import re

def animate(path, old, new):
    with open(path, 'r') as f:
        content = f.read()
    content = re.sub(old, new, content)
    with open(path, 'w') as f:
        f.write(content)

# Admin
animate('/workspace/app-bq45u0keznk1/src/pages/AdminDashboard.tsx',
    r'className="bg-card card-glow border-border"',
    'className="bg-card card-glow border-border animate-in fade-in zoom-in-95 duration-500"'
)

# Menu
animate('/workspace/app-bq45u0keznk1/src/pages/OnlineOrdering.tsx',
    r'className={`flex flex-col overflow-hidden rounded-lg transition-opacity bg-card border border-border \$\{product.is_available === false \? \'opacity-50\' : \'\'\}`\}',
    'className={`flex flex-col overflow-hidden rounded-lg transition-opacity bg-card border border-border animate-in fade-in zoom-in-95 duration-500 ${product.is_available === false ? \'opacity-50\' : \'\'}`}'
)
