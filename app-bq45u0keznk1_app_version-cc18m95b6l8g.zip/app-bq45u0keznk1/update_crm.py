import sys

path = '/workspace/app-bq45u0keznk1/src/components/CrmPosPanel.tsx'
with open(path, 'r') as f:
    content = f.read()

content = content.replace(
    "const [deliveryType, setDeliveryType] = useState<'szállítás' | 'elvitel' | 'beülős'>('szállítás');",
    "const [deliveryType, setDeliveryType] = useState<'szállítás' | 'elvitel' | 'beülős'>(initialTable ? 'beülős' : 'szállítás');"
)

content = content.replace(
    "const [city, setCity] = useState('');",
    "const [city, setCity] = useState('');\n  useEffect(() => {\n    if (initialTable) {\n      setDeliveryType('beülős');\n      setAddressFields(prev => ({...prev, street: initialTable}));\n    }\n  }, [initialTable]);"
)

with open(path, 'w') as f:
    f.write(content)
print("Done")
