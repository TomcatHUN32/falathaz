import sys

# 1. Read old AdminDashboard
with open('/tmp/old_AdminDashboard.tsx', 'r') as f:
    old_content = f.read()

# Get the helper functions (lines 1300-end)
# We can just split by lines
old_lines = old_content.split('\n')
helper_functions = '\n'.join(old_lines[1299:])

# Get the old tabs block
# It starts around {activeTab === 'extra-menu' && (
# and ends before {/* ── Alsó Menü Sáv (Mobil) ── */}
start_idx = old_content.find("{activeTab === 'extra-menu' && (")
end_idx = old_content.find("{/* ── Alsó Menü Sáv (Mobil) ── */}")
old_tabs_block = old_content[start_idx:end_idx].strip()
if old_tabs_block.endswith('</div>'):
    old_tabs_block = old_tabs_block[:-6].strip()

# 2. Read new AdminDashboard
path = '/workspace/app-bq45u0keznk1/src/pages/AdminDashboard.tsx'
with open(path, 'r') as f:
    new_content = f.read()

# Replace the placeholder
placeholder = """{['products', 'stats', 'couriers', 'courier-management', 'coupons', 'settings', 'napi-zaras', 'futar-zaras'].includes(activeTab) && (
          <div className="p-6 h-full overflow-y-auto bg-white">
            <h2 className="text-xl font-bold mb-4 uppercase text-gray-800">{activeTab.replace('-', ' ')}</h2>
            <p className="text-gray-500">Kérlek használd a korábbi felületet ezen funkciók eléréséhez, vagy nyisd meg az újításokat.</p>
          </div>
        )}"""

if placeholder in new_content:
    new_content = new_content.replace(placeholder, old_tabs_block)
    
# Append helper functions if they are missing
if "function ProductManagement" not in new_content:
    new_content += "\n" + helper_functions

with open(path, 'w') as f:
    f.write(new_content)
    
print("Restored tabs and helper functions!")
