import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { orderApi, reviewApi } from '@/services/api';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Separator } from '@/components/ui/separator';
import { toast } from 'sonner';
import type { Order, Review } from '@/types';
import AppHeader from '@/components/AppHeader';
import { Star, Package, MapPin, ExternalLink, CheckCircle } from 'lucide-react';

const STATUS_MAP: Record<string, { label: string; color: string }> = {
  pending: { label: 'Feldolgozás alatt', color: 'bg-yellow-500/20 text-yellow-400' },
  accepted: { label: 'Elfogadva', color: 'bg-blue-500/20 text-blue-400' },
  preparing: { label: 'Konyhán készül', color: 'bg-orange-500/20 text-orange-400' },
  ready: { label: 'Kész', color: 'bg-purple-500/20 text-purple-400' },
  delivering: { label: 'Kiszállítás alatt', color: 'bg-primary/15 text-primary' },
  delivered: { label: 'Kiszállítva ✓', color: 'bg-green-500/20 text-green-400' },
  cancelled: { label: 'Sztornózva', color: 'bg-red-500/20 text-red-400' },
};

function StarRating({ value, onChange, size = 'md' }: { value: number; onChange?: (v: number) => void; size?: 'sm' | 'md' | 'lg' }) {
  const [hovered, setHovered] = useState(0);
  const sz = size === 'sm' ? 'w-4 h-4' : size === 'lg' ? 'w-8 h-8' : 'w-6 h-6';
  return (
    <div className="flex gap-1">
      {[1, 2, 3, 4, 5].map((star) => (
        <Star
          key={star}
          className={`${sz} transition-colors ${onChange ? 'cursor-pointer' : ''} ${
            star <= (hovered || value) ? 'text-yellow-400 fill-yellow-400' : 'text-muted-foreground'
          }`}
          onMouseEnter={() => onChange && setHovered(star)}
          onMouseLeave={() => onChange && setHovered(0)}
          onClick={() => onChange?.(star)}
        />
      ))}
    </div>
  );
}

function ReviewDialog({
  order,
  existingReview,
  open,
  onClose,
  onSubmitted,
}: {
  order: Order;
  existingReview: Review | null;
  open: boolean;
  onClose: () => void;
  onSubmitted: () => void;
}) {
  const [rating, setRating] = useState(existingReview?.rating || 0);
  const [foodRating, setFoodRating] = useState(existingReview?.food_rating || 0);
  const [deliveryRating, setDeliveryRating] = useState(existingReview?.delivery_rating || 0);
  const [comment, setComment] = useState(existingReview?.comment || '');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (open && existingReview) {
      setRating(existingReview.rating);
      setFoodRating(existingReview.food_rating || 0);
      setDeliveryRating(existingReview.delivery_rating || 0);
      setComment(existingReview.comment || '');
    } else if (open && !existingReview) {
      setRating(0); setFoodRating(0); setDeliveryRating(0); setComment('');
    }
  }, [open, existingReview]);

  const handleSubmit = async () => {
    if (!rating) { toast.error('Kérjük adj meg egy összesített értékelést!'); return; }
    setSubmitting(true);
    try {
      await reviewApi.create({
        order_id: order._id,
        rating,
        food_rating: foodRating || undefined,
        delivery_rating: deliveryRating || undefined,
        comment: comment.trim(),
      });
      toast.success('Köszönjük az értékelésedet!');
      onSubmitted();
      onClose();
    } catch (err: any) {
      toast.error(err.response?.data?.error || 'Hiba az értékelés mentésekor');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="bg-card border border-primary/30 max-w-[calc(100%-2rem)] md:max-w-lg" aria-describedby={undefined}>
        <DialogTitle className="sr-only">Értékelés írása</DialogTitle>
        <DialogHeader>
          <DialogTitle className="text-foreground flex items-center gap-2">
            <Star className="w-5 h-5 text-yellow-400" />
            {existingReview ? 'Értékelésed' : 'Rendelés értékelése'}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-5 pt-1">
          {/* rendelt ételek */}
          <div className="bg-secondary rounded-lg p-3 border border-primary/10">
            <p className="text-xs text-muted-foreground mb-1">Rendelés #{order._id.slice(-4)}</p>
            <p className="text-sm text-foreground">{order.items.map((i) => `${i.name} ×${i.quantity}`).join(', ')}</p>
          </div>

          {/* Összesített csillag */}
          <div>
            <p className="text-sm font-medium text-foreground mb-2">Összesített értékelés *</p>
            {existingReview
              ? <StarRating value={rating} size="lg" />
              : <StarRating value={rating} onChange={setRating} size="lg" />
            }
            <p className="text-xs text-muted-foreground mt-1">
              {rating === 1 && 'Nagyon rossz'}
              {rating === 2 && 'Rossz'}
              {rating === 3 && 'Megfelelő'}
              {rating === 4 && 'Jó'}
              {rating === 5 && 'Kiváló!'}
            </p>
          </div>

          <Separator className="bg-[#ff6600]/10" />

          {/* Részletes értékelések */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-xs text-muted-foreground mb-1.5">Ételek minősége</p>
              {existingReview
                ? <StarRating value={foodRating} />
                : <StarRating value={foodRating} onChange={setFoodRating} />
              }
            </div>
            <div>
              <p className="text-xs text-muted-foreground mb-1.5">Kiszállítás</p>
              {existingReview
                ? <StarRating value={deliveryRating} />
                : <StarRating value={deliveryRating} onChange={setDeliveryRating} />
              }
            </div>
          </div>

          {/* Szöveges megjegyzés */}
          {existingReview ? (
            comment ? (
              <div>
                <p className="text-xs text-muted-foreground mb-1">Megjegyzésed</p>
                <p className="text-sm text-foreground bg-secondary rounded-lg p-3 border border-primary/10">{comment}</p>
              </div>
            ) : null
          ) : (
            <div>
              <p className="text-sm font-medium text-foreground mb-2">Megjegyzés (nem kötelező)</p>
              <Textarea
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                placeholder="Írd le tapasztalataidat..."
                className="bg-secondary border-primary/20 text-foreground resize-none"
                rows={3}
                maxLength={500}
              />
              <p className="text-xs text-muted-foreground mt-1 text-right">{comment.length}/500</p>
            </div>
          )}

          {!existingReview && (
            <div className="flex gap-3 pt-1">
              <Button variant="ghost" onClick={onClose} className="flex-1 border border-primary/20 text-muted-foreground">
                Mégse
              </Button>
              <Button
                onClick={handleSubmit}
                disabled={submitting || !rating}
                className="flex-1 btn-primary-gradient text-foreground font-bold"
              >
                {submitting ? 'Mentés...' : 'Értékelés küldése'}
              </Button>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

export default function MyOrders() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [reviews, setReviews] = useState<Record<string, Review | null>>({});
  const [reviewOrder, setReviewOrder] = useState<Order | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    loadOrders();
  }, []);

  const loadOrders = async () => {
    try {
      const res = await orderApi.getMyOrders();
      const loaded: Order[] = res.data;
      setOrders(loaded);
      // értékelések lekérése minden lezárt rendeléshez
      const deliveredOrders = loaded.filter((o) => o.status === 'delivered');
      const reviewMap: Record<string, Review | null> = {};
      await Promise.all(
        deliveredOrders.map(async (o) => {
          try {
            const r = await reviewApi.getByOrder(o._id);
            reviewMap[o._id] = r.data;
          } catch {
            reviewMap[o._id] = null;
          }
        })
      );
      setReviews(reviewMap);
    } catch {
      toast.error('Nem sikerült betölteni a rendeléseket');
    }
  };

  const handleReviewSubmitted = () => {
    loadOrders();
  };

  return (
    <div className="min-h-screen bg-background">
      <AppHeader />

      <main className="max-w-2xl mx-auto px-4 py-6 space-y-4">
        {orders.length === 0 ? (
          <div className="text-center py-12">
            <Package className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">Még nincs leadott rendelésed</p>
            <Button className="mt-4 btn-primary-gradient text-foreground" onClick={() => navigate('/')}>
              Étlap megtekintése
            </Button>
          </div>
        ) : (
          orders.map((order) => {
            const statusInfo = STATUS_MAP[order.status] || { label: order.status, color: 'bg-muted text-muted-foreground' };
            const isDelivered = order.status === 'delivered';
            const hasReview = reviews[order._id] != null;
            const review = reviews[order._id] ?? null;

            return (
              <Card key={order._id} className="bg-card border border-border card-glow">
                <CardContent className="p-4">
                  {/* fejléc */}
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-foreground font-bold text-base">#{order._id.slice(-4)}</span>
                    <Badge className={`${statusInfo.color} text-xs`}>{statusInfo.label}</Badge>
                  </div>

                  {/* metaadatok */}
                  <div className="space-y-1 mb-3">
                    <p className="text-muted-foreground text-xs">
                      {new Date(order.createdAt).toLocaleString('hu-HU')}
                    </p>
                    <p className="text-muted-foreground text-sm flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-primary shrink-0" />
                      {order.address}
                    </p>
                    <p className="text-sm text-foreground/70 text-pretty">
                      {order.items.map((i) => `${i.name} ×${i.quantity}`).join(', ')}
                    </p>
                  </div>

                  <div className="flex items-center justify-between">
                    <p className="text-primary font-bold text-base">{order.total.toLocaleString()} Ft</p>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-muted-foreground border border-border hover:border-primary/40 hover:text-primary h-8"
                      onClick={() => navigate(`/track/${order._id}`)}
                    >
                      <ExternalLink className="w-3 h-3 mr-1.5" />
                      Követés
                    </Button>
                  </div>

                  {/* Értékelés szekció — csak lezárt rendelésnél */}
                  {isDelivered && (
                    <>
                      <Separator className="my-3 bg-white/6" />
                      {hasReview && review ? (
                        <div
                          className="flex items-center justify-between cursor-pointer group"
                          onClick={() => setReviewOrder(order)}
                        >
                          <div className="flex items-center gap-2">
                            <CheckCircle className="w-4 h-4 text-green-400 shrink-0" />
                            <span className="text-sm text-green-400">Értékelted</span>
                            <StarRating value={review.rating} size="sm" />
                          </div>
                          <span className="text-xs text-muted-foreground group-hover:text-primary transition-colors">
                            Megtekintés
                          </span>
                        </div>
                      ) : (
                        <Button
                          className="w-full bg-yellow-500/10 border border-yellow-500/30 text-yellow-400 hover:bg-yellow-500/20 hover:border-yellow-500/60 font-medium h-9"
                          onClick={() => setReviewOrder(order)}
                        >
                          <Star className="w-4 h-4 mr-2" />
                          Értékeld a rendelést
                        </Button>
                      )}
                    </>
                  )}
                </CardContent>
              </Card>
            );
          })
        )}
      </main>

      {/* Értékelés dialógus */}
      {reviewOrder && (
        <ReviewDialog
          order={reviewOrder}
          existingReview={reviews[reviewOrder._id] ?? null}
          open={!!reviewOrder}
          onClose={() => setReviewOrder(null)}
          onSubmitted={handleReviewSubmitted}
        />
      )}
    </div>
  );
}
