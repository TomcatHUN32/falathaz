import React, { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { useNavigate } from 'react-router-dom';
import api from '../services/api';
import { Store, MapPin, Clock, LogIn, LayoutDashboard } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';

const MainPortal = () => {
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const [step, setStep] = useState(1);
  
  const [county, setCounty] = useState('');
  const [city, setCity] = useState('');
  const [restaurants, setRestaurants] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  // Hardcoded counties and cities for demo purposes, in reality this might be fetched
  const counties = ['Budapest', 'Borsod-Abaúj-Zemplén', 'Pest', 'Győr-Moson-Sopron'];
  const cities = {
    'Borsod-Abaúj-Zemplén': ['Miskolc', 'Szuhogy', 'Kazincbarcika'],
    'Budapest': ['Budapest'],
    'Pest': ['Érd', 'Cegléd', 'Vác'],
    'Győr-Moson-Sopron': ['Győr', 'Sopron']
  };

  const searchRestaurants = async () => {
    if (!county || !city) return;
    setLoading(true);
    try {
      const res = await api.get('/restaurants/public', { params: { county, city } });
      setRestaurants(res.data);
      setStep(2);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const getStatusText = (r: any) => {
    return r.is_open 
      ? <span className="text-green-500 font-semibold">Nyitva</span>
      : <span className="text-red-500 font-semibold">Zárva</span>;
  };

  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center p-4 relative">
      <div className="absolute top-4 right-4 flex gap-2">
        {user ? (
          <>
            {user.role === 'superadmin' && (
              <Button variant="outline" onClick={() => navigate('/super-admin')} className="border-primary/20 text-primary hover:bg-primary/10">
                <LayoutDashboard className="w-4 h-4 mr-2" />
                Super Admin
              </Button>
            )}
            <Button variant="ghost" onClick={logout} className="text-muted-foreground hover:text-foreground">
              Kijelentkezés
            </Button>
          </>
        ) : (
          <Button variant="ghost" onClick={() => navigate('/login')} className="text-muted-foreground hover:text-foreground">
            <LogIn className="w-4 h-4 mr-2" />
            Bejelentkezés
          </Button>
        )}
      </div>
      <div className="max-w-2xl w-full space-y-8 animate-fade-in text-center mt-12">
        <div className="space-y-4">
          <h1 className="text-4xl md:text-6xl font-bold font-heading text-primary">Szesztestvérek Falatház</h1>
          <p className="text-muted-foreground text-lg md:text-xl text-balance">
            {step === 1 ? 'Válaszd ki a tartózkodási helyed a rendeléshez!' : 'Válassz éttermet a folytatáshoz!'}
          </p>
        </div>

        {step === 1 && (
          <Card className="max-w-md mx-auto bg-card/50 backdrop-blur border-border/50">
            <CardContent className="p-6 md:p-8 space-y-6">
              <div className="space-y-4 text-left">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Megye</label>
                  <Select value={county} onValueChange={(v) => { setCounty(v); setCity(''); }}>
                    <SelectTrigger className="h-12"><SelectValue placeholder="Válassz megyét..." /></SelectTrigger>
                    <SelectContent>
                      {counties.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium">Város</label>
                  <Select value={city} onValueChange={setCity} disabled={!county}>
                    <SelectTrigger className="h-12"><SelectValue placeholder="Válassz várost..." /></SelectTrigger>
                    <SelectContent>
                      {county && (cities[county as keyof typeof cities] || []).map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <Button 
                className="w-full h-12 text-lg rounded-full shadow-lg shadow-primary/20" 
                onClick={searchRestaurants}
                disabled={!county || !city || loading}
              >
                {loading ? 'Keresés...' : 'Tovább'}
              </Button>
            </CardContent>
          </Card>
        )}

        {step === 2 && (
          <div className="space-y-6">
            <div className="flex items-center justify-center gap-2 text-muted-foreground">
              <MapPin className="w-4 h-4" />
              <span>{county}, {city}</span>
              <button onClick={() => setStep(1)} className="text-primary text-sm underline ml-2">Módosítás</button>
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              {restaurants.map(r => (
                <Card 
                  key={r._id} 
                  className="overflow-hidden hover:border-primary/50 transition-colors cursor-pointer group"
                  onClick={() => navigate(`/${r._id}/menu`)}
                >
                  <CardContent className="p-6 flex flex-col h-full text-left">
                    <div className="flex justify-between items-start mb-4">
                      <h3 className="text-2xl font-bold font-heading group-hover:text-primary transition-colors">{r.name}</h3>
                      <div className="bg-card px-3 py-1 rounded-full text-sm flex items-center gap-2 border">
                        <Clock className="w-3.5 h-3.5" />
                        {getStatusText(r)}
                      </div>
                    </div>
                    <p className="text-muted-foreground line-clamp-2 mb-6 flex-1">
                      {r.description || 'Kiváló minőségű ételek, gyors kiszállítás, friss alapanyagok.'}
                    </p>
                    <Button variant="ghost" asChild><span className="w-full border border-primary/20 hover:bg-primary/10 group-hover:bg-primary group-hover:text-primary-foreground">
                      Étlap megtekintése →</span>
                    </Button>
                  </CardContent>
                </Card>
              ))}
              
              {restaurants.length === 0 && (
                <div className="col-span-full py-12 text-center text-muted-foreground">
                  Sajnos jelenleg nincs elérhető étterem ebben a városban.
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default MainPortal;
