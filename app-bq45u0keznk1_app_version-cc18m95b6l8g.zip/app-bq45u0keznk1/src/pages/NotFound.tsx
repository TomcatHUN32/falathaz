import { Link } from "react-router-dom";
import { ChefHat } from "lucide-react";

export default function NotFound() {
  return (
    <div className="relative flex flex-col items-center justify-center min-h-screen p-6 bg-gradient-to-b from-[#0a0a0a] to-[#111111]">
      <div className="mx-auto w-full max-w-md text-center">
        <div className="mx-auto mb-6 w-20 h-20 rounded-full bg-gradient-to-br from-[#ff6600] to-[#cc0000] flex items-center justify-center">
          <ChefHat className="w-10 h-10 text-white" />
        </div>
        <h1 className="mb-4 font-bold text-4xl text-white neon-text">
          404
        </h1>
        <p className="mt-4 mb-8 text-lg text-muted-foreground">
          Az oldal nem található. Kérjük, ellenőrizze a címet.
        </p>
        <Link
          to="/"
          className="inline-flex items-center justify-center rounded-lg bg-gradient-to-r from-[#ff6600] to-[#cc0000] px-6 py-3 text-sm font-bold text-white hover:opacity-90"
        >
          Vissza a főoldalra
        </Link>
      </div>
      <p className="absolute text-sm text-center text-muted-foreground bottom-6">
        &copy; {new Date().getFullYear()} Szesztestvérek Falatház
      </p>
    </div>
  );
}
