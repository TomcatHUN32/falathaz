import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { authApi, orderApi, favoriteApi, settingsApi } from '@/services/api';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { ArrowLeft, User, MapPin, Lock, Phone, Save, ChefHat, LogOut, Star, ShoppingBag, RotateCcw, Heart, Crown, Award, Trash2 } from 'lucide-react';
import type { Order, Product } from '@/types';

export default function Profile() {
  const { user, setUser, logout } = useAuth();
  const navigate = useNavigate();

  // Adatok szerkesztése
  const [name, setName] = useState(user?.name || '');
  const [address, setAddress] = useState(user?.default_address || '');
  const [savingInfo, setSavingInfo] = useState(false);

  // Jelszócsere
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [savingPassword, setSavingPassword] = useState(false);
  
  // Egyéb adatok
  const [orders, setOrders] = useState<Order[]>([]);
  const [favorites, setFavorites] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'profile' | 'orders' | 'favorites'>('profile');
  const [loyaltySettings, setLoyaltySettings] = useState({
    bronze_threshold: 10,
    silver_threshold: 50,
    gold_threshold: 100,
  });

  useEffect(() => {
    if (user?.id) {
      loadUserData();
    }
    settingsApi.get('loyalty_settings').then(res => {
      const data = res.data?.value || res.data;
      if (data) setLoyaltySettings(data);
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  const loadUserData = async () => {
    try {
      setLoading(true);
      const [ordersRes, favRes, userRes] = await Promise.allSettled([
        orderApi.getMyOrders(),
        favoriteApi.getFavorites(),
        authApi.getMe() // Frissítjük a profil adatokat (pontok)
      ]);
      
      if (ordersRes.status === 'fulfilled') {
        setOrders(ordersRes.value.data || []);
      } else {
        console.error('Failed to load orders', ordersRes.reason);
        setOrders([]);
      }

      if (favRes.status === 'fulfilled') {
        setFavorites(Array.isArray(favRes.value.data) ? favRes.value.data.filter((f: any) => f.product) : []);
      } else {
        console.error('Failed to load favorites', favRes.reason);
        setFavorites([]);
      }
      
      if (userRes.status === 'fulfilled' && userRes.value.data && userRes.value.data.points !== undefined) {
        setUser({ ...user, ...userRes.value.data });
      }
    } catch (err) {
      console.error('Hiba az adatok betöltésekor:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleReorder = (order: Order) => {
    // Töröljük a kosarat
    localStorage.removeItem('szt_cart');
    
    // Újraépítjük
    const newCart = order.items.map(item => ({
      product_id: item.product_id,
      name: item.name,
      quantity: item.quantity,
      price: item.price,
      packaging_fee: 0,
      drs_applies: false,
      extras: item.extras || [],
      product: {} as Product // Mock, valós appban lekérjük
    }));
    
    localStorage.setItem('szt_cart', JSON.stringify(newCart));
    toast.success('Rendelés tartalma a kosárba rakva!');
    navigate('/menu');
  };

  const removeFavorite = async (productId: string) => {
    try {
      await favoriteApi.removeFavorite(productId);
      setFavorites(prev => prev.filter(f => f.product._id !== productId));
      toast.success('Törölve a kedvencekből');
    } catch (err) {
      toast.error('Hiba történt a törlés során');
    }
  };


  const handleSaveInfo = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingInfo(true);
    try {
      const res = await authApi.updateProfile({
        name: name.trim(),
        default_address: address.trim(),
      });
      setUser(res.data);
      toast.success('Adatok sikeresen mentve!');
    } catch (err: any) {
      toast.error(err.response?.data?.error || 'Mentés sikertelen');
    } finally {
      setSavingInfo(false);
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword !== confirmPassword) {
      toast.error('Az új jelszavak nem egyeznek!');
      return;
    }
    if (newPassword.length < 6) {
      toast.error('A jelszónak legalább 6 karakter hosszúnak kell lennie!');
      return;
    }
    setSavingPassword(true);
    try {
      await authApi.updateProfile({
        current_password: currentPassword,
        new_password: newPassword,
      });
      toast.success('Jelszó sikeresen megváltoztatva!');
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
    } catch (err: any) {
      toast.error(err.response?.data?.error || 'Jelszócsere sikertelen');
    } finally {
      setSavingPassword(false);
    }
  };

  const roleLabel = user?.role === 'admin' ? 'Adminisztrátor' : user?.role === 'courier' ? 'Futár' : 'Vendég';
  const roleBadgeClass = user?.role === 'admin'
    ? 'bg-destructive/15 text-destructive border-destructive/30'
    : user?.role === 'courier'
    ? 'bg-blue-500/20 text-blue-400 border-blue-500/30'
    : 'bg-primary/15 text-primary border-primary/30';

  if (loading) {
    return <div className="min-h-screen bg-background flex items-center justify-center text-primary font-bold">Betöltés...</div>;
  }

  return (
    <div className="theme-restaurant min-h-screen bg-background text-foreground pb-20">
      {/* Fejléc */}
      <header className="sticky top-0 z-50 bg-card/80 backdrop-blur border-b border-white/10">
        <div className="max-w-4xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button onClick={() => navigate(-1)} className="text-muted-foreground hover:text-white transition-colors p-2 rounded-full hover:bg-white/5">
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
                <ChefHat className="w-5 h-5 text-primary" />
              </div>
              <div>
                <h1 className="text-lg font-bold text-white leading-tight">Profilom</h1>
                <p className="text-xs text-primary leading-tight font-medium tracking-wide uppercase">Falatház</p>
              </div>
            </div>
          </div>
          <button
            onClick={() => { logout(); navigate('/login'); }}
            className="flex items-center gap-1.5 text-sm text-destructive/80 hover:text-destructive transition-colors font-medium"
          >
            <LogOut className="w-4 h-4" />
            <span className="hidden sm:inline">Kijelentkezés</span>
          </button>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-8 space-y-6">
        
        {/* Navigációs Tabok */}
        <div className="flex bg-card border border-white/5 rounded-2xl p-1 mb-8">
          <button 
            onClick={() => setActiveTab('profile')} 
            className={`flex-1 py-3 px-4 rounded-xl text-sm font-bold transition-all ${activeTab === 'profile' ? 'bg-primary text-white shadow-[0_0_15px_rgba(234,90,12,0.3)]' : 'text-muted-foreground hover:text-white hover:bg-white/5'}`}
          >
            Adataim
          </button>
          <button 
            onClick={() => setActiveTab('orders')} 
            className={`flex-1 py-3 px-4 rounded-xl text-sm font-bold transition-all ${activeTab === 'orders' ? 'bg-primary text-white shadow-[0_0_15px_rgba(234,90,12,0.3)]' : 'text-muted-foreground hover:text-white hover:bg-white/5'}`}
          >
            Rendeléseim
          </button>
          <button 
            onClick={() => setActiveTab('favorites')} 
            className={`flex-1 py-3 px-4 rounded-xl text-sm font-bold transition-all ${activeTab === 'favorites' ? 'bg-primary text-white shadow-[0_0_15px_rgba(234,90,12,0.3)]' : 'text-muted-foreground hover:text-white hover:bg-white/5'}`}
          >
            Kedvencek
          </button>
        </div>

        {activeTab === 'profile' && (
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
            <div className="md:col-span-5 space-y-6">
              {/* Felhasználói összefoglaló */}
              <div className="flex flex-col items-center p-8 rounded-2xl bg-card border border-white/5 shadow-xl text-center">
                <div className="relative">
                  <div className="w-24 h-24 rounded-full bg-primary/20 border-2 border-primary flex items-center justify-center text-primary font-black text-4xl mb-4 shadow-[0_0_25px_rgba(234,90,12,0.3)]">
                    {user?.name?.charAt(0).toUpperCase() || '?'}
                  </div>
                </div>
                
                <h2 className="text-white font-bold text-xl mb-1">{user?.name}</h2>
                <div className="flex items-center justify-center gap-2 mb-4 text-muted-foreground">
                  <Phone className="w-4 h-4" />
                  <span className="text-sm">{user?.phone}</span>
                </div>
                
                <div className="flex flex-wrap justify-center gap-2">
                  <Badge className={`text-xs font-bold px-3 py-1 bg-primary/10 border border-primary/30 text-primary`}>
                    <Star className="w-3.5 h-3.5 mr-1" /> Hűségpont: {(user as any)?.points || 0} pont
                  </Badge>
                  {user?.role === 'admin' && <Badge className="bg-destructive/20 text-destructive border-destructive/30 px-3 py-1 text-xs">Admin</Badge>}
                </div>
              </div>

            </div>

            <div className="md:col-span-7 space-y-6">
              {/* Személyes adatok */}
              <Card className="bg-card border border-white/5 rounded-2xl shadow-xl">
                <CardHeader className="border-b border-white/5 pb-4">
                  <CardTitle className="text-white flex items-center gap-3 text-lg">
                    <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
                      <User className="w-5 h-5 text-primary" />
                    </div>
                    Személyes adatok
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-6">
                  <form onSubmit={handleSaveInfo} className="space-y-5">
                    <div className="space-y-1.5">
                      <Label htmlFor="prof-name" className="text-sm font-medium text-white/80">Teljes név</Label>
                      <Input
                        id="prof-name"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="Teljes neved"
                        required
                        className="bg-black/50 border-white/10 focus-visible:ring-primary/50 focus-visible:border-primary text-white h-12 rounded-xl"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor="prof-phone" className="text-sm font-medium text-white/80">Telefonszám (nem szerkeszthető)</Label>
                      <Input
                        id="prof-phone"
                        value={user?.phone || ''}
                        disabled
                        className="bg-black/20 border-white/5 text-white/50 h-12 rounded-xl cursor-not-allowed"
                      />
                      <p className="text-xs text-white/30 mt-1 pl-1">A telefonszám a belépéshez szükséges, nem módosítható.</p>
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor="prof-address" className="text-sm font-medium text-white/80 flex items-center gap-1.5">
                        <MapPin className="w-3.5 h-3.5 text-primary" />
                        Alapértelmezett szállítási cím
                      </Label>
                      <Input
                        id="prof-address"
                        value={address}
                        onChange={(e) => setAddress(e.target.value)}
                        placeholder="Pl. Szuhogy, Kossuth u. 10."
                        className="bg-black/50 border-white/10 focus-visible:ring-primary/50 focus-visible:border-primary text-white h-12 rounded-xl"
                      />
                    </div>
                    <Button
                      type="submit"
                      disabled={savingInfo}
                      className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-bold h-12 rounded-xl shadow-[0_0_15px_rgba(234,90,12,0.3)] transition-all hover:shadow-[0_0_25px_rgba(234,90,12,0.5)] mt-2"
                    >
                      <Save className="w-5 h-5 mr-2" />
                      {savingInfo ? 'Mentés folyamatban...' : 'Adatok mentése'}
                    </Button>
                  </form>
                </CardContent>
              </Card>

              {/* Biztonság */}
              <Card className="bg-card border border-white/5 rounded-2xl shadow-xl">
                <CardHeader className="border-b border-white/5 pb-4">
                  <CardTitle className="text-white flex items-center gap-3 text-lg">
                    <div className="w-10 h-10 rounded-xl bg-destructive/10 flex items-center justify-center">
                      <Lock className="w-5 h-5 text-destructive" />
                    </div>
                    Biztonság
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-6">
                  <form onSubmit={handleChangePassword} className="space-y-5">
                    <div className="space-y-1.5">
                      <Label htmlFor="curr-pwd" className="text-sm font-medium text-white/80">Jelenlegi jelszó</Label>
                      <Input
                        id="curr-pwd"
                        type="password"
                        value={currentPassword}
                        onChange={(e) => setCurrentPassword(e.target.value)}
                        required
                        className="bg-black/50 border-white/10 focus-visible:ring-destructive/50 focus-visible:border-destructive text-white h-12 rounded-xl"
                      />
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="space-y-1.5">
                        <Label htmlFor="new-pwd" className="text-sm font-medium text-white/80">Új jelszó</Label>
                        <Input
                          id="new-pwd"
                          type="password"
                          value={newPassword}
                          onChange={(e) => setNewPassword(e.target.value)}
                          required
                          className="bg-black/50 border-white/10 focus-visible:ring-destructive/50 focus-visible:border-destructive text-white h-12 rounded-xl"
                        />
                      </div>
                      <div className="space-y-1.5">
                        <Label htmlFor="conf-pwd" className="text-sm font-medium text-white/80">Új jelszó megerősítése</Label>
                        <Input
                          id="conf-pwd"
                          type="password"
                          value={confirmPassword}
                          onChange={(e) => setConfirmPassword(e.target.value)}
                          required
                          className="bg-black/50 border-white/10 focus-visible:ring-destructive/50 focus-visible:border-destructive text-white h-12 rounded-xl"
                        />
                      </div>
                    </div>
                    <Button
                      type="submit"
                      disabled={savingPassword}
                      variant="outline"
                      className="w-full border-destructive/50 text-destructive hover:bg-destructive/10 hover:text-destructive hover:border-destructive font-bold h-12 rounded-xl mt-2"
                    >
                      <Lock className="w-4 h-4 mr-2" />
                      {savingPassword ? 'Csere...' : 'Jelszó módosítása'}
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </div>
          </div>
        )}

        {/* Rendeléseim Tab */}
        {activeTab === 'orders' && (
          <div className="space-y-4">
            <h2 className="text-2xl font-black text-white mb-6">Korábbi rendeléseim</h2>
            
            {orders.length === 0 ? (
              <Card className="bg-card border border-white/5 rounded-2xl py-12 text-center">
                <CardContent>
                  <ShoppingBag className="w-16 h-16 text-white/10 mx-auto mb-4" />
                  <h3 className="text-xl font-bold text-white mb-2">Még nincs rendelésed</h3>
                  <p className="text-muted-foreground mb-6">Fedezd fel étlapunkat és rendelj valami finomat!</p>
                  <Button onClick={() => navigate('/menu')} className="bg-primary text-primary-foreground font-bold h-12 px-8 rounded-xl shadow-[0_0_15px_rgba(234,90,12,0.3)]">
                    Tovább az étlaphoz
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {orders.map((order) => (
                  <Card key={order._id} className="bg-card border border-white/5 rounded-2xl overflow-hidden shadow-lg transition-all hover:shadow-[0_0_20px_rgba(234,90,12,0.1)] hover:border-primary/20 flex flex-col h-full">
                    <div className="bg-white/5 px-5 py-4 border-b border-white/10 flex justify-between items-center">
                      <div>
                        <p className="text-white font-bold">#{order._id.slice(-6).toUpperCase()}</p>
                        <p className="text-xs text-muted-foreground">{new Date(order.createdAt).toLocaleDateString('hu-HU', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</p>
                      </div>
                      <Badge variant="outline" className={`
                        ${order.status === 'delivered' ? 'border-green-500/30 text-green-400 bg-green-500/10' : 
                          order.status === 'cancelled' ? 'border-red-500/30 text-red-400 bg-red-500/10' : 
                          'border-primary/30 text-primary bg-primary/10'}
                      `}>
                        {order.status === 'delivered' ? 'Kiszállítva' : order.status === 'cancelled' ? 'Sztornózva' : 'Folyamatban'}
                      </Badge>
                    </div>
                    
                    <CardContent className="p-5 flex-1 flex flex-col">
                      <div className="space-y-2 mb-6 flex-1">
                        {order.items.slice(0, 3).map((item: any, i: number) => (
                          <div key={i} className="flex justify-between items-center text-sm">
                            <span className="text-white/80">{item.quantity}x {item.name}</span>
                            <span className="text-white font-medium">{(item.price * item.quantity).toLocaleString('hu-HU')} Ft</span>
                          </div>
                        ))}
                        {order.items.length > 3 && (
                          <div className="text-xs text-muted-foreground pt-1">...és további {order.items.length - 3} tétel</div>
                        )}
                      </div>
                      
                      <div className="border-t border-white/10 pt-4 mt-auto">
                        <div className="flex justify-between items-center mb-4">
                          <span className="text-muted-foreground text-sm">Összesen</span>
                          <span className="text-primary font-black text-lg">{order.total.toLocaleString('hu-HU')} Ft</span>
                        </div>
                        
                        <div className="grid grid-cols-2 gap-2">
                          <Button 
                            variant="ghost" 
                            className="bg-transparent border border-white/20 text-white hover:bg-white/10 h-10"
                            onClick={() => navigate(`/tracking/${order._id}`)}
                          >
                            Részletek
                          </Button>
                          <Button 
                            className="bg-primary text-primary-foreground font-bold h-10 shadow-[0_0_10px_rgba(234,90,12,0.3)] hover:shadow-[0_0_15px_rgba(234,90,12,0.5)]"
                            onClick={() => handleReorder(order)}
                          >
                            <RotateCcw className="w-4 h-4 mr-2" /> Ujra
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Kedvencek Tab */}
        {activeTab === 'favorites' && (
          <div className="space-y-4">
            <h2 className="text-2xl font-black text-white mb-6">Mentett kedvenceid</h2>
            
            {favorites.length === 0 ? (
              <Card className="bg-card border border-white/5 rounded-2xl py-12 text-center">
                <CardContent>
                  <Heart className="w-16 h-16 text-white/10 mx-auto mb-4" />
                  <h3 className="text-xl font-bold text-white mb-2">Nincsenek még kedvenceid</h3>
                  <p className="text-muted-foreground mb-6">Böngészd az étlapot és jelöld meg a kedvenc ételeidet a szív ikonnal!</p>
                  <Button onClick={() => navigate('/menu')} className="bg-primary text-primary-foreground font-bold h-12 px-8 rounded-xl shadow-[0_0_15px_rgba(234,90,12,0.3)]">
                    Tovább az étlaphoz
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {favorites.map((fav) => (
                  <Card key={fav._id} className="bg-[#0c0a07] border border-[#2e2616] rounded-2xl overflow-hidden group">
                    <div className="relative aspect-[4/3] overflow-hidden">
                      <img 
                        src={fav.product.image || 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?q=80&w=400&auto=format&fit=crop'} 
                        alt={fav.product.name} 
                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" 
                      />
                      <div className="absolute inset-x-0 bottom-0 h-24 bg-gradient-to-t from-[#0c0a07] to-transparent" />
                      <button 
                        onClick={() => removeFavorite(fav.product._id)}
                        className="absolute top-3 right-3 w-10 h-10 rounded-full bg-black/40 backdrop-blur border border-white/10 flex items-center justify-center text-red-500 hover:bg-red-500 hover:text-white transition-colors shadow-lg"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                    <CardContent className="p-4 pt-2 relative z-10">
                      <h3 className="font-bold text-lg text-white mb-1">{fav.product.name}</h3>
                      <p className="text-primary font-black text-lg mb-4">{fav.product.price.toLocaleString('hu-HU')} Ft</p>
                      <Button 
                        className="w-full bg-white/10 hover:bg-primary text-white hover:text-white font-bold h-10 border border-white/10 transition-colors"
                        onClick={() => navigate('/menu')}
                      >
                        Megrendelem
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        )}

      </main>
    </div>
  );
}
