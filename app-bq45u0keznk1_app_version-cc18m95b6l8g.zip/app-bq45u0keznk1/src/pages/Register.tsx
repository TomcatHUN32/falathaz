import { useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { User, Mail, Phone, Lock, MapPin, UserPlus, AlertCircle, Loader2, Eye, EyeOff, Home } from 'lucide-react';
import { toast } from 'sonner';

const LOGO_URL = '/logo.png';

export default function Register() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [passwordConfirm, setPasswordConfirm] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [address, setAddress] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const { register } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const redirect = searchParams.get('redirect') || '/';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isLoading) return;
    if (password !== passwordConfirm) {
      setError('A két jelszó nem egyezik meg!');
      return;
    }
    setError('');
    setIsLoading(true);
    try {
      const success = await register({
        name,
        email: email.trim().toLowerCase(),
        password,
        phone,
        default_address: address,
        lat: null,
        lng: null,
      });
      if (success) {
        navigate(redirect, { replace: true });
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Ismeretlen hiba történt.';
      setError(msg);
    } finally {
      setIsLoading(false);
    }
  };

  const goToLogin = () => {
    const params = redirect !== '/' ? `?redirect=${encodeURIComponent(redirect)}` : '';
    navigate(`/login${params}`);
  };

  return (
    <div className="theme-restaurant min-h-screen flex bg-background text-foreground">
      {/* Bal oldal - Kép */}
      <div className="hidden lg:flex lg:w-1/2 relative">
        <div className="absolute inset-0 bg-gradient-to-r from-background/40 to-background z-10" />
        <img
          src="https://images.unsplash.com/photo-1513104890138-7c749659a591?q=80&w=2000&auto=format&fit=crop"
          alt="Gourmet Pizza"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 z-20 flex flex-col justify-end p-12 pb-24">
          <div className="flex items-center gap-4 mb-4">
            <img src={LOGO_URL} alt="Logo" className="h-16 w-auto object-contain drop-shadow-[0_0_12px_rgba(234,90,12,0.6)]" />
            <div>
              <h1 className="text-3xl font-black text-white tracking-wide">Szesztestvérek</h1>
              <p className="text-sm font-bold uppercase tracking-[0.25em] text-primary">Falatház</p>
            </div>
          </div>
          <p className="text-white/80 text-lg max-w-md">Csatlakozz közösségünkhöz, gyűjtsd a hűségpontokat és élvezd a prémium funkciókat minden rendelésnél!</p>
        </div>
      </div>

      {/* Jobb oldal - Form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-6 sm:p-12 relative overflow-y-auto">
        
        {/* Vissza a főoldalra gomb mobilon */}
        <div className="absolute top-6 left-6 lg:hidden flex items-center gap-3 cursor-pointer" onClick={() => navigate('/')}>
          <img src={LOGO_URL} alt="Logo" className="h-10 w-auto object-contain" />
        </div>

        <div className="w-full max-w-md space-y-6 py-12">
          <div>
            <h2 className="text-3xl font-bold text-white mb-2">Új fiók</h2>
            <p className="text-muted-foreground">Hozd létre a fiókodat a kedvezményekhez.</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="reg-name" className="text-sm font-medium text-white/80 flex items-center gap-2">
                <User className="w-4 h-4 text-primary" /> Teljes név
              </Label>
              <Input
                id="reg-name"
                value={name}
                onChange={(e) => { setName(e.target.value); setError(''); }}
                placeholder="Pl. Kiss Péter"
                autoComplete="name"
                disabled={isLoading}
                required
                className="bg-black/50 border-white/10 focus-visible:ring-primary/50 focus-visible:border-primary text-white placeholder:text-white/30 h-12 rounded-xl"
              />
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="reg-email" className="text-sm font-medium text-white/80 flex items-center gap-2">
                <Mail className="w-4 h-4 text-primary" /> E-mail cím
              </Label>
              <Input
                id="reg-email"
                type="email"
                value={email}
                onChange={(e) => { setEmail(e.target.value); setError(''); }}
                placeholder="pelda@email.hu"
                autoComplete="email"
                disabled={isLoading}
                required
                className="bg-black/50 border-white/10 focus-visible:ring-primary/50 focus-visible:border-primary text-white placeholder:text-white/30 h-12 rounded-xl"
              />
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="reg-phone" className="text-sm font-medium text-white/80 flex items-center gap-2">
                <Phone className="w-4 h-4 text-primary" /> Telefonszám
              </Label>
              <Input
                id="reg-phone"
                type="tel"
                value={phone}
                onChange={(e) => { setPhone(e.target.value); setError(''); }}
                placeholder="Pl. 06301234567"
                autoComplete="tel"
                disabled={isLoading}
                className="bg-black/50 border-white/10 focus-visible:ring-primary/50 focus-visible:border-primary text-white placeholder:text-white/30 h-12 rounded-xl"
              />
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="reg-password" className="text-sm font-medium text-white/80 flex items-center gap-2">
                <Lock className="w-4 h-4 text-primary" /> Jelszó
              </Label>
              <div className="relative">
                <Input
                  id="reg-password"
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => { setPassword(e.target.value); setError(''); }}
                  placeholder="Minimum 6 karakter"
                  autoComplete="new-password"
                  disabled={isLoading}
                  required
                  className="bg-black/50 border-white/10 focus-visible:ring-primary/50 focus-visible:border-primary text-white placeholder:text-white/30 h-12 rounded-xl pr-10"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-white/50 hover:text-white/80 transition-colors"
                  tabIndex={-1}
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="reg-password-confirm" className="text-sm font-medium text-white/80 flex items-center gap-2">
                <Lock className="w-4 h-4 text-primary" /> Jelszó újra
              </Label>
              <div className="relative">
                <Input
                  id="reg-password-confirm"
                  type={showPassword ? "text" : "password"}
                  value={passwordConfirm}
                  onChange={(e) => { setPasswordConfirm(e.target.value); setError(''); }}
                  placeholder="Minimum 6 karakter"
                  autoComplete="new-password"
                  disabled={isLoading}
                  required
                  className="bg-black/50 border-white/10 focus-visible:ring-primary/50 focus-visible:border-primary text-white placeholder:text-white/30 h-12 rounded-xl pr-10"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="reg-address" className="text-sm font-medium text-white/80 flex items-center gap-2">
                <MapPin className="w-4 h-4 text-primary" /> Szállítási cím
              </Label>
              <Input
                id="reg-address"
                value={address}
                onChange={(e) => { setAddress(e.target.value); setError(''); }}
                placeholder="Pl. Szuhogy, Kossuth u. 10."
                autoComplete="street-address"
                disabled={isLoading}
                required
                className="bg-black/50 border-white/10 focus-visible:ring-primary/50 focus-visible:border-primary text-white placeholder:text-white/30 h-12 rounded-xl"
              />
            </div>

            {error && (
              <div className="flex items-start gap-2 bg-destructive/10 border border-destructive/30 rounded-xl px-4 py-3 text-sm text-destructive">
                <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            <Button
              type="submit"
              disabled={isLoading}
              className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-bold h-12 text-base mt-4 rounded-xl shadow-[0_0_15px_rgba(234,90,12,0.3)] transition-all hover:shadow-[0_0_25px_rgba(234,90,12,0.5)]"
            >
              {isLoading ? (
                <><Loader2 className="w-5 h-5 mr-2 animate-spin" />Kérlek várj...</>
              ) : (
                <><UserPlus className="w-5 h-5 mr-2" />Regisztráció</>
              )}
            </Button>

            <div className="relative my-8">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-white/10"></div>
              </div>
              <div className="relative flex justify-center text-xs">
                <span className="bg-background px-2 text-muted-foreground uppercase tracking-wider">Vagy térj vissza</span>
              </div>
            </div>
            
            <div className="grid grid-cols-1 gap-4">
              <Button type="button" onClick={() => navigate('/')} variant="outline" className="h-12 bg-white/5 border-white/10 hover:bg-white/10 rounded-xl">
                <Home className="w-5 h-5 mr-2" />
                Vissza a főoldalra
              </Button>
            </div>
          </form>

          <p className="text-center mt-8 text-sm text-muted-foreground">
            Már van fiókod?{' '}
            <button
              type="button"
              onClick={goToLogin}
              className="font-semibold text-primary hover:text-primary/80 transition-colors"
            >
              Lépj be itt!
            </button>
          </p>
        </div>
      </div>
    </div>
  );
}

