import { useState, useEffect, useRef, useCallback } from 'react';
import { orderApi, adminApi } from '@/services/api';
import { useAuth } from '@/contexts/AuthContext';
import { useSocket } from '@/contexts/SocketContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import type { Order } from '@/types';
import { Truck, Package, MapPin, Navigation, CheckCircle, ArrowLeft, Phone, TrendingUp, Banknote, CreditCard, LogOut, Loader2, Clock } from 'lucide-react';

const COURIER_STATUS_LABELS: Record<string, string> = {
  assigned: 'Bent van a rendszerbe',
  accepted: 'Fogadva',
  on_the_way: 'Úton',
  delivered: 'Megérkezett',
};

const COURIER_STATUS_ACTIONS: Record<string, { next: string; label: string; icon: any }> = {
  assigned: { next: 'accepted', label: 'Fogadom', icon: CheckCircle },
  accepted: { next: 'on_the_way', label: 'Elindult', icon: Navigation },
  on_the_way: { next: 'delivered', label: 'Megérkezett', icon: CheckCircle },
};

function formatElapsed(minutes: number): string {
  if (minutes < 1) return 'Éppen indult';
  return `${minutes} perc úton`;
}

function CourierTimer({ startedAt }: { startedAt?: string | null }) {
  const [minutes, setMinutes] = useState(0);
  useEffect(() => {
    if (!startedAt) return;
    const update = () => {
      setMinutes(Math.floor((Date.now() - new Date(startedAt).getTime()) / 60_000));
    };
    update();
    const id = setInterval(update, 30_000);
    return () => clearInterval(id);
  }, [startedAt]);
  if (!startedAt) return null;
  const colorClass = minutes < 15 ? 'text-green-400' : minutes < 30 ? 'text-yellow-400' : 'text-red-400';
  return (
    <div className={`flex items-center gap-1.5 text-sm font-medium ${colorClass}`}>
      <Clock className="w-4 h-4" />
      {formatElapsed(minutes)}
    </div>
  );
}

export default function CourierApp() {
  const { user } = useAuth();
  const { socket } = useSocket();
  const [orders, setOrders] = useState<Order[]>([]);
  const [activeOrder, setActiveOrder] = useState<Order | null>(null);
  const [showDailyClose, setShowDailyClose] = useState(false);
  const [dailyStats, setDailyStats] = useState<{ deliveredCount: number; cashTotal: number; cardTotal: number; total: number; totalOrders: number } | null>(null);
  const [loadingDaily, setLoadingDaily] = useState(false);
  const [workFinished, setWorkFinished] = useState(false);

  // ref: stale closure elkerüléséhez — mindig az aktuális activeOrder._id-t tartja
  const activeOrderIdRef = useRef<string | null>(null);

  // activeOrderIdRef szinkronban tartása az állapottal
  useEffect(() => {
    activeOrderIdRef.current = activeOrder?._id ?? null;
  }, [activeOrder]);

  const loadOrders = useCallback(async () => {
    if (!user) return;
    try {
      let fresh: Order[] = [];
      if (user.role === 'admin') {
        const res = await orderApi.getTodayOrders();
        fresh = (Array.isArray(res.data) ? res.data : []).filter(
          (o: Order) => o.status === 'delivering' || o.status === 'ready'
        );
      } else {
        const res = await orderApi.getCourierOrders(user.id);
        fresh = Array.isArray(res.data) ? res.data : [];
      }
      setOrders(fresh);
      // Ha van nyitott rendelés-nézet, frissítsük azt is a DB-ből érkező adattal
      const currentId = activeOrderIdRef.current;
      if (currentId) {
        const updated = fresh.find((o) => o._id === currentId);
        if (updated) setActiveOrder(updated);
        // Ha már nincs a listában (pl. kiszállítva), ne töröljük el — hagyjuk a nézetet
      }
    } catch {
      toast.error('Nem sikerült betölteni a feladatokat');
    }
  }, [user]);

  useEffect(() => {
    if (!user) return;
    loadOrders();
    const interval = setInterval(loadOrders, 10000);
    return () => clearInterval(interval);
  }, [loadOrders]);

  // Socket csatlakoztatás + join_courier (connect + reconnect kezelve)
  useEffect(() => {
    if (!socket || !user) return;

    const doJoin = () => {
      socket.emit('join_courier', user.id);
      console.log('[Futár] join_courier elküldve:', user.id);
    };

    // Azonnal, ha már csatlakozva van
    if (socket.connected) doJoin();
    // Minden (újra)csatlakozáskor
    socket.on('connect', doJoin);

    socket.on('order_status_update', (data: any) => {
      setOrders((prev) => prev.map((o) => (o._id === data.orderId ? { ...o, status: data.status } : o)));
      if (activeOrderIdRef.current === data.orderId) {
        setActiveOrder((prev) => prev ? { ...prev, status: data.status } : prev);
      }
    });

    // Valós idejű értesítés: admin hozzárendelt egy rendelést ehhez a futárhoz
    socket.on('courier_order_assigned', (order: Order) => {
      setOrders((prev) => {
        const exists = prev.find((o) => o._id === order._id);
        if (exists) {
          // Frissítjük ha már szerepel (pl. státusz változás)
          return prev.map((o) => (o._id === order._id ? order : o));
        }
        // Új rendelés az elejére kerül
        return [order, ...prev];
      });
    });

    return () => {
      socket.off('connect', doJoin);
      socket.off('order_status_update');
      socket.off('courier_order_assigned');
    };
  }, [socket, user]);

  const updateCourierStatus = useCallback(async (orderId: string, courierStatus: string, mainStatus?: string) => {
    try {
      const res = await orderApi.updateStatus(orderId, mainStatus || undefined, undefined, courierStatus);
      // Backend válasz alapján frissítjük, hogy megkapjuk a courier_started_at mezőt is
      const updatedOrder = res.data;
      setOrders((prev) => prev.map((o) =>
        o._id === orderId ? updatedOrder : o
      ));
      // activeOrder frissítése — ref alapján, nem stale closure alapján
      if (activeOrderIdRef.current === orderId) {
        setActiveOrder(updatedOrder);
      }
      toast.success('Státusz frissítve');
      if (courierStatus === 'delivered') {
        setActiveOrder(null);
        activeOrderIdRef.current = null;
        loadOrders();
      }
    } catch {
      toast.error('Státusz frissítése sikertelen');
    }
  }, [loadOrders]);

  const loadDailyStats = async () => {
    setLoadingDaily(true);
    try {
      const res = await adminApi.getCourierDaily();
      setDailyStats(res.data);
    } catch {
      toast.error('Napi adatok betöltése sikertelen');
    } finally {
      setLoadingDaily(false);
    }
  };

  // Napi zárás megnyitásakor automatikusan betölt
  useEffect(() => {
    if (showDailyClose) {
      setDailyStats(null);
      loadDailyStats();
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showDailyClose]);

  const handleFinishWork = () => {
    if (socket) {
      socket.emit('courier_finished_work', { courierId: user?.id, courierName: user?.name });
    }
    setWorkFinished(true);
    toast.success('Munka befejezve! Az admin értesítve lett.');
  };

  const handleAction = (order: Order) => {
    const currentCourierStatus = order.courier_status || 'assigned';
    const action = COURIER_STATUS_ACTIONS[currentCourierStatus];
    if (!action) return;
    const mainStatus = action.next === 'delivered' ? 'delivered' : undefined;
    updateCourierStatus(order._id, action.next, mainStatus);
  };

  const handleStop = (order: Order) => {
    // Megállít: vissza accepted-re
    updateCourierStatus(order._id, 'accepted');
  };

  if (activeOrder) {
    const cs = activeOrder.courier_status || 'assigned';
    const nextAction = COURIER_STATUS_ACTIONS[cs];
    const isOnTheWay = cs === 'on_the_way';

    return (
      <div className="min-h-screen bg-muted">
        <header className="bg-background/95 backdrop-blur border-b border-border px-4 py-3">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" onClick={() => { setActiveOrder(null); }} className="text-primary">
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <h1 className="text-lg font-bold text-foreground">Feladat részletei</h1>
          </div>
        </header>

        <main className="max-w-lg mx-auto px-4 py-4 space-y-4">
          <Card className="bg-card border border-border">
            <CardContent className="p-4 space-y-3">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Rendelés</span>
                <span className="text-foreground font-bold">#{activeOrder._id.slice(-4)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Vásárló</span>
                <span className="text-foreground">{typeof activeOrder.user_id === 'object' ? activeOrder.user_id.name : activeOrder.user_id}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Telefon</span>
                <span className="text-foreground flex items-center gap-1">
                  <Phone className="w-3 h-3 text-primary" />
                  {typeof activeOrder.user_id === 'object' ? activeOrder.user_id.phone : ''}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Cím</span>
                <span className="text-foreground text-right max-w-[60%]">
                  {activeOrder.address
                    || (typeof activeOrder.user_id === 'object' ? activeOrder.user_id.default_address : '')
                    || '—'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Összeg</span>
                <span className="text-primary font-bold">{activeOrder.total} Ft</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Fizetés</span>
                <span className="text-foreground">{activeOrder.payment_method}</span>
              </div>
              {/* Futár úton időzítő */}
              {activeOrder.courier_started_at && isOnTheWay && (
                <CourierTimer startedAt={activeOrder.courier_started_at} />
              )}
              {activeOrder.notes && (
                <div className="bg-destructive/10 border border-destructive/30 rounded-lg p-3">
                  <p className="text-destructive font-bold text-center">{activeOrder.notes}</p>
                </div>
              )}
            </CardContent>
          </Card>

          {nextAction && (
            <Button
              className="w-full btn-primary-gradient text-white font-bold text-lg py-6"
              onClick={() => handleAction(activeOrder)}
            >
              {(() => {
                const A = nextAction;
                const Icon = A.icon;
                return <><Icon className="w-5 h-5 mr-2" />{A.label}</>;
              })()}
            </Button>
          )}

          {isOnTheWay && (
            <Button
              variant="outline"
              className="w-full font-bold text-lg py-6 border-2 border-destructive text-destructive hover:bg-destructive/10"
              onClick={() => handleStop(activeOrder)}
            >
              Megállít
            </Button>
          )}
        </main>
      </div>
    );
  }

  // Napi zárás nézet
  if (showDailyClose) {
    return (
      <div className="min-h-screen bg-muted">
        <header className="bg-background/95 backdrop-blur border-b border-border px-4 py-3">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" onClick={() => setShowDailyClose(false)} className="text-primary">
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <h1 className="text-lg font-bold text-foreground">Napi zárás</h1>
          </div>
        </header>
        <main className="max-w-lg mx-auto px-4 py-6 space-y-4">
          {!dailyStats && !loadingDaily && (
            <div className="text-center py-8">
              <TrendingUp className="w-12 h-12 text-primary mx-auto mb-4" />
              <p className="text-foreground font-semibold mb-2">Nem sikerült betölteni az adatokat</p>
              <p className="text-muted-foreground text-sm mb-6">Ellenőrizd a kapcsolatot és próbáld újra</p>
              <Button className="btn-primary-gradient text-white font-semibold px-8" onClick={loadDailyStats}>
                Újra próbálás
              </Button>
            </div>
          )}
          {loadingDaily && (
            <div className="text-center py-12">
              <Loader2 className="w-8 h-8 text-primary mx-auto animate-spin mb-3" />
              <p className="text-muted-foreground">Adatok betöltése...</p>
            </div>
          )}
          {dailyStats && !loadingDaily && (
            <>
              {/* Statisztika kártyák */}
              <Card className="bg-card border border-border">
                <CardContent className="p-5 space-y-4">
                  <div className="flex items-center gap-2 mb-1">
                    <TrendingUp className="w-5 h-5 text-primary" />
                    <h2 className="text-foreground font-bold text-base">Mai teljesítmény</h2>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="bg-secondary rounded-xl p-4 border border-border text-center">
                      <Truck className="w-5 h-5 text-primary mx-auto mb-1" />
                      <p className="text-muted-foreground text-xs">Kiszállítások</p>
                      <p className="text-3xl font-bold text-white mt-1">{dailyStats.deliveredCount}</p>
                      <p className="text-muted-foreground text-xs">teljesítve</p>
                    </div>
                    <div className="bg-secondary rounded-xl p-4 border border-border text-center">
                      <TrendingUp className="w-5 h-5 text-primary mx-auto mb-1" />
                      <p className="text-muted-foreground text-xs">Teljes forgalom</p>
                      <p className="text-2xl font-bold text-primary mt-1">{dailyStats.total.toLocaleString('hu-HU')}</p>
                      <p className="text-muted-foreground text-xs">Ft</p>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="bg-secondary rounded-xl p-4 border border-green-500/20 text-center">
                      <Banknote className="w-5 h-5 text-green-400 mx-auto mb-1" />
                      <p className="text-muted-foreground text-xs">Készpénz</p>
                      <p className="text-xl font-bold text-green-400 mt-1">{dailyStats.cashTotal.toLocaleString('hu-HU')}</p>
                      <p className="text-muted-foreground text-xs">Ft — átadandó</p>
                    </div>
                    <div className="bg-secondary rounded-xl p-4 border border-blue-500/20 text-center">
                      <CreditCard className="w-5 h-5 text-blue-400 mx-auto mb-1" />
                      <p className="text-muted-foreground text-xs">Bankkártya</p>
                      <p className="text-xl font-bold text-blue-400 mt-1">{dailyStats.cardTotal.toLocaleString('hu-HU')}</p>
                      <p className="text-muted-foreground text-xs">Ft — terminál</p>
                    </div>
                  </div>
                  {dailyStats.cashTotal > 0 && (
                    <div className="bg-green-500/10 border border-green-500/30 rounded-xl p-3 text-center">
                      <p className="text-green-400 text-sm font-semibold">
                        Átadandó készpénz: {dailyStats.cashTotal.toLocaleString('hu-HU')} Ft
                      </p>
                      <p className="text-muted-foreground text-xs mt-0.5">Ezt add át a kasszának záráskor!</p>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Munka befejezése */}
              {!workFinished ? (
                <Button
                  className="w-full h-14 text-base font-bold btn-primary-gradient text-white"
                  onClick={handleFinishWork}
                >
                  <LogOut className="w-5 h-5 mr-2" />
                  Munka befejezése — Admin értesítése
                </Button>
              ) : (
                <div className="bg-green-500/10 border border-green-500/40 rounded-xl p-5 text-center">
                  <CheckCircle className="w-10 h-10 text-green-400 mx-auto mb-2" />
                  <p className="text-green-400 font-bold text-lg">Munka befejezve!</p>
                  <p className="text-muted-foreground text-sm mt-1">Az admin értesítést kapott. Jó pihenést!</p>
                </div>
              )}
            </>
          )}
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-muted">
      <header className="bg-background/95 backdrop-blur border-b border-border px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center">
              <Truck className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-foreground">Futár felület</h1>
              <p className="text-xs text-muted-foreground">{user?.name}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="sm"
              className="text-muted-foreground hover:text-foreground border border-border hover:border-primary/40 text-xs"
              onClick={() => { setShowDailyClose(true); loadDailyStats(); }}
            >
              <TrendingUp className="w-3.5 h-3.5 mr-1" />
              Napi zárás
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-lg mx-auto px-4 py-4">
        <h2 className="text-xl font-bold text-white mb-4">Aktív feladatok ({orders.length})</h2>
        {orders.length === 0 ? (
          <div className="text-center py-12">
            <Package className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">Nincs aktív feladat</p>
          </div>
        ) : (
          <div className="space-y-3">
            {orders.map((order) => (
              <Card
                key={order._id}
                className="bg-card border border-border cursor-pointer"
                onClick={() => setActiveOrder(order)}
              >
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-foreground font-bold">#{order._id.slice(-4)}</span>
                    <Badge className="bg-primary/15 text-primary">
                      {order.courier_status ? COURIER_STATUS_LABELS[order.courier_status] : 'Hozzárendelve'}
                    </Badge>
                  </div>
                  <p className="text-muted-foreground text-sm">{typeof order.user_id === 'object' ? order.user_id.name : order.user_id}</p>
                  <p className="text-muted-foreground text-xs flex items-center gap-1 mt-1">
                    <MapPin className="w-3 h-3 text-primary" />
                    {order.address
                      || (typeof order.user_id === 'object' ? order.user_id.default_address : '')
                      || '—'}
                  </p>
                  {order.courier_started_at && order.courier_status === 'on_the_way' && (
                    <div className="mt-1">
                      <CourierTimer startedAt={order.courier_started_at} />
                    </div>
                  )}
                  <p className="text-primary font-bold mt-2">{order.total} Ft</p>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </main>

    </div>
  );
}
