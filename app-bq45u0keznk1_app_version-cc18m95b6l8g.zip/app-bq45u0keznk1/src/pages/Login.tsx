import { useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Mail, Lock, LogIn, AlertCircle, Loader2, Eye, EyeOff, Home } from 'lucide-react';
import { toast } from 'sonner';

const LOGO_URL = '/logo.png';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const { login } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const redirect = searchParams.get('redirect') || '/';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isLoading) return;
    setError('');
    setIsLoading(true);
    try {
      const success = await login(email.trim().toLowerCase(), password);
      if (success) {
        navigate(redirect, { replace: true });
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Ismeretlen hiba történt.';
      setError(msg);
    } finally {
      setIsLoading(false);
    }
  };

  const goToRegister = () => {
    const params = redirect !== '/' ? `?redirect=${encodeURIComponent(redirect)}` : '';
    navigate(`/register${params}`);
  };

  return (
    <div className="theme-restaurant min-h-screen flex bg-background text-foreground">
      {/* Bal oldal - Kép */}
      <div className="hidden lg:flex lg:w-1/2 relative">
        <div className="absolute inset-0 bg-gradient-to-r from-background/40 to-background z-10" />
        <img
          src="https://images.unsplash.com/photo-1568901346375-23c9450c58cd?q=80&w=2000&auto=format&fit=crop"
          alt="Gourmet Burger"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 z-20 flex flex-col justify-end p-12 pb-24">
          <div className="flex items-center gap-4 mb-4">
            <img src={LOGO_URL} alt="Logo" className="h-16 w-auto object-contain drop-shadow-[0_0_12px_rgba(234,90,12,0.6)]" />
            <div>
              <h1 className="text-3xl font-black text-white tracking-wide">Szesztestvérek</h1>
              <p className="text-sm font-bold uppercase tracking-[0.25em] text-primary">Falatház</p>
            </div>
          </div>
          <p className="text-white/80 text-lg max-w-md">Prémium alapanyagok, füstös ízek és utánozhatatlan hangulat. Lépj be és rendeld meg kedvencedet perceken belül!</p>
        </div>
      </div>

      {/* Jobb oldal - Form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-6 sm:p-12 relative">
        
        {/* Vissza a főoldalra gomb mobilon */}
        <div className="absolute top-6 left-6 lg:hidden flex items-center gap-3 cursor-pointer" onClick={() => navigate('/')}>
          <img src={LOGO_URL} alt="Logo" className="h-10 w-auto object-contain" />
        </div>

        <div className="w-full max-w-md space-y-8">
          <div>
            <h2 className="text-3xl font-bold text-white mb-2">Üdv újra!</h2>
            <p className="text-muted-foreground">Jelentkezz be a rendeléshez és a kedvezményekhez.</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="space-y-1.5">
              <Label htmlFor="email" className="text-sm font-medium text-white/80 flex items-center gap-2">
                <Mail className="w-4 h-4 text-primary" /> E-mail cím
              </Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => { setEmail(e.target.value); setError(''); }}
                placeholder="pelda@email.hu"
                autoComplete="email"
                disabled={isLoading}
                required
                className="bg-black/50 border-white/10 focus-visible:ring-primary/50 focus-visible:border-primary text-white placeholder:text-white/30 h-12 rounded-xl"
              />
            </div>
            
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <Label htmlFor="password" className="text-sm font-medium text-white/80 flex items-center gap-2">
                  <Lock className="w-4 h-4 text-primary" /> Jelszó
                </Label>
              </div>
              <div className="relative">
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => { setPassword(e.target.value); setError(''); }}
                  placeholder="••••••••"
                  autoComplete="current-password"
                  disabled={isLoading}
                  required
                  className="bg-black/50 border-white/10 focus-visible:ring-primary/50 focus-visible:border-primary text-white placeholder:text-white/30 h-12 rounded-xl pr-10"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-white/50 hover:text-white/80 transition-colors"
                  tabIndex={-1}
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>

            {error && (
              <div className="flex items-start gap-2 bg-destructive/10 border border-destructive/30 rounded-xl px-4 py-3 text-sm text-destructive">
                <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            <Button
              type="submit"
              disabled={isLoading}
              className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-bold h-12 text-base mt-4 rounded-xl shadow-[0_0_15px_rgba(234,90,12,0.3)] transition-all hover:shadow-[0_0_25px_rgba(234,90,12,0.5)]"
            >
              {isLoading ? (
                <><Loader2 className="w-5 h-5 mr-2 animate-spin" />Kérlek várj...</>
              ) : (
                <><LogIn className="w-5 h-5 mr-2" />Bejelentkezés</>
              )}
            </Button>
            
            <div className="relative my-8">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-white/10"></div>
              </div>
              <div className="relative flex justify-center text-xs">
                <span className="bg-background px-2 text-muted-foreground uppercase tracking-wider">Vagy térj vissza</span>
              </div>
            </div>
            
            <div className="grid grid-cols-1 gap-4">
              <Button type="button" onClick={() => navigate('/')} variant="outline" className="h-12 bg-white/5 border-white/10 hover:bg-white/10 rounded-xl">
                <Home className="w-5 h-5 mr-2" />
                Vissza a főoldalra
              </Button>
            </div>
          </form>

            {/* Demo Credentials */}
            <div className="mt-8 p-4 bg-muted/30 border border-border rounded-xl">
              <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-primary" /> Teszt Fiókok (Kattints a belépéshez)
              </h3>
              <div className="grid gap-2 text-xs">
                <button type="button" onClick={() => { setEmail('superadmin@falathaz.hu'); setPassword('superadmin'); }} className="flex justify-between p-2 rounded hover:bg-muted transition text-left">
                  <span className="font-semibold text-primary">Super Admin</span>
                  <span className="text-muted-foreground font-mono">superadmin@falathaz.hu</span>
                </button>
                <button type="button" onClick={() => { setEmail('admin@teszt1.hu'); setPassword('admin123'); }} className="flex justify-between p-2 rounded hover:bg-muted transition text-left">
                  <span className="font-semibold">Étterem Admin (Teszt 1)</span>
                  <span className="text-muted-foreground font-mono">admin@teszt1.hu</span>
                </button>
                <button type="button" onClick={() => { setEmail('admin@teszt2.hu'); setPassword('admin123'); }} className="flex justify-between p-2 rounded hover:bg-muted transition text-left">
                  <span className="font-semibold">Étterem Admin (Teszt 2)</span>
                  <span className="text-muted-foreground font-mono">admin@teszt2.hu</span>
                </button>
                <button type="button" onClick={() => { setEmail('futar@teszt.hu'); setPassword('futar123'); }} className="flex justify-between p-2 rounded hover:bg-muted transition text-left">
                  <span className="font-semibold">Futár</span>
                  <span className="text-muted-foreground font-mono">futar@teszt.hu</span>
                </button>
                <button type="button" onClick={() => { setEmail('vevo@teszt.hu'); setPassword('vevo123'); }} className="flex justify-between p-2 rounded hover:bg-muted transition text-left">
                  <span className="font-semibold">Vásárló</span>
                  <span className="text-muted-foreground font-mono">vevo@teszt.hu</span>
                </button>
              </div>
            </div>

          <p className="text-center mt-8 text-sm text-muted-foreground">
            Nincs még fiókod?{' '}
            <button
              type="button"
              onClick={goToRegister}
              className="font-semibold text-primary hover:text-primary/80 transition-colors"
            >
              Regisztrálj most!
            </button>
          </p>
        </div>
      </div>
    </div>
  );
}

