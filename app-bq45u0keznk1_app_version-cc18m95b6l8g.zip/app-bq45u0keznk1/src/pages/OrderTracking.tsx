import { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { orderApi } from '@/services/api';
import { useSocket } from '@/contexts/SocketContext';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import type { Order } from '@/types';
import { ArrowLeft, Package, ChefHat, Truck, CheckCircle, Clock, ShoppingBag, MapPin, CreditCard, Banknote } from 'lucide-react';

const STATUS_STEPS = [
  { key: 'pending',    label: 'Feldolgozás', icon: Clock, desc: 'Rendelés rögzítve, várjuk a konyha visszaigazolását.' },
  { key: 'accepted',  label: 'Elfogadva',   icon: CheckCircle, desc: 'A konyha elfogadta a rendelésed, hamarosan készítik.' },
  { key: 'preparing', label: 'Konyhán',     icon: ChefHat, desc: 'Séfjeink megkezdték az ételek elkészítését.' },
  { key: 'ready',     label: 'Kész',        icon: Package, desc: 'Ételek csomagolva, futárra várnak.' },
  { key: 'delivering',label: 'Futárnál',    icon: Truck, desc: 'A futár úton van hozzád az ételekkel.' },
  { key: 'delivered', label: 'Kiszállítva', icon: CheckCircle, desc: 'Rendelésed megérkezett! Jó étvágyat kívánunk!' },
];

const STATUS_MAP: Record<string, string> = {
  pending:    'Feldolgozás alatt',
  accepted:   'Elfogadva',
  preparing:  'Konyhán készül',
  ready:      'Kész, futárra vár',
  delivering: 'Kiszállítás alatt',
  delivered:  'Kiszállítva',
  cancelled:  'Sztornózva',
};

export default function OrderTracking() {
  const { orderId } = useParams();
  const navigate = useNavigate();
  const [order, setOrder] = useState<Order | null>(null);
  const { socket } = useSocket();

  useEffect(() => {
    loadOrder();
    const poll = setInterval(loadOrder, 15000);
    return () => clearInterval(poll);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [orderId]);

  useEffect(() => {
    if (!socket || !orderId) return;
    socket.emit('join_customer', orderId);
    socket.on('order_status_update', (data: any) => {
      if (data.orderId === orderId) {
        setOrder((prev) => prev ? { ...prev, status: data.status } : prev);
        toast.info(`Rendelés státusza: ${STATUS_MAP[data.status] || data.status}`);
      }
    });
    return () => {
      socket.off('order_status_update');
    };
  }, [socket, orderId]);

  const loadOrder = async () => {
    try {
      const res = await orderApi.getById(orderId!);
      setOrder(res.data);
    } catch {
      toast.error('Nem sikerült betölteni a rendelést');
    }
  };

  // Audio lejátszó a státuszváltáshoz
  const audioRef = useRef<HTMLAudioElement | null>(null);
  
  useEffect(() => {
    // Inicializáljuk a hangot, ha még nincs
    if (!audioRef.current) {
      audioRef.current = new Audio('/notification.mp3');
      audioRef.current.volume = 0.5;
    }
    
    // Ha változik a státusz és nem ez az első betöltés (a component mountkor már lefutna)
    if (order && order.status !== 'pending' && audioRef.current) {
      audioRef.current.play().catch(err => console.log('Audio lejátszás blokkolva a böngésző által', err));
    }
  }, [order?.status]);

  if (!order) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-primary animate-pulse" />
          <p className="text-muted-foreground text-sm">Betöltés...</p>
        </div>
      </div>
    );
  }

  const currentStepIndex = STATUS_STEPS.findIndex((s) => s.key === order.status);

  return (
    <div className="theme-restaurant min-h-screen bg-background text-foreground">
      <header className="bg-card/80 backdrop-blur border-b border-white/10 px-4 py-4 sticky top-0 z-50">
        <div className="max-w-xl mx-auto flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => navigate('/')} className="text-muted-foreground hover:text-white rounded-full hover:bg-white/5">
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-xl font-bold text-white tracking-tight">Rendelés állapota</h1>
        </div>
      </header>

      <main className="max-w-xl mx-auto px-4 py-8 space-y-8">
        {/* Státusz kártya idővonallal (Függőleges) */}
        <Card className="bg-card border border-white/5 rounded-2xl shadow-xl overflow-hidden">
          <div className="bg-white/5 px-6 py-5 flex items-center justify-between border-b border-white/10">
            <div>
              <p className="text-xs font-bold text-primary tracking-wider uppercase mb-1">Rendelés azonosító</p>
              <h2 className="text-xl font-black text-white">#{order._id.slice(-6).toUpperCase()}</h2>
            </div>
            <div className="text-right">
              <p className="text-xs text-muted-foreground mb-1">Leadva</p>
              <p className="text-sm font-medium text-white">{new Date(order.createdAt).toLocaleTimeString('hu-HU', {hour: '2-digit', minute:'2-digit'})}</p>
            </div>
          </div>

          <CardContent className="p-8">
            {order.status !== 'cancelled' ? (
              <div className="relative pl-6 space-y-10">
                {/* Függőleges vonal a háttérben */}
                <div className="absolute left-[31px] top-6 bottom-6 w-0.5 bg-white/10 rounded-full" />
                
                {/* Színes folyamatvonal */}
                <div 
                  className="absolute left-[31px] top-6 w-0.5 bg-primary rounded-full transition-all duration-700 shadow-[0_0_8px_rgba(234,90,12,0.6)]" 
                  style={{ height: currentStepIndex > 0 ? `calc(${Math.min(currentStepIndex / (STATUS_STEPS.length - 1), 1) * 100}% - 48px)` : '0' }}
                />

                {STATUS_STEPS.map((step, idx) => {
                  const Icon = step.icon;
                  const isCompleted = idx <= currentStepIndex;
                  const isCurrent = idx === currentStepIndex;
                  
                  return (
                    <div key={step.key} className="relative z-10 flex gap-6 items-start group">
                      <div className={`mt-1 shrink-0 w-10 h-10 rounded-full flex items-center justify-center transition-all duration-500 border-2 ${
                        isCurrent
                          ? 'bg-primary border-primary text-primary-foreground shadow-[0_0_20px_rgba(234,90,12,0.4)] scale-110'
                          : isCompleted
                            ? 'bg-primary/20 border-primary text-primary'
                            : 'bg-[#111111] border-white/10 text-white/20'
                      }`}>
                        <Icon className={`w-5 h-5 ${isCurrent ? 'animate-pulse' : ''}`} />
                      </div>
                      <div className={`flex flex-col mt-0.5 transition-all duration-300 ${isCompleted ? 'opacity-100' : 'opacity-40'}`}>
                        <h3 className={`text-lg font-bold mb-1 ${isCurrent ? 'text-primary' : 'text-white'}`}>
                          {step.label}
                        </h3>
                        <p className="text-sm text-muted-foreground text-pretty leading-relaxed">
                          {step.desc}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="bg-destructive/10 border border-destructive/30 rounded-xl p-6 text-center">
                <div className="w-16 h-16 rounded-full bg-destructive/20 text-destructive flex items-center justify-center mx-auto mb-4">
                  <span className="text-3xl">✕</span>
                </div>
                <h3 className="text-xl font-bold text-white mb-2">Rendelés törölve</h3>
                <p className="text-destructive font-medium">Ezt a rendelést sajnos sztornózták.</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Rendelés részletei */}
        <Card className="bg-card border border-white/5 rounded-2xl shadow-xl overflow-hidden">
          <div className="bg-white/5 px-6 py-4 border-b border-white/10 flex items-center gap-3">
            <ShoppingBag className="w-5 h-5 text-primary" />
            <h3 className="text-lg font-bold text-white">Rendelés részletei</h3>
          </div>
          <CardContent className="p-0">
            <div className="divide-y divide-white/5">
              {order.items.map((item, i) => (
                <div key={i} className="px-6 py-4 flex justify-between items-center group hover:bg-white/[0.02] transition-colors">
                  <div className="flex items-center gap-4">
                    <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center text-primary font-bold text-sm shrink-0">
                      {item.quantity}x
                    </div>
                    <div>
                      <span className="text-white font-medium block">{item.name}</span>
                      {item.extras && item.extras.length > 0 && (
                        <span className="text-xs text-muted-foreground block mt-1">
                          + {item.extras.map((e: any) => e.name).join(', ')}
                        </span>
                      )}
                    </div>
                  </div>
                  <span className="text-white font-bold whitespace-nowrap">{(item.price * item.quantity).toLocaleString('hu-HU')} Ft</span>
                </div>
              ))}
            </div>
            
            <div className="bg-[#0c0a07] px-6 py-5 border-t border-white/10 space-y-3 text-sm">
              <div className="flex justify-between text-muted-foreground font-medium">
                <span>Részösszeg</span><span>{order.subtotal?.toLocaleString('hu-HU') || 0} Ft</span>
              </div>
              {order.packaging_total > 0 && (
                <div className="flex justify-between text-muted-foreground font-medium">
                  <span>Csomagolási díj</span><span>{order.packaging_total?.toLocaleString('hu-HU') || 0} Ft</span>
                </div>
              )}
              {order.drs_total > 0 && (
                <div className="flex justify-between text-muted-foreground font-medium">
                  <span>DRS díj</span><span>{order.drs_total?.toLocaleString('hu-HU') || 0} Ft</span>
                </div>
              )}
              <div className="flex justify-between text-muted-foreground font-medium">
                <span>Szállítási díj</span><span>{order.delivery_fee === 0 ? 'Ingyenes' : `${order.delivery_fee?.toLocaleString('hu-HU')} Ft`}</span>
              </div>
              
              <div className="flex justify-between text-white font-black text-xl pt-4 border-t border-white/10 mt-2">
                <span>Fizetendő</span>
                <span className="text-primary">{order.total?.toLocaleString('hu-HU') || 0} Ft</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Cím és fizetési mód */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Card className="bg-card border border-white/5 rounded-2xl overflow-hidden">
            <CardContent className="p-5 flex items-start gap-4">
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                <MapPin className="w-5 h-5 text-primary" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-white mb-1">Szállítási cím</h4>
                <p className="text-sm text-muted-foreground leading-relaxed">{order.address}</p>
                {order.notes && (
                  <p className="text-xs text-primary mt-2 font-medium bg-primary/10 p-2 rounded border border-primary/20">
                    Megjegyzés: {order.notes}
                  </p>
                )}
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-card border border-white/5 rounded-2xl overflow-hidden">
            <CardContent className="p-5 flex items-start gap-4">
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                {order.payment_method === 'Készpénz' ? <Banknote className="w-5 h-5 text-primary" /> : <CreditCard className="w-5 h-5 text-primary" />}
              </div>
              <div>
                <h4 className="text-sm font-bold text-white mb-1">Fizetési mód</h4>
                <p className="text-sm text-muted-foreground">{order.payment_method}</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Upsell / Következő rendelés ajánló */}
        <div className="pt-6 border-t border-white/5">
          <h3 className="text-lg font-bold text-white mb-4 text-center">Népszerű ételeink</h3>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-card border border-white/5 rounded-2xl overflow-hidden group cursor-pointer" onClick={() => navigate('/menu')}>
              <div className="aspect-[4/3] bg-muted relative overflow-hidden">
                <img src="https://images.unsplash.com/photo-1568901346375-23c9450c58cd?q=80&w=600&auto=format&fit=crop" alt="Burger" className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex items-end p-3">
                  <span className="text-white font-bold text-sm">Gourmet Burger</span>
                </div>
              </div>
            </div>
            <div className="bg-card border border-white/5 rounded-2xl overflow-hidden group cursor-pointer" onClick={() => navigate('/menu')}>
              <div className="aspect-[4/3] bg-muted relative overflow-hidden">
                <img src="https://images.unsplash.com/photo-1513104890138-7c749659a591?q=80&w=600&auto=format&fit=crop" alt="Pizza" className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex items-end p-3">
                  <span className="text-white font-bold text-sm">Prémium Pizza</span>
                </div>
              </div>
            </div>
          </div>
        </div>

      </main>
    </div>
  );
}
