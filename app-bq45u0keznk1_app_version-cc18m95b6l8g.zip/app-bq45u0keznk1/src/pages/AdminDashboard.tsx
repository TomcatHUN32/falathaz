import { useParams } from 'react-router-dom';
import { useState, useEffect, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { orderApi, productApi, adminApi, settingsApi, authApi, toppingApi, couponApi, restaurantApi } from '@/services/api';
import { useSocket } from '@/contexts/SocketContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Sheet, SheetContent, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import { toast } from 'sonner';
import type { Order, Product, Stats, User, ToppingGroup, Coupon } from '@/types';
import DailyReportPDF from '@/components/DailyReportPDF';
import OrderDetailModal from '@/components/OrderDetailModal';
import OrderRow from '@/components/OrderRow';
import CrmPosPanel from '@/components/CrmPosPanel';
import CourierDispatchPanel from '@/components/CourierDispatchPanel';
import LoyaltySettingsManager from '@/components/admin/LoyaltySettingsManager';
import OrdersTab from '@/components/admin/OrdersTab';
import CityManager from '@/components/CityManager';
import NapiZaras from '@/components/NapiZaras';
import FutarZaras from '@/components/FutarZaras';
import AdminProDashboard from '@/components/admin/AdminProDashboard';

import {
  ChefHat, Bell, CheckCircle, Printer, Package, Truck, Clock,
  BarChart3, Settings, Users, Plus, Trash2, Edit2, Volume2, VolumeX,
  Phone, MapPin, Search, Tag, Check, ChevronUp, ChevronDown, UtensilsCrossed, X,
  ImageIcon, Upload, Loader2, Banknote, CreditCard, TrendingUp, Menu, LogOut, Home, Monitor,
  Pizza, Utensils, Coffee, Cake, Flame, Salad, Beef, IceCream, Beer, Wine, Apple, Fish, Carrot, Croissant
} from 'lucide-react';
import {
  DropdownMenu, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuItem
} from '@/components/ui/dropdown-menu';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, ResponsiveContainer,
  LineChart, Line, PieChart, Pie, Cell
} from 'recharts';

const STATUS_LABELS: Record<string, string> = {
  pending: 'Várakozik',
  accepted: 'Elfogadva',
  preparing: 'Konyhán',
  ready: 'Kész',
  delivering: 'Kiszállítás alatt',
  delivered: 'Kiszállítva',
  cancelled: 'Sztornózva',
};

const STATUS_COLORS: Record<string, string> = {
  pending: 'bg-yellow-600',
  accepted: 'bg-blue-600',
  preparing: 'bg-primary',
  ready: 'bg-purple-600',
  delivering: 'bg-green-600',
  delivered: 'bg-gray-600',
  cancelled: 'bg-red-700',
};

const CHART_COLORS = ['#e73423', '#b91c1c', '#d97706', '#16a34a', '#2563eb', '#9333ea'];

// Null-biztos helper-ek a populate-elt user_id kezeléséhez
// (typeof null === 'object' JS quirk → explicit null check szükséges)
function getUserName(userId: Order['user_id'] | null | undefined, fallback = 'Ismeretlen'): string {
  if (!userId || typeof userId !== 'object') return fallback;
  return (userId as User).name || fallback;
}
function getUserPhone(userId: Order['user_id'] | null | undefined): string {
  if (!userId || typeof userId !== 'object') return '';
  return (userId as User).phone || '';
}

function getDisplayName(order: Order): string {
  if (order.delivery_type === 'elvitel') return 'Elvitel';
  if (order.delivery_type === 'beülős') return 'Beülős';
  return order.guest_name || getUserName(order.user_id);
}

// Rendelés kora alapján border-szín meghatározása
function getOrderAgeBorderClass(createdAt: string, status?: string): string {
  if (status === 'delivered' || status === 'cancelled') return 'border-border opacity-50';
  const ageMin = (Date.now() - new Date(createdAt).getTime()) / 60_000;
  if (ageMin < 30) return 'border-green-500';
  if (ageMin < 60) return 'border-yellow-400';
  return 'border-red-500';
}

// Rendelés kora: rövid szöveges jelzés (delivered: null)
function getOrderAgeLabel(createdAt: string, status?: string): { label: string; cls: string } | null {
  if (status === 'delivered' || status === 'cancelled') return null;
  const ageMin = Math.floor((Date.now() - new Date(createdAt).getTime()) / 60_000);
  if (ageMin < 1) return { label: 'Most érkezett', cls: 'text-green-400' };
  if (ageMin < 30) return { label: `${ageMin} perce`, cls: 'text-green-400' };
  if (ageMin < 60) return { label: `${ageMin} perce`, cls: 'text-yellow-400' };
  return { label: `${ageMin} perce`, cls: 'text-red-400' };
}

export default function AdminDashboard() {
  const navigate = useNavigate();
  const { logout } = useAuth();
  const [activeTab, setActiveTab] = useState('overview');
  const [selectedOrderId, setSelectedOrderId] = useState<string | null>(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [orders, setOrders] = useState<Order[]>([]);
  const { restaurantId } = useParams<{ restaurantId: string }>();
  const [restaurant, setRestaurant] = useState<any>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [stats, setStats] = useState<Stats | null>(null);
  const [couriers, setCouriers] = useState<User[]>([]);
  // Szűrő státuszok a RENDELÉSEK tabhoz
  const [orderTypeFilter, setOrderTypeFilter] = useState<'all' | 'dine_in' | 'delivery' | 'pickup'>('all');
  const [filterCourier, setFilterCourier] = useState('');
  const [filterOrderNum, setFilterOrderNum] = useState('');
  const [filterName, setFilterName] = useState('');
  const [filterStreet, setFilterStreet] = useState('');
  const [lastOrderTime, setLastOrderTime] = useState(Date.now());
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [manualOverride, setManualOverride] = useState(true);
  const [openingHours, setOpeningHours] = useState<any>({});
  // forceManual: true = manuálisan lett beállítva, az auto-schedule nem írja felül
  const [forceManual, setForceManual] = useState(false);
  const [crmKey, setCrmKey] = useState(0); // CRM panel reset kulcs
  const [now, setNow] = useState(() => Date.now());
  const [categories, setCategories] = useState<string[]>(['Házias ételek', 'Sültek', 'Italok']);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [toppingGroups, setToppingGroups] = useState<ToppingGroup[]>([]);
  const [coupons, setCoupons] = useState<Coupon[]>([]);
  const [couponForm, setCouponForm] = useState({ name: '', code: '', discount_pct: 0, max_uses: 0 });
  const [editingCoupon, setEditingCoupon] = useState<string | null>(null);
  const [courierForm, setCourierForm] = useState({ name: '', email: '', phone: '', password: '' });
  const [editingCourier, setEditingCourier] = useState<string | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const { socket } = useSocket();

  const alarmIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Rendelés jelzés: Hangosabb, egyedi "Konyhai Csengő" (Kitchen Bell)
  const playBeep = useCallback(() => {
    try {
      const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const t = ctx.currentTime;

      const ding = (when: number, freq: number, dur: number) => {
        const osc = ctx.createOscillator();
        const g = ctx.createGain();
        osc.connect(g); g.connect(ctx.destination);
        
        // Gazdagabb hangszín (sine és triangle keveréke kellemesebb, de a square hangosabb)
        osc.type = 'triangle';
        osc.frequency.value = freq;
        
        // Erős kezdés, majd finom elhalás (harang/csengő szerű)
        g.gain.setValueAtTime(0, when);
        g.gain.linearRampToValueAtTime(1.0, when + 0.02); // Nagyon hangos (1.0)
        g.gain.exponentialRampToValueAtTime(0.01, when + dur);
        
        osc.start(when);
        osc.stop(when + dur);
      };

      // DING - DONG - DING (Éttermi felhívó dallam)
      ding(t, 880.00, 0.6);        // A5
      ding(t + 0.25, 659.25, 0.8); // E5
      ding(t + 0.6, 1046.50, 1.2); // C6 (hosszan kitartva)
      
      // Második réteg a csengő-hatásért (magasabb felhangok)
      const ring = (when: number, freq: number, dur: number) => {
        const osc = ctx.createOscillator();
        const g = ctx.createGain();
        osc.connect(g); g.connect(ctx.destination);
        osc.type = 'sine';
        osc.frequency.value = freq;
        g.gain.setValueAtTime(0.3, when);
        g.gain.exponentialRampToValueAtTime(0.01, when + dur);
        osc.start(when);
        osc.stop(when + dur);
      };
      
      ring(t, 1760, 0.6);
      ring(t + 0.25, 1318.5, 0.8);
      ring(t + 0.6, 2093, 1.2);

    } catch {}
  }, []);

  const startAlarm = useCallback(() => {
    if (!soundEnabled || alarmIntervalRef.current) return;
    playBeep();
    alarmIntervalRef.current = setInterval(playBeep, 4000);
  }, [soundEnabled, playBeep]);

  const stopAlarm = useCallback(() => {
    if (alarmIntervalRef.current) {
      clearInterval(alarmIntervalRef.current);
      alarmIntervalRef.current = null;
    }
  }, []);

  // Percenkénti újrarenderelés az időalapú színkódoláshoz
  useEffect(() => {
    const timer = setInterval(() => setNow(Date.now()), 30_000);
    return () => clearInterval(timer);
  }, []);

  // Auto-schedule: a backend végzi (server.js startAutoSchedule),
  // az admin frontend csak figyeli a socket eseményt és szinkronizálja az UI-t
  useEffect(() => {
    if (!socket) return;
    const handleAutoChanged = (data: { is_open: boolean; auto: boolean; reason?: string }) => {
      setManualOverride(data.is_open);
      if (data.auto) setForceManual(false);
      toast.info(
        data.is_open
          ? '🟢 Automata nyitás (nyitvatartási idő kezdete)'
          : '🔴 Automata zárás (nyitvatartási idő vége)',
        { duration: 4000 }
      );
    };
    socket.on('auto_open_changed', handleAutoChanged);
    return () => { socket.off('auto_open_changed', handleAutoChanged); };
  }, [socket]);

  useEffect(() => {
    loadData();
    loadStatsData(statsFromDate, statsToDate);
    loadSettings();
    loadToppings();
    loadRestaurant();
    loadCoupons();
    const interval = setInterval(() => {
      loadData();
      if (activeTab === 'coupons') loadCoupons();
    }, 30000);
    return () => clearInterval(interval);
  }, [activeTab]);

  useEffect(() => {
    if (!socket) return;
    socket.emit('join_admin');
    socket.on('new_order', (order: Order) => {
      setOrders((prev) => [order, ...prev]);
      setLastOrderTime(Date.now());
      startAlarm();
      toast.info(`Új rendelés érkezett! #${order._id.slice(-4)}`);
    });
    socket.on('courier_finished_work', (data: any) => {
      toast.success(`🏁 ${data.courierName ?? 'Futár'} befejezte a napi munkát!`, { duration: 8000 });
    });

    socket.on('order_status_update', (data: any) => {
      setOrders((prev) =>
        prev.map((o) => (o._id === data.orderId ? { ...o, status: data.status } : o))
      );
    });
    return () => {
      socket.off('new_order');
      socket.off('order_status_update');
      socket.off('courier_finished_work');
    };
  }, [socket, startAlarm]);

  const todayStr = new Date().toISOString().slice(0, 10);
  const [closeFromDate, setCloseFromDate] = useState(todayStr);
  const [closeToDate, setCloseToDate] = useState(todayStr);
  const [closeOrders, setCloseOrders] = useState<Order[]>([]);

  const [statsFromDate, setStatsFromDate] = useState(todayStr);
  const [statsToDate, setStatsToDate] = useState(todayStr);

  const loadStatsData = async (from: string, to: string) => {
    try {
      const res = await adminApi.getStats(from, to);
      setStats(res.data);
    } catch {
      toast.error('Statisztika betöltése sikertelen');
    }
  };

  const loadCloseData = async (from: string, to: string) => {
    try {
      const res = await orderApi.getAllOrders(from, to);
      setCloseOrders(Array.isArray(res.data) ? res.data : []);
    } catch {
      toast.error('Adatok betöltése sikertelen');
    }
  };

  const loadData = async () => {
    try {
      const [ordersRes, productsRes, couriersRes] = await Promise.all([
        orderApi.getTodayOrders(),
        productApi.getAll(true), // admin: minden termék (is_available is false is)
        adminApi.getCouriers(),
      ]);
      setOrders(ordersRes.data);
      setProducts(productsRes.data);
      setCouriers(couriersRes.data);
    } catch {
      toast.error('Adatok betöltése sikertelen');
    }
  };

  const loadToppings = async () => {
    try {
      const res = await toppingApi.getAll();
      setToppingGroups(Array.isArray(res.data) ? res.data : []);
    } catch {}
  };

  const loadCoupons = async () => {
    try {
      const res = await couponApi.getAll();
      setCoupons(Array.isArray(res.data) ? res.data : []);
    } catch {}
  };

  
  const loadRestaurant = async () => {
    try {
      if (restaurantId) {
        const res = await restaurantApi.getById(restaurantId);
        setRestaurant(res.data);
      }
    } catch {}
  };

  const loadSettings = async () => {
    try {
      const res = await settingsApi.getAll();
      setManualOverride(res.data.manual_override?.is_open ?? true);
      setForceManual(res.data.manual_override?.force_manual ?? false);
      setOpeningHours(res.data.opening_hours || {});
      if (res.data.categories && Array.isArray(res.data.categories)) {
        setCategories(res.data.categories);
      }
    } catch {}
  };

  const updateStatus = async (orderId: string, status: string, courierId?: string | null, courierStatus?: string | null) => {
    try {
      const autoCourierStatus = courierStatus !== undefined ? courierStatus : (status === 'delivering' ? 'assigned' : undefined);
      await orderApi.updateStatus(orderId, status, courierId, autoCourierStatus);
      setOrders((prev) =>
        prev.map((o) => (o._id === orderId ? { ...o, status: status as any, ...(autoCourierStatus !== undefined ? { courier_status: autoCourierStatus as any } : {}), ...(courierId !== undefined ? { courier_id: courierId } : {}) } : o))
      );
      if (selectedOrder?._id === orderId) {
        setSelectedOrder((prev) => prev ? { ...prev, status: status as any, ...(autoCourierStatus !== undefined ? { courier_status: autoCourierStatus as any } : {}), ...(courierId !== undefined ? { courier_id: courierId } : {}) } : prev);
      }
      toast.success(`Státusz frissítve: ${STATUS_LABELS[status]}`);
    } catch {
      toast.error('Státusz frissítése sikertelen');
    }
  };

  const handleAcceptOrder = (order: Order) => {
    updateStatus(order._id, 'accepted');
    stopAlarm();
  };

  // CRM: rendelés sikeresen felvéve — panel reset + automatikus nyomtatás
  const handleCrmOrderCreated = (order: Order) => {
    setCrmKey((k) => k + 1);
    loadData();
    handlePrint(order);
  };

  const handleOrderUpdated = (updated: Order) => {
    setOrders(prev => prev.map(o => o._id === updated._id ? updated : o));
    setSelectedOrder(updated);
  };

  const handleSaveProduct = async (product: Partial<Product>) => {    try {
      if (product._id) {
        await productApi.update(product._id, product);
        toast.success('Termék frissítve');
      } else {
        await productApi.create(product);
        toast.success('Termék hozzáadva');
      }
      loadData();
    } catch (error: any) {
      console.error('Product save error:', error);
      toast.error('Mentés sikertelen: ' + (error?.response?.data?.error || error.message));
    }
  };

  const handleToggleAvailability = async (id: string, val: boolean) => {
    try {
      const res = await productApi.toggleAvailability(id, val);
      setProducts((prev) => prev.map((p) => p._id === id ? { ...p, is_available: res.data.is_available } : p));
      toast.success(val ? 'Termék elérhetővé téve' : 'Termék visszavonva az étlapról');
    } catch {
      toast.error('Elérhetőség módosítása sikertelen');
    }
  };

  const handleDeleteProduct = async (id: string) => {
    if (!confirm('Biztosan törli ezt a terméket?')) return;
    try {
      await productApi.delete(id);
      toast.success('Termék törölve');
      loadData();
    } catch {
      toast.error('Törlés sikertelen');
    }
  };

  const handleToggleManual = async () => {
    try {
      const newVal = !manualOverride;
      // force_manual=true: manuális beállítás, az auto-schedule ne írja felül
      await settingsApi.update('manual_override', { is_open: newVal, force_manual: true });
      setManualOverride(newVal);
      setForceManual(true);
      toast.success(newVal ? 'Étterem manuálisan kinyitva (auto-schedule szünetel)' : 'Étterem manuálisan lezárva (auto-schedule szünetel)');
    } catch {
      toast.error('Művelet sikertelen');
    }
  };

  const handleResetAuto = async () => {
    try {
      // Töröljük a manuális felülírást — az auto-schedule átveszi az irányítást
      await settingsApi.update('manual_override', { is_open: manualOverride, force_manual: false });
      setForceManual(false);
      toast.success('Automatikus ütemezés visszaállítva — a nyitvatartási idők alapján fog nyitni/zárni');
    } catch {
      toast.error('Visszaállítás sikertelen');
    }
  };

  const handleSaveHours = async () => {
    try {
      await settingsApi.update('opening_hours', openingHours);
      toast.success('Nyitvatartás mentve');
    } catch {
      toast.error('Mentés sikertelen');
    }
  };

  const handlePrint = (order: Order) => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) { toast.error('Engedélyezd a felugró ablakokat a nyomtatáshoz!'); return; }
    const logoUrl = window.location.origin + '/logo.png';
    const dateStr = new Date().toLocaleString('hu-HU');
    const orderNum = order._id.slice(-4);
    const deliveryLabel = order.delivery_type === 'szállítás' ? '&#x1F6F5; Kiszállítás' : '&#x1F961; Elvitel';
    const guestName = order.guest_name || (typeof order.user_id === 'object' && order.user_id !== null ? (order.user_id as User).name : '');
    const itemsHtml = order.items.map((item) => {
      const extrasHtml = (item.extras || []).length > 0
        ? `<div class="item-extra">+ ${(item.extras || []).map((e: {option_name: string}) => e.option_name).join(', ')}</div>`
        : '';
      const noteHtml = item.note ? `<div class="item-extra" style="color:#d9534f;font-weight:bold;margin-top:2px;">(Megj: ${item.note})</div>` : '';
      return `<div>
        <div class="item-row">
          <span class="item-name">${item.name}</span>
          <span class="item-qty">&times;${item.quantity}</span>
          <span class="item-price">${(item.price * item.quantity).toLocaleString('hu-HU')} Ft</span>
        </div>${extrasHtml}${noteHtml}</div>`;
    }).join('');
    const infoRows = [
      guestName ? `<div class="info-row"><b>Név:</b> ${guestName}</div>` : '',
      order.address ? `<div class="info-row"><b>Cím:</b> ${order.address}</div>` : '',
    ].filter(Boolean).join('');
    const feeRows = [
      `<div class="fee-row"><span>Részösszeg:</span><span>${order.subtotal.toLocaleString('hu-HU')} Ft</span></div>`,
      order.packaging_total > 0 ? `<div class="fee-row"><span>Csomagolás:</span><span>${order.packaging_total.toLocaleString('hu-HU')} Ft</span></div>` : '',
      order.drs_total > 0 ? `<div class="fee-row"><span>DRS betétdíj:</span><span>${order.drs_total.toLocaleString('hu-HU')} Ft</span></div>` : '',
      order.delivery_type === 'szállítás' && order.delivery_fee > 0 ? `<div class="fee-row"><span>Szállítás:</span><span>${order.delivery_fee.toLocaleString('hu-HU')} Ft</span></div>` : '',
    ].filter(Boolean).join('');
    const notesHtml = order.notes ? `<div class="notes-box">&#9888;&#65039; ${order.notes}</div>` : '';
    printWindow.document.write(`<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Szesztestvérek Falatház – Blokk</title>
      <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'Helvetica Neue', Arial, sans-serif; width: 80mm; margin: 0 auto; background: #fff; color: #111; padding: 6mm 7mm 10mm; }
        .receipt-header { text-align: center; padding-bottom: 8px; border-bottom: 2px solid #111; margin-bottom: 10px; }
        .logo { width: 44mm; height: 44mm; object-fit: contain; margin-bottom: 2px; }
        .order-num { font-size: 30px; font-weight: 700; text-align: center; margin: 8px 0 4px; letter-spacing: 1px; }
        .order-type-badge { display: block; font-size: 10px; font-weight: 600; text-transform: uppercase; letter-spacing: 1.5px; text-align: center; margin-bottom: 2px; }
        .datetime { font-size: 10px; color: #666; text-align: center; margin-bottom: 8px; }
        .section-label { font-size: 9px; font-weight: 700; text-transform: uppercase; letter-spacing: 1.5px; color: #999; margin: 8px 0 3px; }
        .info-row { font-size: 12px; margin-bottom: 3px; }
        .info-row b { font-weight: 600; }
        .divider { border: none; border-top: 1px dashed #bbb; margin: 7px 0; }
        .divider-solid { border: none; border-top: 1.5px solid #111; margin: 7px 0; }
        .item-row { display: flex; justify-content: space-between; align-items: flex-start; font-size: 12px; margin-bottom: 5px; gap: 4px; }
        .item-name { flex: 1; font-weight: 600; }
        .item-qty { font-size: 10px; color: #666; min-width: 20px; text-align: center; background: #f0f0f0; border-radius: 3px; padding: 0 3px; margin-top: 1px; }
        .item-price { font-weight: 600; white-space: nowrap; }
        .item-extra { font-size: 10px; color: #777; padding-left: 6px; margin-bottom: 3px; }
        .fee-row { display: flex; justify-content: space-between; font-size: 11px; color: #555; margin: 2px 0; }
        .total-row { display: flex; justify-content: space-between; font-size: 16px; font-weight: 700; margin-top: 5px; }
        .payment-badge { display: inline-block; font-size: 11px; font-weight: 600; background: #f0f0f0; border-radius: 4px; padding: 2px 8px; margin-top: 5px; }
        .notes-box { font-size: 13px; font-weight: 700; text-align: center; color: #c00; margin: 10px 0; border: 2px solid #c00; border-radius: 5px; padding: 7px 10px; line-height: 1.4; }
        .receipt-footer { text-align: center; margin-top: 12px; padding-top: 8px; border-top: 1px dashed #bbb; }
        .footer-main { font-size: 12px; font-weight: 700; margin-bottom: 2px; }
        .footer-sub { font-size: 9px; color: #888; letter-spacing: 0.5px; }
      </style></head><body>
      <div class="receipt-header">
        <img src="${logoUrl}" class="logo" alt="Szestestvérek Falatház" onload="window.print()" onerror="window.print()" />
      </div>
      <div class="order-num">#${orderNum}</div>
      <div class="order-type-badge">${deliveryLabel}</div>
      <div class="datetime">${dateStr}</div>
      ${infoRows ? `<hr class="divider"><div class="section-label">Ügyfél</div>${infoRows}` : ''}
      <hr class="divider">
      <div class="section-label">Rendelés</div>
      ${itemsHtml}
      <hr class="divider">
      ${feeRows}
      <hr class="divider-solid">
      <div class="total-row"><span>Fizetendő:</span><span>${order.total.toLocaleString('hu-HU')} Ft</span></div>
      <div><span class="payment-badge">&#x1F4B3; ${order.payment_method}</span></div>
      ${notesHtml}
      <div class="receipt-footer">
        <div class="footer-main">Köszönjük a rendelését! &#x1F354;</div>
        <div class="footer-sub">szesztestvérek falatház</div>
      </div>
    </body></html>`);
    printWindow.document.close();
  };

  const pendingOrders = orders.filter((o) => o.status === 'pending');

  // Szűrt rendelések lista
  const filteredOrders = orders.filter((o) => {
    if (orderTypeFilter === 'dine_in' && (o.delivery_type as string) !== 'beülős') return false;
    if (orderTypeFilter === 'delivery' && ((o.delivery_type as string) === 'elvitel' || (o.delivery_type as string) === 'beülős')) return false;
    if (orderTypeFilter === 'pickup' && o.delivery_type !== 'elvitel') return false;
    if (filterOrderNum && !String(o.order_number ?? '').includes(filterOrderNum)) return false;
    if (filterName) {
      const name = (o.guest_name || getUserName(o.user_id)).toLowerCase();
      if (!name.includes(filterName.toLowerCase())) return false;
    }
    if (filterStreet && !(o.address ?? '').toLowerCase().includes(filterStreet.toLowerCase())) return false;
    if (filterCourier) {
      const cid = typeof o.courier_id === 'object' && o.courier_id ? (o.courier_id as any)._id : o.courier_id;
      const c = couriers.find((x) => x.id === cid);
      if (!c || !c.name.toLowerCase().includes(filterCourier.toLowerCase())) return false;
    }
    return true;
  });

  useEffect(() => {
    if (pendingOrders.length > 0 && soundEnabled) {
      startAlarm();
    } else {
      stopAlarm();
    }
    return () => { stopAlarm(); };
  }, [pendingOrders.length, soundEnabled, startAlarm, stopAlarm]);

  const isPro = activeTab === 'overview';
  const daysLeft = restaurant?.license_expiry ? Math.ceil((new Date(restaurant.license_expiry).getTime() - Date.now()) / (1000 * 60 * 60 * 24)) : 0;
  
  return (
    <div className={`h-screen flex flex-col overflow-hidden ${isPro ? 'bg-[#1b1f24] text-gray-200' : 'admin-light bg-[#eef1f4] text-foreground'}`}>
      {/* ── Top Header ── */}
      <header className={`shrink-0 flex items-center justify-between px-4 py-2 z-10 shadow-sm h-16 ${isPro ? 'bg-[#22272d] border-b border-[#30363d]' : 'bg-white border-b border-border'}`}>
        <div className="flex items-center gap-2">
          <Sheet open={isSidebarOpen} onOpenChange={setIsSidebarOpen}>
            <SheetTrigger asChild>
              <button className={`w-10 h-10 flex items-center justify-center rounded-lg transition-colors mr-2 ${isPro ? 'hover:bg-[#2a3036] text-gray-400' : 'hover:bg-gray-100 text-gray-700'}`}>
                <Menu className="w-6 h-6" />
              </button>
            </SheetTrigger>
            <SheetContent side="left" className="w-[300px] p-0 flex flex-col bg-white border-r border-border" aria-describedby={undefined}>
              <div className="p-4 bg-gray-50 border-b border-border">
                <SheetTitle className="font-bold text-lg text-gray-800">Admin Menü</SheetTitle>
              </div>
              <div className="flex-1 overflow-y-auto p-2 space-y-1">
                {[
                  { key: 'overview', label: 'Áttekintés (Pro)', icon: <BarChart3 className="w-5 h-5" /> },
                  { key: 'orders', label: 'Rendelések', icon: <Pizza className="w-5 h-5" /> },
                  { key: 'crm', label: 'Pult (POS)', icon: <Monitor className="w-5 h-5" /> },
                  { key: 'products', label: 'Termékek', icon: <ChefHat className="w-5 h-5" /> },
                  { key: 'toppings', label: 'Feltétek és Extrák', icon: <UtensilsCrossed className="w-5 h-5" /> },
                  { key: 'stats', label: 'Statisztika', icon: <BarChart3 className="w-5 h-5" /> },
                  { key: 'dispatch', label: 'Futár kiosztás (Régi)', icon: <Truck className="w-5 h-5" /> },
                  { key: 'courier-management', label: 'Futárok kezelése', icon: <Users className="w-5 h-5" /> },
                  { key: 'coupons', label: 'Kuponok', icon: <Tag className="w-5 h-5" /> },
                  { key: 'settings', label: 'Nyitvatartás & Városok', icon: <Settings className="w-5 h-5" /> },
                  { key: 'napi-zaras', label: 'Nap zárása', icon: <Banknote className="w-5 h-5" /> },
                  { key: 'futar-zaras', label: 'Futár zárás', icon: <CreditCard className="w-5 h-5" /> },
                ].map((item) => {
                  const isActive = activeTab === item.key;
                  return (
                    <button
                      key={item.key}
                      onClick={() => { setActiveTab(item.key); setIsSidebarOpen(false); }}
                      className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-left transition-colors ${isActive ? 'bg-gray-100 text-[#e73423]' : 'hover:bg-gray-50 text-gray-700'}`}
                    >
                      <span className={isActive ? 'text-[#e73423]' : 'text-gray-500'}>{item.icon}</span>
                      <span className="font-medium">{item.label}</span>
                    </button>
                  );
                })}
              </div>
            </SheetContent>
          </Sheet>
          
          {isPro ? (
            <div className="flex items-center gap-4">
              <div className="flex flex-col ml-2">
                <span className="font-bold text-gray-100 flex items-center gap-2">
                  <UtensilsCrossed className="w-4 h-4 text-[#e73423]" /> Falatház Pro
                </span>
                <span className="text-[10px] text-gray-500">SaaS Partner Portal</span>
              </div>
              <div className="hidden sm:flex ml-4 bg-[#1b1f24] border border-[#30363d] rounded-full pl-1 pr-4 py-1 items-center gap-3">
                <div className="bg-[#2a3036] rounded-full p-1.5 border border-[#30363d]">
                  <div className="bg-green-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1">
                    <span className="w-1.5 h-1.5 bg-white rounded-full animate-pulse" /> Live
                  </div>
                </div>
                <div className="flex flex-col">
                  <span className="text-xs font-bold text-gray-200">License Status</span>
                  <span className="text-[10px] text-gray-500">
                    Licenc: {restaurant?.license_type === 'perpetual' ? 'Örökös' : `${daysLeft} nap hátra`} | Típus: {
                      restaurant?.license_type === 'monthly' ? 'Havi' : 
                      restaurant?.license_type === 'quarterly' ? 'Negyedéves' : 
                      restaurant?.license_type === 'yearly' ? 'Éves' : 
                      restaurant?.license_type === 'perpetual' ? 'Örökös' : 'Éves'
                    }
                  </span>
                </div>
              </div>
            </div>
          ) : (
            <button onClick={() => navigate('/')} className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm hover:bg-gray-100 text-gray-700 font-medium">
              <Home className="w-4 h-4" />
              <span className="hidden sm:inline">Étterem</span>
            </button>
          )}
        </div>
        <div className="flex items-center gap-4">
          {pendingOrders.length > 0 && (
            <span className="flex items-center gap-1 text-xs font-bold px-3 py-1.5 rounded-full animate-pulse bg-[#e73423] text-white shadow-sm">
              <Bell className="w-3.5 h-3.5" />{pendingOrders.length} új
            </span>
          )}
          <button
            onClick={() => setSoundEnabled(!soundEnabled)}
            className={`w-9 h-9 flex items-center justify-center rounded-md transition-colors ${isPro ? 'text-gray-400 hover:bg-[#2a3036]' : 'text-gray-600 hover:bg-gray-100'}`}
            title="Hangjelzés kikapcsolása"
          >
            {soundEnabled ? <Volume2 className="w-4.5 h-4.5" /> : <VolumeX className="w-4.5 h-4.5" />}
          </button>
          <button
            className={`w-9 h-9 flex items-center justify-center rounded-md transition-colors ${isPro ? 'text-gray-400 hover:bg-[#2a3036]' : 'text-gray-600 hover:bg-gray-100'}`}
            onClick={() => loadData()}
            title="Frissítés"
          >
            <Loader2 className="w-4.5 h-4.5" />
          </button>
          <button onClick={() => { logout(); navigate('/'); }} className={`w-9 h-9 flex items-center justify-center rounded-md ml-2 ${isPro ? 'text-red-400 hover:bg-red-500/10' : 'text-red-600 hover:bg-red-50'}`} title="Kijelentkezés">
            <LogOut className="w-4.5 h-4.5" />
          </button>
        </div>
      </header>

      {/* ── Main Content Area ── */}
      <div className="flex-1 overflow-hidden relative">
        {activeTab === 'overview' && (
          <div className="absolute inset-0 overflow-y-auto">
            <AdminProDashboard />
          </div>
        )}
        {activeTab === 'orders' && (
          <OrdersTab orders={orders} couriers={couriers} onOpenOrder={setSelectedOrder} />
        )}
        {activeTab === 'crm' && (
          <CrmPosPanel
            products={products}
            categories={[]}
            toppingGroups={toppingGroups}
            onOrderCreated={handleCrmOrderCreated}
            initialTable=""
            existingOrderId={selectedOrderId}
          />
        )}
        {activeTab === 'dispatch' && (
          <CourierDispatchPanel
            orders={orders}
            couriers={couriers}
            onStatusChange={(orderId, status, courierId, courierStatus) => updateStatus(orderId, status, courierId, courierStatus)}
          />
        )}
                {/* Archívum */}
        {activeTab === 'archive' && (
          <div className="h-full overflow-y-auto p-4 print-container">
            <div className="flex items-center gap-2 mb-4 print-hidden">
              <h2 className="font-bold text-base text-foreground">Archívum</h2>
            </div>
            <ArchiveView />
          </div>
        )}

        {/* Napi zárás */}
        {activeTab === 'napi-zaras' && (
          <div className="h-full overflow-hidden print-container">
            <NapiZaras
              orders={closeOrders.length > 0 ? closeOrders : orders}
              fromDate={closeFromDate}
              toDate={closeToDate}
              onFromChange={setCloseFromDate}
              onToChange={setCloseToDate}
              onSearch={() => loadCloseData(closeFromDate, closeToDate)}
            />
          </div>
        )}

        {/* Futár zárás */}
        {activeTab === 'futar-zaras' && (
          <div className="h-full overflow-hidden print-container">
            <FutarZaras
              orders={closeOrders.length > 0 ? closeOrders : orders}
              couriers={couriers}
              fromDate={closeFromDate}
              toDate={closeToDate}
              onFromChange={setCloseFromDate}
              onToChange={setCloseToDate}
              onSearch={() => loadCloseData(closeFromDate, closeToDate)}
            />
          </div>
        )}

        {/* Futár Menedzsment (CRUD) */}
        {activeTab === 'courier-management' && (
          <div className="h-full overflow-hidden">
            <CourierManagementView
              couriers={couriers}
              courierForm={courierForm}
              setCourierForm={setCourierForm}
              editingCourier={editingCourier}
              setEditingCourier={setEditingCourier}
              loadData={loadData}
            />
          </div>
        )}

        {/* Étlap szerkesztő */}
        {activeTab === 'products' && (
          <div className="h-full overflow-y-auto p-4">
            <div className="flex items-center gap-2 mb-4">
              <button onClick={() => setActiveTab('extra-menu')} className="text-primary">← Vissza</button>
              <h2 className="font-bold text-base text-foreground">Étlap szerkesztő</h2>
            </div>
            <ProductManagement products={products} categories={categories} toppingGroups={toppingGroups} onSave={handleSaveProduct} onDelete={handleDeleteProduct} onCategoriesChange={setCategories} onToggleAvailability={handleToggleAvailability} />
          </div>
        )}

        {/* Öntet */}
        {activeTab === 'toppings' && (
          <div className="h-full overflow-y-auto p-4 md:p-6 space-y-6">
            <ToppingManager groups={toppingGroups} onRefresh={() => toppingApi.getAll().then((r) => setToppingGroups(Array.isArray(r.data) ? r.data : []))} />
          </div>
        )}

        {/* Beállítások: Nyitvatartás & Városok */}
        {activeTab === 'stats' && stats && (
          <div className="h-full overflow-y-auto p-4 md:p-6 space-y-6">
            <h2 className="text-2xl font-bold text-gray-800 border-b pb-2 mb-4">Statisztika Áttekintés</h2>
            <div className="flex gap-2 items-end bg-white p-4 rounded-lg shadow-sm border border-gray-100">
              <div>
                <Label className="text-gray-600 mb-1 block">Ettől:</Label>
                <Input type="date" value={statsFromDate} onChange={(e) => setStatsFromDate(e.target.value)} className="w-40 border-gray-300 bg-white" />
              </div>
              <div>
                <Label className="text-gray-600 mb-1 block">Eddig:</Label>
                <Input type="date" value={statsToDate} onChange={(e) => setStatsToDate(e.target.value)} className="w-40 border-gray-300 bg-white" />
              </div>
              <Button onClick={() => loadStatsData(statsFromDate, statsToDate)} className="bg-primary text-white hover:bg-primary/90">
                Szűrés
              </Button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Card className="bg-white shadow-sm border-gray-100">
                <CardContent className="p-6">
                  <div className="text-sm font-medium text-gray-500 mb-1">Összes Rendelés</div>
                  <div className="text-3xl font-black text-gray-800">{stats.totalOrders} db</div>
                </CardContent>
              </Card>
              <Card className="bg-white shadow-sm border-gray-100">
                <CardContent className="p-6">
                  <div className="text-sm font-medium text-gray-500 mb-1">Teljes Bevétel</div>
                  <div className="text-3xl font-black text-green-600">{stats.totalRevenue.toLocaleString()} Ft</div>
                </CardContent>
              </Card>
              <Card className="bg-white shadow-sm border-gray-100">
                <CardContent className="p-6">
                  <div className="text-sm font-medium text-gray-500 mb-1">Készpénzes fizetés</div>
                  <div className="text-2xl font-bold text-gray-700">{stats.cashRevenue.toLocaleString()} Ft</div>
                </CardContent>
              </Card>
              <Card className="bg-white shadow-sm border-gray-100">
                <CardContent className="p-6">
                  <div className="text-sm font-medium text-gray-500 mb-1">Bankkártyás fizetés</div>
                  <div className="text-2xl font-bold text-gray-700">{stats.cardRevenue.toLocaleString()} Ft</div>
                </CardContent>
              </Card>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
              <Card className="bg-white shadow-sm border-gray-100">
                <CardContent className="p-6">
                  <h3 className="font-bold text-lg text-gray-800 mb-4">Bevétel Részletezése</h3>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center pb-2 border-b border-gray-100">
                      <span className="text-gray-600">Étel/Ital bevétel</span>
                      <span className="font-bold">{stats.foodRevenue.toLocaleString()} Ft</span>
                    </div>
                    <div className="flex justify-between items-center pb-2 border-b border-gray-100">
                      <span className="text-gray-600">Csomagolási díj bevétel</span>
                      <span className="font-bold">{stats.packagingRevenue.toLocaleString()} Ft</span>
                    </div>
                    <div className="flex justify-between items-center pb-2 border-b border-gray-100">
                      <span className="text-gray-600">DRS bevétel</span>
                      <span className="font-bold">{stats.drsRevenue.toLocaleString()} Ft</span>
                    </div>
                    <div className="flex justify-between items-center pb-2 border-b border-gray-100">
                      <span className="text-gray-600">Kiszállítási díjak</span>
                      <span className="font-bold">{(stats.totalRevenue - stats.foodRevenue - stats.packagingRevenue - stats.drsRevenue).toLocaleString()} Ft</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-white shadow-sm border-gray-100">
                <CardContent className="p-6">
                  <h3 className="font-bold text-lg text-gray-800 mb-4">Top Ételek / Italok</h3>
                  <div className="space-y-3">
                    {stats.topProducts.length > 0 ? stats.topProducts.map((p, i) => (
                      <div key={i} className="flex justify-between items-center pb-2 border-b border-gray-100">
                        <span className="text-gray-700 font-medium">{i+1}. {p.name}</span>
                        <span className="text-gray-600">{p.quantity} db <span className="text-gray-400 ml-1 text-sm">({p.revenue.toLocaleString()} Ft)</span></span>
                      </div>
                    )) : (
                      <p className="text-gray-500 text-sm">Nincs még elég adat.</p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        )}

        {activeTab === 'settings' && (
          <div className="h-full overflow-y-auto p-4 md:p-6 bg-muted/20">
            <h2 className="text-xl font-bold text-foreground mb-6 flex items-center gap-2">
              <Settings className="w-6 h-6 text-primary" /> Nyitvatartás & Városok
            </h2>

            <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
              <div className="space-y-6">
                {/* Nyitvatartás */}
                <OpeningHoursManager 
                  hours={openingHours} 
                  onChange={setOpeningHours} 
                  onSave={handleSaveHours} 
                  manualOverride={manualOverride} 
                  onToggleManual={handleToggleManual} 
                  forceManual={forceManual} 
                  onResetAuto={handleResetAuto} 
                />
              </div>

              {/* Városok és VIP */}
              <div className="space-y-6">
                <CityManager />
                <LoyaltySettingsManager />
              </div>
            </div>
          </div>
        )}

        {/* Kuponok */}
        {activeTab === 'coupons' && (
          <div className="h-full overflow-y-auto p-4">
            <div className="flex items-center gap-2 mb-4">
              <button onClick={() => setActiveTab('extra-menu')} className="text-primary">← Vissza</button>
              <h2 className="font-bold text-base text-foreground">Kuponok</h2>
            </div>
            <div className="bg-card rounded shadow-sm p-4 space-y-4 mb-4">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
                <div>
                  <Label className="text-xs text-muted-foreground">Kupon név</Label>
                  <Input value={couponForm.name} onChange={(e) => setCouponForm({ ...couponForm, name: e.target.value })} placeholder="Pl. Nyári akció" className="h-9" />
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">Kód</Label>
                  <Input value={couponForm.code} onChange={(e) => setCouponForm({ ...couponForm, code: e.target.value.toUpperCase() })} placeholder="Pl. NYAR2025" className="h-9" />
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">Kedvezmény %</Label>
                  <Input type="number" min={0} max={100} value={couponForm.discount_pct || ''} onChange={(e) => setCouponForm({ ...couponForm, discount_pct: Number(e.target.value) })} placeholder="Pl. 10" className="h-9" />
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">Max. felhasználás (0 = korlátlan)</Label>
                  <Input type="number" min={0} value={couponForm.max_uses || ''} onChange={(e) => setCouponForm({ ...couponForm, max_uses: Number(e.target.value) })} placeholder="0" className="h-9" />
                </div>
              </div>
              <div className="flex gap-2">
                {editingCoupon ? (
                  <>
                    <Button onClick={async () => {
                      try {
                        await couponApi.update(editingCoupon, couponForm);
                        toast.success('Kupon frissítve');
                        setEditingCoupon(null);
                        setCouponForm({ name: '', code: '', discount_pct: 0, max_uses: 0 });
                        loadCoupons();
                      } catch { toast.error('Frissítés sikertelen'); }
                    }} className="h-9">Mentés</Button>
                    <Button variant="outline" onClick={() => { setEditingCoupon(null); setCouponForm({ name: '', code: '', discount_pct: 0, max_uses: 0 }); }} className="h-9">Mégse</Button>
                  </>
                ) : (
                  <Button onClick={async () => {
                    if (!couponForm.name.trim() || !couponForm.code.trim()) { toast.error('Név és kód kötelező'); return; }
                    try {
                      await couponApi.create(couponForm);
                      toast.success('Kupon létrehozva');
                      setCouponForm({ name: '', code: '', discount_pct: 0, max_uses: 0 });
                      loadCoupons();
                    } catch { toast.error('Létrehozás sikertelen'); }
                  }} className="h-9">Létrehozás</Button>
                )}
              </div>
            </div>
            <div className="bg-card rounded shadow-sm overflow-hidden">
              <div className="grid grid-cols-12 gap-2 px-4 py-2 text-xs font-medium bg-muted/20 border-b border-border">
                <span className="col-span-3">Név</span>
                <span className="col-span-2">Kód</span>
                <span className="col-span-2">Kedvezmény</span>
                <span className="col-span-2">Felhasználás</span>
                <span className="col-span-3 text-right">Műveletek</span>
              </div>
              {coupons.map((c) => (
                <div key={c._id} className="grid grid-cols-12 gap-2 px-4 py-2.5 text-sm items-center border-b border-border">
                  <span className="col-span-3 truncate">{c.name}</span>
                  <span className="col-span-2 font-mono text-xs">{c.code}</span>
                  <span className="col-span-2">{c.discount_pct}%</span>
                  <span className="col-span-2">{c.usage_count} / {c.max_uses || '∞'}</span>
                  <div className="col-span-3 flex justify-end gap-2">
                    <button onClick={() => { setEditingCoupon(c._id); setCouponForm({ name: c.name, code: c.code, discount_pct: c.discount_pct, max_uses: c.max_uses ?? 0 }); }} className="text-muted-foreground hover:text-foreground"><Edit2 className="w-3.5 h-3.5" /></button>
                    <button onClick={async () => {
                      if (!confirm('Biztosan törlöd a kupont?')) return;
                      try { await couponApi.delete(c._id); toast.success('Kupon törölve'); loadCoupons(); }
                      catch { toast.error('Törlés sikertelen'); }
                    }} className="text-red-500 hover:text-red-600"><Trash2 className="w-3.5 h-3.5" /></button>
                  </div>
                </div>
              ))}
              {coupons.length === 0 && (
                <div className="px-4 py-6 text-center text-sm text-muted-foreground">Nincs kupon</div>
              )}
            </div>
          </div>
        )}

        {/* Futárok kezelése */}
        {activeTab === 'couriers' && (
          <div className="h-full overflow-y-auto p-4">
            <div className="flex items-center gap-2 mb-4">
              <button onClick={() => setActiveTab('extra-menu')} className="text-primary">← Vissza</button>
              <h2 className="font-bold text-base text-foreground">Futárok kezelése</h2>
            </div>
            <div className="bg-card rounded shadow-sm p-4 space-y-4 mb-4">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
                <div>
                  <Label className="text-xs text-muted-foreground">Név *</Label>
                  <Input value={courierForm.name} onChange={(e) => setCourierForm({ ...courierForm, name: e.target.value })} placeholder="Pl. Futár János" className="h-9" />
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">E-mail *</Label>
                  <Input value={courierForm.email} onChange={(e) => setCourierForm({ ...courierForm, email: e.target.value })} placeholder="Pl. futar@szesztestverek.hu" className="h-9" />
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">Telefon</Label>
                  <Input value={courierForm.phone} onChange={(e) => setCourierForm({ ...courierForm, phone: e.target.value })} placeholder="Pl. 06123456789" className="h-9" />
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">Jelszó {editingCourier ? '(üresen hagyva = nem változik)' : '*'}</Label>
                  <Input type="password" value={courierForm.password} onChange={(e) => setCourierForm({ ...courierForm, password: e.target.value })} placeholder="Jelszó" className="h-9" />
                </div>
              </div>
              <div className="flex gap-2">
                {editingCourier ? (
                  <>
                    <Button onClick={async () => {
                      try {
                        const payload: any = {};
                        if (courierForm.name) payload.name = courierForm.name;
                        if (courierForm.email) payload.email = courierForm.email;
                        if (courierForm.phone) payload.phone = courierForm.phone;
                        if (courierForm.password) payload.password = courierForm.password;
                        await adminApi.updateCourier(editingCourier, payload);
                        toast.success('Futár frissítve');
                        setEditingCourier(null);
                        setCourierForm({ name: '', email: '', phone: '', password: '' });
                        const cRes = await adminApi.getCouriers();
                        setCouriers(cRes.data);
                      } catch { toast.error('Frissítés sikertelen'); }
                    }} className="h-9">Mentés</Button>
                    <Button variant="outline" onClick={() => { setEditingCourier(null); setCourierForm({ name: '', email: '', phone: '', password: '' }); }} className="h-9">Mégse</Button>
                  </>
                ) : (
                  <Button onClick={async () => {
                    if (!courierForm.name.trim() || !courierForm.email.trim() || !courierForm.password) { toast.error('Név, e-mail és jelszó kötelező'); return; }
                    try {
                      await adminApi.createCourier(courierForm);
                      toast.success('Futár létrehozva');
                      setCourierForm({ name: '', email: '', phone: '', password: '' });
                      const cRes = await adminApi.getCouriers();
                      setCouriers(cRes.data);
                    } catch { toast.error('Létrehozás sikertelen'); }
                  }} className="h-9">Létrehozás</Button>
                )}
              </div>
            </div>
            <div className="bg-card rounded shadow-sm overflow-hidden">
              <div className="grid grid-cols-12 gap-2 px-4 py-2 text-xs font-medium bg-muted/20 border-b border-border">
                <span className="col-span-3">Név</span>
                <span className="col-span-3">E-mail</span>
                <span className="col-span-3">Telefon</span>
                <span className="col-span-3 text-right">Műveletek</span>
              </div>
              {couriers.map((c) => (
                <div key={c.id} className="grid grid-cols-12 gap-2 px-4 py-2.5 text-sm items-center border-b border-border">
                  <span className="col-span-3 truncate">{c.name}</span>
                  <span className="col-span-3 truncate">{c.email}</span>
                  <span className="col-span-3">{c.phone || '—'}</span>
                  <div className="col-span-3 flex justify-end gap-2">
                    <button onClick={() => { setEditingCourier(c.id); setCourierForm({ name: c.name, email: c.email, phone: c.phone || '', password: '' }); }} className="text-muted-foreground hover:text-foreground"><Edit2 className="w-3.5 h-3.5" /></button>
                    <button onClick={async () => {
                      if (!confirm('Biztosan törlöd a futárt?')) return;
                      try { await adminApi.deleteCourier(c.id); toast.success('Futár törölve'); const cRes = await adminApi.getCouriers(); setCouriers(cRes.data); }
                      catch { toast.error('Törlés sikertelen'); }
                    }} className="text-red-500 hover:text-red-600"><Trash2 className="w-3.5 h-3.5" /></button>
                  </div>
                </div>
              ))}
              {couriers.length === 0 && (
                <div className="px-4 py-6 text-center text-sm text-muted-foreground">Nincs futár</div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* ── Bottom Tabs (POS Layout) ── */}
      <div className="shrink-0 h-[60px] bg-white border-t border-gray-200 flex items-stretch text-gray-600 text-[11px] sm:text-sm font-bold uppercase tracking-wider relative z-50 justify-center">
        <div className="flex w-full max-w-4xl mx-auto px-4 md:px-12">
          <button 
            className={`flex-1 flex items-center justify-center transition-colors border-t-[3px] mt-[-1px] ${activeTab === 'orders' ? 'border-[#b5255e] text-[#b5255e]' : 'border-transparent hover:text-gray-900'}`}
            onClick={() => setActiveTab('orders')}
          >
            RENDELÉSEK
          </button>
          <button 
            className={`flex-1 flex items-center justify-center transition-colors border-t-[3px] mt-[-1px] ${activeTab === 'crm' ? 'border-[#b5255e] text-[#b5255e]' : 'border-transparent hover:text-gray-900'}`}
            onClick={() => setActiveTab('crm')}
          >
            TELEFONOS
          </button>
          <button 
            className={`flex-1 flex items-center justify-center transition-colors border-t-[3px] mt-[-1px] ${activeTab === 'dispatch' ? 'border-[#b5255e] text-[#b5255e]' : 'border-transparent hover:text-gray-900'}`}
            onClick={() => setActiveTab('dispatch')}
          >
            FUTÁROK
          </button>
        </div>
      </div>
      
      {/* ── Order Detail Modal ── */}
      {selectedOrder && (
        <OrderDetailModal
          order={selectedOrder}
          open={!!selectedOrder}
          onClose={() => setSelectedOrder(null)}
          onUpdated={(o) => setSelectedOrder(null)}
          onPrint={() => handlePrint(selectedOrder)}
          onEdit={(o) => {
            setSelectedOrder(null);
            setSelectedOrderId(o._id);
            setActiveTab('crm');
          }}
          products={products}
          categories={[]}
        />
      )}
    </div>
  );
}
function ProductManagement({
  products,
  categories,
  toppingGroups,
  onSave,
  onDelete,
  onCategoriesChange,
  onToggleAvailability,
}: {
  products: Product[];
  categories: string[];
  toppingGroups: ToppingGroup[];
  onSave: (p: Partial<Product>) => void;
  onDelete: (id: string) => void;
  onCategoriesChange: (cats: string[]) => void;
  onToggleAvailability: (id: string, val: boolean) => void;
}) {
  const [editing, setEditing] = useState<Partial<Product> | null>(null);
  const [activeTab, setActiveTab] = useState<'products' | 'categories'>('products');
  const [imgMode, setImgMode] = useState<'url' | 'file'>('url');
  const [imgUploading, setImgUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [newCatName, setNewCatName] = useState('');
  const [editingCat, setEditingCat] = useState<{ index: number; value: string } | null>(null);
  const [savingCats, setSavingCats] = useState(false);

  const saveCategories = async (cats: string[]) => {
    setSavingCats(true);
    try {
      await settingsApi.updateCategories(cats);
      onCategoriesChange(cats);
      toast.success('Kategóriák mentve');
    } catch {
      toast.error('Mentés sikertelen');
    } finally {
      setSavingCats(false);
    }
  };

  const handleAddCategory = () => {
    const name = newCatName.trim();
    if (!name) return;
    if (categories.includes(name)) {
      toast.error('Ez a kategória már létezik');
      return;
    }
    const updated = [...categories, name];
    saveCategories(updated);
    setNewCatName('');
  };

  const handleRenameCategory = (index: number, newName: string) => {
    const trimmed = newName.trim();
    if (!trimmed) return;
    if (categories.includes(trimmed) && categories[index] !== trimmed) {
      toast.error('Ez a kategória már létezik');
      return;
    }
    const updated = categories.map((c, i) => (i === index ? trimmed : c));
    saveCategories(updated);
    setEditingCat(null);
  };

  const handleDeleteCategory = (index: number) => {
    const catName = categories[index];
    const inUse = products.some((p) => p.category === catName);
    if (inUse) {
      toast.error(`A "${catName}" kategória termékeket tartalmaz. Előbb helyezd át vagy töröld a termékeket.`);
      return;
    }
    const updated = categories.filter((_, i) => i !== index);
    saveCategories(updated);
  };

  const handleMoveCat = (index: number, dir: -1 | 1) => {
    const newIdx = index + dir;
    if (newIdx < 0 || newIdx >= categories.length) return;
    const updated = [...categories];
    [updated[index], updated[newIdx]] = [updated[newIdx], updated[index]];
    saveCategories(updated);
  };

  return (
    <div className="space-y-4">
      {/* Fejléc + fültab */}
      <div className="flex flex-col md:flex-row md:items-center gap-3">
        <h2 className="text-xl font-bold text-foreground flex-1">Étlap kezelése</h2>
        <div className="flex gap-2">
          <Button
            size="sm"
            variant={activeTab === 'products' ? 'default' : 'outline'}
            className={activeTab === 'products' ? 'btn-primary-gradient text-white' : 'border-border text-primary'}
            onClick={() => setActiveTab('products')}
          >
            <UtensilsCrossed className="w-3.5 h-3.5 mr-1" /> Termékek
          </Button>
          <Button
            size="sm"
            variant={activeTab === 'categories' ? 'default' : 'outline'}
            className={activeTab === 'categories' ? 'btn-primary-gradient text-white' : 'border-border text-primary'}
            onClick={() => setActiveTab('categories')}
          >
            <Tag className="w-3.5 h-3.5 mr-1" /> Kategóriák
          </Button>
          {activeTab === 'products' && (
            <Button
              size="sm"
              className="btn-primary-gradient text-white"
              onClick={() => setEditing({ name: '', description: '', price: 0, category: categories[0] || '', packaging_fee: 0, drs_applies: false, image: '' })}
            >
              <Plus className="w-3.5 h-3.5 mr-1" /> Új termék
            </Button>
          )}
        </div>
      </div>

      {/* ─── KATEGÓRIA KEZELŐ ─── */}
      {activeTab === 'categories' && (
        <div className="space-y-4">
          {/* Új kategória */}
          <Card className="bg-card border border-border">
            <CardContent className="p-4">
              <p className="text-sm text-muted-foreground mb-3">Új kategória hozzáadása</p>
              <div className="flex gap-2">
                <Input
                  placeholder="Kategória neve (akár emojival 🍕)"
                  value={newCatName}
                  onChange={(e) => setNewCatName(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleAddCategory()}
                  className="bg-secondary border-border text-foreground"
                />
                <Button
                  className="btn-primary-gradient text-white shrink-0"
                  onClick={handleAddCategory}
                  disabled={!newCatName.trim() || savingCats}
                >
                  <Plus className="w-4 h-4 mr-1" /> Hozzáad
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Kategória lista */}
          <div className="space-y-2">
            {categories.length === 0 && (
              <p className="text-muted-foreground text-sm text-center py-6">Nincsenek kategóriák. Adj hozzá egyet!</p>
            )}
            {categories.map((cat, idx) => {
              const usedCount = products.filter((p) => p.category === cat).length;
              return (
                <Card key={cat + idx} className="bg-card border border-border">
                  <CardContent className="p-3">
                    {editingCat?.index === idx ? (
                      <div className="flex gap-2 items-center">
                        <Input
                          autoFocus
                          value={editingCat.value}
                          onChange={(e) => setEditingCat({ index: idx, value: e.target.value })}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') handleRenameCategory(idx, editingCat.value);
                            if (e.key === 'Escape') setEditingCat(null);
                          }}
                          className="bg-secondary border-border text-foreground h-8 text-sm flex-1"
                        />
                        <Button size="sm" className="btn-primary-gradient text-white h-8 px-3" onClick={() => handleRenameCategory(idx, editingCat.value)}>
                          <Check className="w-3.5 h-3.5" />
                        </Button>
                        <Button size="sm" variant="ghost" className="text-muted-foreground h-8 px-2" onClick={() => setEditingCat(null)}>
                          <X className="w-3.5 h-3.5" />
                        </Button>
                      </div>
                    ) : (
                      <div className="flex items-center gap-2">
                        {/* Sorrend gombok */}
                        <div className="flex flex-col gap-0.5 shrink-0">
                          <button
                            disabled={idx === 0 || savingCats}
                            onClick={() => handleMoveCat(idx, -1)}
                            className="text-muted-foreground hover:text-foreground disabled:opacity-30 leading-none"
                          >
                            <ChevronUp className="w-3.5 h-3.5" />
                          </button>
                          <button
                            disabled={idx === categories.length - 1 || savingCats}
                            onClick={() => handleMoveCat(idx, 1)}
                            className="text-muted-foreground hover:text-foreground disabled:opacity-30 leading-none"
                          >
                            <ChevronDown className="w-3.5 h-3.5" />
                          </button>
                        </div>
                        {/* Névsor */}
                        <div className="flex-1 min-w-0 flex items-center gap-3">
                          <div className="flex flex-col">
                            <span className="text-foreground font-medium">{cat}</span>
                            <span className="text-xs text-muted-foreground">
                              {usedCount} termék
                            </span>
                          </div>
                        </div>
                        {/* Műveletek */}
                        <div className="flex gap-1 shrink-0">
                          <Button
                            size="sm"
                            variant="outline"
                            className="border-border h-7 px-2"
                            onClick={() => setEditingCat({ index: idx, value: cat })}
                          >
                            <Edit2 className="w-3 h-3" />
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            className="text-red-400 h-7 px-2"
                            onClick={() => handleDeleteCategory(idx)}
                            disabled={usedCount > 0 || savingCats}
                            title={usedCount > 0 ? 'Csak üres kategória törölhető' : 'Töröl'}
                          >
                            <Trash2 className="w-3 h-3" />
                          </Button>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>
          <p className="text-xs text-muted-foreground">
            💡 Csak üres (0 termékes) kategória törölhető. A sorrend az online rendelési oldalon is érvényes.
          </p>
        </div>
      )}

      {/* ─── TERMÉKEK ─── */}
      {activeTab === 'products' && (
        <div className="space-y-4">
          {/* Szerkesztő form */}
          <Dialog open={!!editing} onOpenChange={(open) => { if (!open) setEditing(null); }}>
            <DialogContent className="bg-[#1a1510] border border-[#3e3020] max-w-[calc(100%-2rem)] md:max-w-2xl max-h-[90dvh] overflow-y-auto text-[#f5f0e8] rounded-2xl shadow-2xl" aria-describedby={undefined}>
              <DialogHeader>
                <DialogTitle className="text-white flex items-center gap-2 text-xl font-bold">
                  <Edit2 className="w-5 h-5 text-[#ea5a0c]" />
                  {editing?._id ? 'Termék szerkesztése' : 'Új termék'}
                </DialogTitle>
              </DialogHeader>
              {editing && <div className="space-y-6 mt-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Input placeholder="Név" value={editing.name} onChange={(e) => setEditing({ ...editing, name: e.target.value })} className="bg-[#2a2318] border-[#3e3020] text-white focus-visible:ring-[#ea5a0c] rounded-xl h-11" />
                  <Input placeholder="Leírás" value={editing.description} onChange={(e) => setEditing({ ...editing, description: e.target.value })} className="bg-[#2a2318] border-[#3e3020] text-white focus-visible:ring-[#ea5a0c] rounded-xl h-11" />
                  <Input type="number" placeholder="Ár (Ft)" value={editing.price} onChange={(e) => setEditing({ ...editing, price: Number(e.target.value) })} className="bg-[#2a2318] border-[#3e3020] text-white focus-visible:ring-[#ea5a0c] rounded-xl h-11" />
                  <Input type="number" placeholder="Régi ár (Áthúzott) - opcionális" value={editing.original_price || ''} onChange={(e) => setEditing({ ...editing, original_price: e.target.value ? Number(e.target.value) : undefined })} className="bg-[#2a2318] border-[#3e3020] text-white focus-visible:ring-[#ea5a0c] rounded-xl h-11" />
                  <select
                    value={editing.category || ''}
                    onChange={(e) => setEditing({ ...editing, category: e.target.value })}
                    className="bg-[#2a2318] border border-[#3e3020] text-white focus-visible:ring-[#ea5a0c] rounded-xl h-11 px-3 text-sm focus:outline-none focus:ring-1 focus:border-[#ea5a0c]"
                  >
                    <option value="" disabled>Kategória kiválasztása...</option>
                    {categories.map((c) => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                  <Input type="number" placeholder="Csomagolási díj" value={editing.packaging_fee} onChange={(e) => setEditing({ ...editing, packaging_fee: Number(e.target.value) })} className="bg-[#2a2318] border-[#3e3020] text-white focus-visible:ring-[#ea5a0c] rounded-xl h-11" />
                  <div className="flex items-center gap-3 bg-[#2a2318] border border-[#3e3020] rounded-xl px-4 h-11">
                    <Switch checked={editing.drs_applies} onCheckedChange={(v) => setEditing({ ...editing, drs_applies: v })} className="data-[state=checked]:bg-[#ea5a0c]" />
                    <Label className="text-white text-sm font-medium">DRS visszaváltási díj (+50 Ft)</Label>
                  </div>
                </div>

                {/* ── Képfeltöltés szekció ── */}
                <div className="border border-[#3e3020] bg-[#1a1510] rounded-xl p-4 space-y-4">
                  <div className="flex items-center justify-between">
                    <Label className="text-white text-sm font-bold flex items-center gap-2">
                      <ImageIcon className="w-5 h-5 text-[#ea5a0c]" /> Termékkép
                    </Label>
                    <div className="flex bg-[#2a2318] rounded-lg overflow-hidden border border-[#3e3020]">
                      <button
                        onClick={() => setImgMode('url')}
                        className={`px-3 py-1.5 rounded-none text-xs font-semibold transition-colors ${imgMode === 'url' ? 'bg-[#ea5a0c] text-white' : 'text-gray-400 hover:text-white'}`}
                      >
                        URL
                      </button>
                      <button
                        onClick={() => setImgMode('file')}
                        className={`px-3 py-1 rounded text-xs transition-colors ${imgMode === 'file' ? 'bg-primary text-primary-foreground' : 'bg-secondary text-muted-foreground hover:text-foreground'}`}
                      >
                        Fájl feltöltés
                      </button>
                    </div>
                  </div>

                  <div className="flex gap-3 items-start">
                    {/* Előnézet */}
                    <div className="w-20 h-20 rounded-lg overflow-hidden border border-border shrink-0 bg-secondary flex items-center justify-center">
                      {editing.image ? (
                        <img src={editing.image} alt="Előnézet" className="w-full h-full object-cover" onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }} />
                      ) : (
                        <ImageIcon className="w-7 h-7 text-muted-foreground/40" />
                      )}
                    </div>

                    <div className="flex-1 min-w-0 space-y-2">
                      {imgMode === 'url' ? (
                        <div className="flex gap-2">
                          <Input
                            placeholder="https://... (kép URL)"
                            value={editing.image || ''}
                            onChange={(e) => setEditing({ ...editing, image: e.target.value })}
                            className="bg-secondary border-border text-sm"
                          />
                          {editing.image && (
                            <Button size="sm" variant="ghost" className="text-red-400 shrink-0 px-2" onClick={() => setEditing({ ...editing, image: '' })}>
                              <X className="w-4 h-4" />
                            </Button>
                          )}
                        </div>
                      ) : (
                        <div>
                          <input
                            ref={fileInputRef}
                            type="file"
                            accept="image/jpeg,image/png,image/webp,image/gif"
                            className="hidden"
                            onChange={async (e) => {
                              const file = e.target.files?.[0];
                              if (!file) return;
                              if (file.size > 5 * 1024 * 1024) {
                                toast.error('A kép mérete maximum 5 MB lehet');
                                return;
                              }
                              setImgUploading(true);
                              try {
                                const reader = new FileReader();
                                reader.onload = async (ev) => {
                                  const base64 = ev.target?.result as string;
                                  const res = await productApi.uploadImage(base64);
                                  setEditing((prev) => prev ? { ...prev, image: res.data.url } : prev);
                                  toast.success('Kép feltöltve');
                                  setImgUploading(false);
                                };
                                reader.onerror = () => { toast.error('Fájl olvasási hiba'); setImgUploading(false); };
                                reader.readAsDataURL(file);
                              } catch {
                                toast.error('Képfeltöltés sikertelen');
                                setImgUploading(false);
                              }
                              // input reset hogy ugyanazt a fájlt újra lehessen választani
                              e.target.value = '';
                            }}
                          />
                          <Button
                            variant="ghost"
                            className="border border-border text-primary hover:bg-primary/10 w-full"
                            onClick={() => fileInputRef.current?.click()}
                            disabled={imgUploading}
                          >
                            {imgUploading ? (
                              <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Feltöltés...</>
                            ) : (
                              <><Upload className="w-4 h-4 mr-2" /> Kép kiválasztása</>
                            )}
                          </Button>
                          <p className="text-xs text-muted-foreground mt-1">JPEG, PNG, WebP, GIF — max. 5 MB</p>
                        </div>
                      )}
                      {editing.image && (
                        <p className="text-xs text-muted-foreground truncate">{editing.image}</p>
                      )}
                    </div>
                  </div>
                </div>

                {/* ── Öntet / Kiegészítő csoportok hozzárendelése ── */}
                <div className="border border-border rounded-lg p-3 space-y-2">
                  <Label className="text-foreground text-sm font-semibold flex items-center gap-1.5">
                    <ChefHat className="w-4 h-4 text-primary" /> Öntet / Kiegészítő csoportok
                  </Label>
                  <p className="text-xs text-muted-foreground">
                    Jelöld be, melyik csoportból kell választani a vásárlónak ennél a terméknél.
                  </p>
                  {toppingGroups.length === 0 ? (
                    <p className="text-xs text-muted-foreground italic py-1">
                      Még nincs kiegészítő csoport. Hozz létre egyet az{' '}
                      <span className="text-primary">„Öntet" fülön</span>, majd mentés után itt jelölheted be.
                    </p>
                  ) : (
                    <div className="space-y-1.5 mt-1">
                      {toppingGroups.map((grp) => {
                        const tgId = (tg: { group_id: any }) =>
                          typeof tg.group_id === 'object' && tg.group_id !== null
                            ? (tg.group_id as ToppingGroup)._id
                            : (tg.group_id as string);
                        const existing = (editing.topping_groups || []).find((tg) => tgId(tg) === grp._id);
                        const checked = !!existing;
                        return (
                          <div
                            key={grp._id}
                            className={`flex items-center gap-3 px-3 py-2.5 rounded-lg border transition-colors cursor-pointer ${
                              checked
                                ? 'border-primary/40 bg-primary/8'
                                : 'border-border bg-secondary hover:border-primary/40'
                            }`}
                            onClick={() => {
                              const current = (editing.topping_groups || []).filter((tg) => tgId(tg) !== grp._id);
                              setEditing({
                                ...editing,
                                topping_groups: checked
                                  ? current
                                  : [...current, { group_id: grp._id as any, required: false, max_select: grp.max_select }],
                              });
                            }}
                          >
                            {/* Checkbox ikon */}
                            <div className={`w-4 h-4 rounded border-2 flex items-center justify-center shrink-0 transition-colors ${
                              checked ? 'border-primary bg-primary' : 'border-border bg-transparent'
                            }`}>
                              {checked && <Check className="w-2.5 h-2.5 text-primary-foreground" />}
                            </div>

                            {/* Csoport neve + opció-darab */}
                            <span className={`flex-1 min-w-0 text-sm font-medium truncate ${checked ? 'text-foreground' : 'text-muted-foreground'}`}>
                              {grp.name}
                            </span>
                            <span className="text-xs text-muted-foreground shrink-0">
                              ({grp.options.length} opció)
                            </span>
                            {/* Opcionális badge — mert checked esetén is mindig opcionális */}
                            <span className="text-xs px-1.5 py-0.5 rounded bg-card/8 text-muted-foreground border border-border shrink-0">
                              Opcionális
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>

                <div className="flex gap-2">
                  <Button className="btn-primary-gradient text-white" onClick={() => { 
                    if (!editing.name?.trim()) { toast.error('Kérlek add meg a termék nevét!'); return; }
                    if (editing.price === undefined || editing.price < 0) { toast.error('Érvényes árat kell megadni!'); return; }
                    onSave(editing); 
                    setEditing(null); 
                  }} disabled={imgUploading}>Mentés</Button>
                  <Button variant="outline" className="border-border" onClick={() => setEditing(null)}>Mégse</Button>
                </div>
              </div>}
            </DialogContent>
          </Dialog>

          {/* Termék kártyák kategóriánként */}
          {categories.map((cat) => {
            const catProducts = products.filter((p) => p.category === cat);
            if (catProducts.length === 0) return null;
            return (
              <div key={cat} className="space-y-2">
                <div className="flex items-center gap-2">
                  <Tag className="w-3.5 h-3.5 text-primary" />
                  <h3 className="text-primary font-semibold text-sm uppercase tracking-wide">{cat}</h3>
                  <span className="text-xs text-muted-foreground">({catProducts.length})</span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {catProducts.map((p) => (
                    <Card key={p._id} className={`border overflow-hidden transition-opacity ${p.is_available === false ? 'bg-muted border-border opacity-60' : 'bg-card border-border'}`}>
                      <div className="h-28 bg-muted flex items-center justify-center overflow-hidden relative">
                        {p.image ? (
                          <img src={p.image} alt={p.name} className={`w-full h-full object-cover ${p.is_available === false ? 'grayscale' : ''}`} onError={(e) => { (e.target as HTMLImageElement).src = ''; (e.target as HTMLImageElement).style.display = 'none'; }} />
                        ) : (
                          <ImageIcon className="w-8 h-8 text-muted-foreground/20" />
                        )}
                        {p.is_available === false && (
                          <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                            <span className="text-red-400 text-xs font-bold uppercase tracking-wider">Nem elérhető</span>
                          </div>
                        )}
                      </div>
                      <CardContent className="p-4">
                        <div className="flex justify-between items-start">
                          <div className="flex-1 min-w-0 pr-2">
                            <h3 className={`font-bold truncate ${p.is_available === false ? 'text-muted-foreground line-through' : 'text-foreground'}`}>{p.name}</h3>
                            {p.description && <p className="text-muted-foreground text-xs line-clamp-1 mt-0.5">{p.description}</p>}
                          </div>
                          <Badge className="bg-primary/15 text-primary shrink-0">{p.price.toLocaleString()} Ft</Badge>
                        </div>
                        <div className="mt-2 text-xs text-muted-foreground">
                          Csomagolás: {p.packaging_fee} Ft | DRS: {p.drs_applies ? 'Igen' : 'Nem'}
                        </div>
                        <div className="mt-3 flex items-center justify-between gap-2 border-t border-border pt-3">
                          <div className="flex items-center gap-2">
                            <Switch
                              checked={p.is_available !== false}
                              onCheckedChange={(val) => onToggleAvailability(p._id, val)}
                            />
                            <span className={`text-xs ${p.is_available === false ? 'text-red-400' : 'text-green-400'}`}>
                              {p.is_available === false ? 'Nem elérhető' : 'Elérhető'}
                            </span>
                          </div>
                          <div className="flex gap-1">
                            <Button size="sm" variant="outline" className="border-border h-7 px-2" onClick={() => { const sanitized = { ...p, topping_groups: (p.topping_groups || []).filter((tg) => tg.group_id !== null) }; setEditing(sanitized); setImgMode(p.image?.startsWith('/uploads') ? 'file' : 'url'); }}>
                              <Edit2 className="w-3 h-3" />
                            </Button>
                            <Button size="sm" variant="ghost" className="text-red-400 h-7 px-2" onClick={() => onDelete(p._id)}>
                              <Trash2 className="w-3 h-3" />
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            );
          })}

          {/* Kategória nélküli termékek */}
          {products.filter((p) => !categories.includes(p.category)).length > 0 && (
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Tag className="w-3.5 h-3.5 text-muted-foreground" />
                <h3 className="text-muted-foreground font-semibold text-sm uppercase tracking-wide">Egyéb (ismeretlen kategória)</h3>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                {products.filter((p) => !categories.includes(p.category)).map((p) => (
                  <Card key={p._id} className={`border overflow-hidden transition-opacity ${p.is_available === false ? 'bg-muted border-border opacity-60' : 'bg-card border-border'}`}>
                    <div className="h-28 bg-muted flex items-center justify-center overflow-hidden relative">
                      {p.image ? (
                        <img src={p.image} alt={p.name} className={`w-full h-full object-cover ${p.is_available === false ? 'grayscale' : ''}`} />
                      ) : (
                        <ImageIcon className="w-8 h-8 text-muted-foreground/20" />
                      )}
                      {p.is_available === false && (
                        <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                          <span className="text-red-400 text-xs font-bold uppercase tracking-wider">Nem elérhető</span>
                        </div>
                      )}
                    </div>
                    <CardContent className="p-4">
                      <div className="flex justify-between items-start">
                        <div className="flex-1 min-w-0 pr-2">
                          <h3 className={`font-bold truncate ${p.is_available === false ? 'text-muted-foreground line-through' : 'text-foreground'}`}>{p.name}</h3>
                          <p className="text-yellow-400/70 text-xs">{p.category}</p>
                        </div>
                        <Badge className="bg-primary/15 text-primary shrink-0">{p.price.toLocaleString()} Ft</Badge>
                      </div>
                      <div className="mt-3 flex items-center justify-between gap-2 border-t border-border pt-3">
                        <div className="flex items-center gap-2">
                          <Switch
                            checked={p.is_available !== false}
                            onCheckedChange={(val) => onToggleAvailability(p._id, val)}
                          />
                          <span className={`text-xs ${p.is_available === false ? 'text-red-400' : 'text-green-400'}`}>
                            {p.is_available === false ? 'Nem elérhető' : 'Elérhető'}
                          </span>
                        </div>
                        <div className="flex gap-1">
                          <Button size="sm" variant="outline" className="border-border h-7 px-2" onClick={() => setEditing({ ...p, topping_groups: (p.topping_groups || []).filter((tg) => tg.group_id !== null) })}>
                            <Edit2 className="w-3 h-3" />
                          </Button>
                          <Button size="sm" variant="ghost" className="text-red-400 h-7 px-2" onClick={() => onDelete(p._id)}>
                            <Trash2 className="w-3 h-3" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {products.length === 0 && (
            <p className="text-muted-foreground text-center py-10">Még nincs termék. Kattints az "Új termék" gombra!</p>
          )}
        </div>
      )}
    </div>
  );
}

function OpeningHoursManager({ hours, onChange, onSave, manualOverride, onToggleManual, forceManual, onResetAuto }: any) {
  const days = [
    { key: 'monday', label: 'Hétfő' },
    { key: 'tuesday', label: 'Kedd' },
    { key: 'wednesday', label: 'Szerda' },
    { key: 'thursday', label: 'Csütörtök' },
    { key: 'friday', label: 'Péntek' },
    { key: 'saturday', label: 'Szombat' },
    { key: 'sunday', label: 'Vasárnap' },
  ];

  const updateDay = (day: string, field: string, value: string) => {
    onChange({ ...hours, [day]: { ...hours[day], [field]: value } });
  };

  return (
    <div className="space-y-6">
      <Card className="bg-card border border-border">
        <CardContent className="p-6 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold text-foreground">Azonnali kapcsoló</h2>
              <p className="text-muted-foreground text-sm mt-1">
                {forceManual
                  ? <span className="text-yellow-400 font-semibold">⚠ Manuális felülírás aktív — az auto-schedule szünetel</span>
                  : 'Az automatikus nyitvatartás szerint működik'}
              </p>
            </div>
            <div className="flex items-center gap-3">
              <span className={`font-bold ${manualOverride ? 'text-green-400' : 'text-red-400'}`}>
                {manualOverride ? 'NYITVA' : 'ZÁRVA'}
              </span>
              <Switch checked={manualOverride} onCheckedChange={onToggleManual} />
            </div>
          </div>
          {forceManual && (
            <div className="flex items-center gap-3 pt-2 border-t border-yellow-400/20">
              <p className="text-sm text-muted-foreground flex-1">
                A manuális beállítás aktív. Az automatikus ütemezés a következő nyitás/zárás időpontban visszaveszi az irányítást — vagy most is visszaállíthatod.
              </p>
              <Button size="sm" variant="outline" className="border-yellow-400/50 text-yellow-400 shrink-0" onClick={onResetAuto}>
                Auto visszaállítás
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      <Card className="bg-card border border-border">
        <CardHeader><CardTitle className="text-foreground">Automatikus nyitvatartás</CardTitle></CardHeader>
        <CardContent className="p-6 space-y-4">
          {days.map((d) => (
            <div key={d.key} className="grid grid-cols-3 gap-4 items-center">
              <span className="text-foreground font-medium">{d.label}</span>
              <Input type="time" value={hours[d.key]?.open || '10:00'} onChange={(e) => updateDay(d.key, 'open', e.target.value)} className="bg-secondary border-border" />
              <Input type="time" value={hours[d.key]?.close || '22:00'} onChange={(e) => updateDay(d.key, 'close', e.target.value)} className="bg-secondary border-border" />
            </div>
          ))}
          <Button className="btn-primary-gradient text-white mt-4" onClick={onSave}>Mentés</Button>
        </CardContent>
      </Card>
    </div>
  );
}

function ArchiveView() {
  const [allOrders, setAllOrders] = useState<Order[]>([]);
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');

  const load = async () => {
    try {
      const res = await orderApi.getAllOrders(fromDate || undefined, toDate || undefined);
      setAllOrders(res.data);
    } catch {
      toast.error('Betöltés sikertelen');
    }
  };

  useEffect(() => {
    load();
  }, []);

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-bold text-foreground">Archívum</h2>
      <div className="flex gap-3">
        <Input type="date" value={fromDate} onChange={(e) => setFromDate(e.target.value)} className="bg-secondary border-border text-foreground" />
        <Input type="date" value={toDate} onChange={(e) => setToDate(e.target.value)} className="bg-secondary border-border text-foreground" />
        <Button className="btn-primary-gradient text-white" onClick={load}>Szűrés</Button>
      </div>
      <div className="space-y-3">
        {allOrders.map((order) => (
          <Card key={order._id} className="bg-card border border-border">
            <CardContent className="p-4 flex justify-between items-center">
              <div>
                <span className="text-foreground font-bold">#{order._id.slice(-4)}</span>
                <p className="text-muted-foreground text-sm">{getDisplayName(order)}</p>
                <p className="text-muted-foreground text-xs">{new Date(order.createdAt).toLocaleString('hu-HU')}</p>
              </div>
              <div className="text-right">
                <Badge className={`${STATUS_COLORS[order.status]} text-white mb-1`}>{STATUS_LABELS[order.status]}</Badge>
                <p className="text-primary font-bold">{order.total} Ft</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}



// ─────────────────────────────────────────────────────────────────────────────
// ToppingManager — Öntet-csoportok kezelése
// ─────────────────────────────────────────────────────────────────────────────
function ToppingManager({ groups, onRefresh }: { groups: ToppingGroup[]; onRefresh: () => void }) {
  const [editingGroup, setEditingGroup] = useState<Partial<ToppingGroup> | null>(null);
  const [newOptionName, setNewOptionName] = useState('');
  const [newOptionPrice, setNewOptionPrice] = useState(0);
  const [saving, setSaving] = useState(false);

  const handleSaveGroup = async () => {
    if (!editingGroup?.name?.trim()) { toast.error('A csoport nevét add meg!'); return; }
    setSaving(true);
    try {
      if (editingGroup._id) {
        await toppingApi.update(editingGroup._id, editingGroup);
        toast.success('Öntet-csoport frissítve');
      } else {
        await toppingApi.create(editingGroup);
        toast.success('Öntet-csoport létrehozva');
      }
      setEditingGroup(null);
      onRefresh();
    } catch { toast.error('Mentés sikertelen'); }
    finally { setSaving(false); }
  };

  const handleDeleteGroup = async (id: string) => {
    if (!window.confirm('Biztosan törlöd ezt az öntet-csoportot?')) return;
    try {
      await toppingApi.delete(id);
      toast.success('Törölve');
      onRefresh();
    } catch { toast.error('Törlés sikertelen'); }
  };

  const addOption = () => {
    if (!newOptionName.trim()) return;
    const opts = [...(editingGroup?.options || []), { name: newOptionName.trim(), price: newOptionPrice }];
    setEditingGroup((prev) => prev ? { ...prev, options: opts } : prev);
    setNewOptionName('');
    setNewOptionPrice(0);
  };

  const removeOption = (idx: number) => {
    const opts = (editingGroup?.options || []).filter((_, i) => i !== idx);
    setEditingGroup((prev) => prev ? { ...prev, options: opts } : prev);
  };

  const startNew = () => setEditingGroup({ name: '', required: false, min_select: 0, max_select: 1, options: [] });

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-foreground font-bold text-lg flex items-center gap-2">
            <ChefHat className="w-5 h-5 text-primary" /> Öntet / Kiegészítő csoportok
          </h2>
          <p className="text-xs text-muted-foreground mt-0.5">
            Hozz létre csoportokat (pl. „Extra feltét", „Öntet"), majd az Étlap szerkesztőben rendeld hozzá a termékekhez.
          </p>
        </div>
        <Button className="btn-primary-gradient text-white shrink-0" onClick={startNew}>
          <Plus className="w-4 h-4 mr-1" /> Új csoport
        </Button>
      </div>

      {/* ── Szerkesztő / Létrehozó form ── */}
      {editingGroup && (
        <Card className="bg-card border border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-foreground text-base flex items-center gap-2">
              {editingGroup._id ? <><Edit2 className="w-4 h-4 text-primary" /> Csoport szerkesztése</> : <><Plus className="w-4 h-4 text-primary" /> Új kiegészítő csoport</>}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Alap adatok */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-sm text-muted-foreground">Csoport neve *</Label>
                <Input
                  placeholder="pl. Extra feltét, Öntet, Mártás"
                  value={editingGroup.name || ''}
                  onChange={(e) => setEditingGroup({ ...editingGroup, name: e.target.value })}
                  className="bg-secondary border-border focus:border-primary"
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm text-muted-foreground">Max. választható darab</Label>
                <Input
                  type="number" min={1} max={20}
                  value={editingGroup.max_select ?? 1}
                  onChange={(e) => setEditingGroup({ ...editingGroup, max_select: Number(e.target.value) })}
                  className="bg-secondary border-border focus:border-primary"
                />
                <p className="text-xs text-muted-foreground">1 = egyszeres választás · több = többszörös</p>
              </div>
            </div>

            {/* Kötelező kapcsoló */}
            <div className="flex items-center gap-3 py-2 px-3 rounded-lg bg-secondary border border-border">
              <Switch
                checked={editingGroup.required ?? false}
                onCheckedChange={(v) => setEditingGroup({ ...editingGroup, required: v })}
              />
              <div>
                <Label className="text-foreground text-sm cursor-pointer">Kötelező választás</Label>
                <p className="text-xs text-muted-foreground">Ha be van kapcsolva, a vásárló nem tud mentés nélkül folytatni</p>
              </div>
            </div>

            {/* Opciók listája */}
            <div className="space-y-2">
              <Label className="text-foreground text-sm font-semibold">Opciók ({(editingGroup.options || []).length} db)</Label>
              {(editingGroup.options || []).length === 0 ? (
                <div className="text-center py-4 border border-dashed border-border rounded-lg">
                  <p className="text-xs text-muted-foreground">Még nincs opció. Add hozzá az első tételt!</p>
                </div>
              ) : (
                <div className="space-y-1.5">
                  {(editingGroup.options || []).map((opt, idx) => (
                    <div key={idx} className="flex items-center gap-2 bg-secondary border border-border rounded-lg px-3 py-2.5">
                      <span className="flex-1 text-foreground text-sm font-medium">{opt.name}</span>
                      <span className={`text-sm shrink-0 ${opt.price > 0 ? 'text-primary' : 'text-muted-foreground'}`}>
                        {opt.price > 0 ? `+${opt.price.toLocaleString()} Ft` : 'Ingyenes'}
                      </span>
                      <button
                        className="text-red-400/70 hover:text-red-400 transition-colors p-1 rounded"
                        onClick={() => removeOption(idx)}
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              )}

              {/* Új opció hozzáadása sor */}
              <div className="flex gap-2 pt-1">
                <Input
                  placeholder="Opció neve (pl. Extra sajt)"
                  value={newOptionName}
                  onChange={(e) => setNewOptionName(e.target.value)}
                  onKeyDown={(e) => { if (e.key === 'Enter') addOption(); }}
                  className="bg-secondary border-border focus:border-primary flex-1"
                />
                <Input
                  type="number" min={0} placeholder="Ár (Ft)"
                  value={newOptionPrice || ''}
                  onChange={(e) => setNewOptionPrice(Number(e.target.value))}
                  className="bg-secondary border-border focus:border-primary w-28"
                />
                <Button
                  className="btn-primary-gradient text-white shrink-0"
                  onClick={addOption}
                  disabled={!newOptionName.trim()}
                >
                  <Plus className="w-4 h-4 mr-1" /> Hozzáad
                </Button>
              </div>
              <p className="text-xs text-muted-foreground">Enter-rel is hozzáadhatod · 0 Ft = ingyenes</p>
            </div>

            {/* Mentés gomb */}
            <div className="flex gap-2 pt-1 border-t border-border">
              <Button className="btn-primary-gradient text-white" onClick={handleSaveGroup} disabled={saving}>
                {saving ? <><Loader2 className="w-4 h-4 mr-1 animate-spin" />Mentés...</> : <><Check className="w-4 h-4 mr-1" />Mentés</>}
              </Button>
              <Button variant="ghost" className="border border-border text-primary hover:bg-primary/10" onClick={() => setEditingGroup(null)}>Mégse</Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* ── Üres állapot ── */}
      {groups.length === 0 && !editingGroup && (
        <div className="text-center py-14 border border-dashed border-border rounded-xl">
          <ChefHat className="w-10 h-10 text-muted-foreground/30 mx-auto mb-3" />
          <p className="text-muted-foreground font-medium">Még nincs kiegészítő csoport</p>
          <p className="text-xs text-muted-foreground mt-1">
            Kattints az „Új csoport" gombra a létrehozáshoz,<br />majd az Étlap szerkesztőjében rendeld hozzá a termékekhez.
          </p>
        </div>
      )}

      {/* ── Meglévő csoportok kártya-rács ── */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {groups.map((grp) => (
          <Card key={grp._id} className="bg-card border border-border h-full flex flex-col">
            <CardContent className="p-4 flex flex-col flex-1 space-y-3">
              {/* Fejléc */}
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1 min-w-0">
                  <h3 className="text-foreground font-bold truncate text-base">{grp.name}</h3>
                  <div className="flex items-center gap-1.5 mt-1 flex-wrap">
                    <span className={`text-xs px-1.5 py-0.5 rounded font-medium ${grp.required ? 'bg-red-500/20 text-red-400' : 'bg-green-500/15 text-green-400'}`}>
                      {grp.required ? 'Kötelező' : 'Opcionális'}
                    </span>
                    <span className="text-xs text-muted-foreground">max {grp.max_select} db</span>
                  </div>
                </div>
                <Badge className="bg-primary/15 text-primary shrink-0 border border-border">
                  {grp.options.length} opció
                </Badge>
              </div>

              {/* Opciók chipek */}
              <div className="flex flex-wrap gap-1.5 flex-1">
                {grp.options.map((opt, i) => (
                  <span key={opt._id || i} className="text-xs px-2 py-1 rounded-full bg-card/5 text-muted-foreground border border-border">
                    {opt.name}{opt.price > 0 ? ` +${opt.price} Ft` : ''}
                  </span>
                ))}
              </div>

              {/* Gombok */}
              <div className="flex gap-2 pt-1 border-t border-border mt-auto">
                <Button size="sm" variant="outline" className="flex-1 border-border text-primary hover:bg-primary/10" onClick={() => setEditingGroup({ ...grp })}>
                  <Edit2 className="w-3 h-3 mr-1" /> Szerkeszt
                </Button>
                <Button size="sm" variant="ghost" className="text-red-400 hover:text-red-300 hover:bg-red-500/10" onClick={() => handleDeleteGroup(grp._id)}>
                  <Trash2 className="w-3 h-3" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}

function CourierManagementView({
  couriers,
  courierForm,
  setCourierForm,
  editingCourier,
  setEditingCourier,
  loadData
}: any) {
  const handleSaveCourier = async () => {
    if (!courierForm.name) {
      toast.error('Kérlek add meg a futár nevét');
      return;
    }
    
    const payload = {
      name: courierForm.name,
      email: courierForm.email || `futar_${Date.now()}@szesztestverek.hu`,
      phone: courierForm.phone || '',
      password: courierForm.password || 'futar123'
    };

    try {
      if (editingCourier) {
        await adminApi.updateCourier(editingCourier, payload);
        toast.success('Futár frissítve');
      } else {
        await adminApi.createCourier(payload);
        toast.success('Futár létrehozva');
      }
      setCourierForm({ name: '', email: '', phone: '', password: '' });
      setEditingCourier(null);
      loadData();
    } catch (err: any) {
      toast.error(err.response?.data?.error || 'Hiba a futár mentésekor');
    }
  };

  const handleDeleteCourier = async (id: string) => {
    if (confirm('Biztosan törölni szeretnéd ezt a futárt?')) {
      try {
        await adminApi.deleteCourier(id);
        toast.success('Futár törölve');
        loadData();
      } catch (err: any) {
        toast.error(err.response?.data?.error || 'Hiba a futár törlésekor');
      }
    }
  };

  return (
    <div className="h-full overflow-y-auto p-4 space-y-6">
      <Card className="bg-card border-border shadow-sm">
        <CardHeader className="p-4 border-b border-border bg-muted/30">
          <CardTitle className="text-base font-bold text-foreground">
            {editingCourier ? 'Futár szerkesztése' : 'Új futár hozzáadása'}
          </CardTitle>
        </CardHeader>
        <CardContent className="p-4 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Név</Label>
              <Input
                value={courierForm.name}
                onChange={(e) => setCourierForm({ ...courierForm, name: e.target.value })}
                placeholder="Pl. Futár János"
              />
            </div>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            {editingCourier && (
              <Button
                variant="outline"
                onClick={() => {
                  setEditingCourier(null);
                  setCourierForm({ name: '', email: '', phone: '', password: '' });
                }}
              >
                Mégse
              </Button>
            )}
            <Button
              onClick={handleSaveCourier}
              className="bg-primary text-primary-foreground hover:bg-primary/90"
            >
              <Check className="w-4 h-4 mr-2" />
              {editingCourier ? 'Mentés' : 'Hozzáadás'}
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-card border-border shadow-sm">
        <CardHeader className="p-4 border-b border-border bg-muted/30">
          <CardTitle className="text-base font-bold text-foreground">Futárok listája</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {couriers.length === 0 ? (
            <div className="p-8 text-center text-muted-foreground">Nincsenek még futárok rögzítve.</div>
          ) : (
            <div className="divide-y divide-border">
              {couriers.map((courier: User) => (
                <div key={courier.id || (courier as any)._id} className="p-4 flex items-center justify-between hover:bg-muted/30 transition-colors">
                  <div>
                    <div className="font-bold text-foreground flex items-center gap-2">
                      <Truck className="w-4 h-4 text-primary" />
                      {courier.name}
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        setEditingCourier(courier.id || (courier as any)._id);
                        setCourierForm({
                          name: courier.name || '',
                          email: courier.email || '',
                          phone: courier.phone || '',
                          password: ''
                        });
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                      }}
                    >
                      <Edit2 className="w-4 h-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="destructive"
                      className="bg-red-50 text-red-600 hover:bg-red-100 hover:text-red-700 border-0"
                      onClick={() => handleDeleteCourier(courier.id || (courier as any)._id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
