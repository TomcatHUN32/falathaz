import { useParams } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { productApi, orderApi, settingsApi, authApi, toppingApi, cityApi, couponApi, favoriteApi, restaurantApi } from '@/services/api';
import { useAuth } from '@/contexts/AuthContext';
import { useSocket } from '@/contexts/SocketContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';
import type { Product, CartItem, ToppingGroup, ToppingOption, OrderItemExtra } from '@/types';
import AppHeader from '@/components/AppHeader';
import { ShoppingCart, Plus, Minus, Trash2, MapPin, CreditCard, Banknote, LogIn, UserPlus, ChefHat, UtensilsCrossed, Clock, Check, Loader2, Truck, Package, X, Info, Pizza, Coffee, Cake, Flame, Utensils, Salad, Beef, Heart, IceCream, Beer, Wine, Apple, Fish, Carrot, Croissant } from 'lucide-react';

const LOGO_URL = '/logo.png';

// Kategóriák: dinamikusan töltődnek az API-ból (settingsApi.getCategories)
const MIN_ORDER = 2500;
const CART_KEY = 'szt_cart';
const NOTES_KEY = 'szt_notes';
const PAYMENT_KEY = 'szt_payment';

const getDefaultImage = (cat: string) => {
  const c = cat.toLowerCase();
  if (c.includes('pizza')) return 'https://miaoda-site-img.s3cdn.medo.dev/images/KLing_817dfc06-ca90-4f3f-a657-5d8405777e84.jpg';
  if (c.includes('burger') || c.includes('hamburger')) return 'https://miaoda-site-img.s3cdn.medo.dev/images/KLing_631f7b2e-729e-4965-abc5-f4c05d7a2b5c.jpg';
  if (c.includes('leves')) return 'https://images.unsplash.com/photo-1547592180-85f173990554?q=80&w=800&auto=format&fit=crop';
  if (c.includes('ital')) return 'https://images.unsplash.com/photo-1544145945-f90425340c7e?q=80&w=800&auto=format&fit=crop';
  if (c.includes('desszert')) return 'https://images.unsplash.com/photo-1551024506-0baafc50c491?q=80&w=800&auto=format&fit=crop';
  if (c.includes('sült') || c.includes('marha')) return 'https://images.unsplash.com/photo-1544025162-83112c8a29a0?q=80&w=800&auto=format&fit=crop';
  if (c.includes('saláta')) return 'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?q=80&w=800&auto=format&fit=crop';
  return 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?q=80&w=800&auto=format&fit=crop'; // Default food
};

// Kosár mentése localStorage-ba
function saveCart(cart: CartItem[]) {
  try { localStorage.setItem(CART_KEY, JSON.stringify(cart)); } catch {}
}
function loadCart(): CartItem[] {
  try {
    const raw = localStorage.getItem(CART_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch { return []; }
}
function clearCart() {
  try {
    localStorage.removeItem(CART_KEY);
    localStorage.removeItem(NOTES_KEY);
    localStorage.removeItem(PAYMENT_KEY);
  } catch {}
}

export default function OnlineOrdering() {
  const { restaurantId } = useParams<{ restaurantId: string }>();
  const [restaurant, setRestaurant] = useState<any>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<string[]>(['Házias ételek', 'Sültek', 'Italok']);
  const [toppingGroups, setToppingGroups] = useState<ToppingGroup[]>([]);
  // Modal a termék konfigurálásához (öntet választás)
  const [configProduct, setConfigProduct] = useState<Product | null>(null);
  const [selectedExtras, setSelectedExtras] = useState<Record<string, string[]>>({});
  const [configNote, setConfigNote] = useState('');
  const [cart, setCart] = useState<CartItem[]>(() => loadCart());
  const [activeCategory, setActiveCategory] = useState('Házias ételek');
  const [isCartBouncing, setIsCartBouncing] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<'Készpénz' | 'Bankkártya'>(() => {
    try { return (localStorage.getItem(PAYMENT_KEY) as any) || 'Készpénz'; } catch { return 'Készpénz'; }
  });
  const [notes, setNotes] = useState(() => {
    try { return localStorage.getItem(NOTES_KEY) || ''; } catch { return ''; }
  });
  const [isOpen, setIsOpen] = useState(true);
  const [nextOpenTime, setNextOpenTime] = useState('');
  // Checkout szállítási cím — két mező: város + utca
  const [checkoutCity, setCheckoutCity] = useState('');
  const [usedPointsAmount, setUsedPointsAmount] = useState(0);
  const [checkoutStreet, setCheckoutStreet] = useState('');
  const [deliveryType, setDeliveryType] = useState<'szállítás' | 'elvitel'>('szállítás');
  const [cities, setCities] = useState<Array<{ _id: string; name: string; delivery_fee: number; free_delivery_threshold?: number }>>([]);
  const [couponCode, setCouponCode] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<{ name: string; code: string; discount_pct: number } | null>(null);
  const [couponLoading, setCouponLoading] = useState(false);
  const { user } = useAuth();
  const navigate = useNavigate();
  const { socket } = useSocket();
  const [favorites, setFavorites] = useState<string[]>([]);
  const [loyaltySettings, setLoyaltySettings] = useState({
    bronze_threshold: 10,
    silver_threshold: 50,
    gold_threshold: 100,
    vip_enabled: true,
    vip_discount_pct: 10,
    vip_free_shipping: true,
    points_usable_per_order: 1000
  });

  // Kosár perzisztálása minden változásnál
  useEffect(() => { saveCart(cart); }, [cart]);
  useEffect(() => { try { localStorage.setItem(NOTES_KEY, notes); } catch {} }, [notes]);
  useEffect(() => { try { localStorage.setItem(PAYMENT_KEY, paymentMethod); } catch {} }, [paymentMethod]);

  useEffect(() => {
    settingsApi.get('loyalty_settings').then(res => {
      const data = res.data?.value || res.data;
      if (data) setLoyaltySettings(data);
    }).catch(() => {});
  }, []);

  // Checkout cím inicializálása bejelentkezett felhasználónál
  useEffect(() => {
    if (user?.default_address) {
      const parts = user.default_address.split(',');
      if (parts.length >= 2) {
        setCheckoutCity(parts[0].trim());
        setCheckoutStreet(parts.slice(1).join(',').trim());
      } else {
        setCheckoutCity(user.default_address.trim());
      }
    }
    
    // Kedvencek betöltése ha be van jelentkezve
    if (user) {
      favoriteApi.getFavorites().then((res: any) => {
        if (res.data && Array.isArray(res.data)) {
          setFavorites(res.data.filter((f: any) => f.product).map((f: any) => f.product._id));
        }
      }).catch((err: any) => console.error('Hiba a kedvencek betöltésekor', err));
    } else {
      setFavorites([]);
    }
  }, [user]);

  useEffect(() => {
    loadProducts();
    checkOpeningHours();
    cityApi.getAll().then((res) => {
      setCities(Array.isArray(res.data) ? res.data : []);
    }).catch(() => setCities([]));
    // Percenkénti polling (fallback)
    const interval = setInterval(checkOpeningHours, 60_000);
    return () => clearInterval(interval);
  }, []);

  // Valós idejű nyitvatartás-frissítés a backend auto-schedule socket eseményén keresztül
  useEffect(() => {
    if (!socket) return;
    const handleAutoChanged = (data: { is_open: boolean; reason?: string }) => {
      setIsOpen(data.is_open);
      if (data.is_open) {
        setNextOpenTime('');
      }
    };
    socket.on('auto_open_changed', handleAutoChanged);
    return () => { socket.off('auto_open_changed', handleAutoChanged); };
  }, [socket]);

  
  const loadRestaurant = async () => {
    try {
      if (restaurantId) {
        const res = await restaurantApi.getById(restaurantId);
        setRestaurant(res.data);
      }
    } catch {}
  };

  const loadProducts = async () => {
    try {
      const [prodRes, catRes, toppingRes] = await Promise.all([
        productApi.getAll(),
        settingsApi.getCategories(),
        toppingApi.getAll(),
      ]);
      setProducts(Array.isArray(prodRes.data) ? prodRes.data : []);
      setToppingGroups(Array.isArray(toppingRes.data) ? toppingRes.data : []);
      if (Array.isArray(catRes.data) && catRes.data.length > 0) {
        setCategories(catRes.data);
        setActiveCategory((prev) => catRes.data.includes(prev) ? prev : catRes.data[0]);
      }
    } catch {
      toast.error('Nem sikerült betölteni az étlapot');
    }
  };

  const toggleFavorite = async (e: React.MouseEvent, productId: string) => {
    e.stopPropagation(); // Ne nyissa meg a kosár gombot, ha az egész kártya kattintható lenne
    if (!user) {
      toast.info('Kedvencekhez bejelentkezés szükséges!');
      return;
    }
    try {
      if (favorites.includes(productId)) {
        await favoriteApi.removeFavorite(productId);
        setFavorites(prev => prev.filter(id => id !== productId));
        toast.success('Eltávolítva a kedvencek közül');
      } else {
        try {
          await favoriteApi.addFavorite(productId);
          setFavorites(prev => [...prev, productId]);
          toast.success('Hozzáadva a kedvencekhez');
        } catch (addErr: any) {
          if (addErr.response?.status === 400 && addErr.response?.data?.message === 'Already in favorites') {
            setFavorites(prev => [...prev, productId]);
          } else {
            throw addErr;
          }
        }
      }
    } catch (err) {
      toast.error('Hiba történt a mentés során');
    }
  };

  const checkOpeningHours = async () => {
    try {
      const res = await settingsApi.getAll();
      const manual = res.data.manual_override;
      const hours = res.data.opening_hours;
      const now = new Date();
      const dayNames = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
      const dayKey = dayNames[now.getDay()] as keyof typeof hours;
      const todayHours = hours?.[dayKey];
      const currentTime = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

      let open = false;
      if (manual?.is_open !== undefined) {
        open = manual.is_open;
      } else if (todayHours) {
        open = currentTime >= todayHours.open && currentTime < todayHours.close;
      }
      setIsOpen(open);
      if (!open) setNextOpenTime(todayHours?.open || '10:00');
    } catch {
      setIsOpen(true);
    }
  };

  // Termék közvetlen kosárba adása (öntet nélkül, vagy konfigurált extrassal)
  const addToCartWithExtras = (product: Product, extras: OrderItemExtra[], note: string = '') => {
    // Ha vannak extras, minden extra kombináció egyedi sor (eltérő extras = eltérő sor). A megjegyzés is számít.
    const extrasKey = extras.map((e) => e.option_id).sort().join('|') + '|note:' + note;
    
    setCart((prev) => {
      const existing = prev.find((i) => {
        const iKey = (i.extras || []).map((e) => e.option_id).sort().join('|') + '|note:' + (i.note || '');
        return i.product_id === product._id && iKey === extrasKey;
      });
      if (existing) {
        return prev.map((i) => {
          const iKey = (i.extras || []).map((e) => e.option_id).sort().join('|') + '|note:' + (i.note || '');
          return i.product_id === product._id && iKey === extrasKey
            ? { ...i, quantity: i.quantity + 1 }
            : i;
        });
      }
      return [...prev, {
        product_id: product._id,
        name: product.name,
        quantity: 1,
        price: product.price,
        packaging_fee: product.packaging_fee,
        drs_applies: product.drs_applies,
        extras,
        note: note || undefined,
        product,
      }];
    });
    toast.success(`${product.name} hozzáadva a kosárhoz`);
    
    // Animáció trigger
    setIsCartBouncing(true);
    setTimeout(() => setIsCartBouncing(false), 500);
  };

  const addToCart = (product: Product) => {
    // Ha a terméknek nincs extrája, egyből a kosárba tesszük (így gyorsabb)
    if (!product.topping_groups || product.topping_groups.length === 0) {
      addToCartWithExtras(product, []);
      return;
    }
    // Különben nyílik a modal
    setConfigProduct(product);
    setSelectedExtras({});
    setConfigNote('');
  };

  const updateQuantity = (productId: string, delta: number, extrasKey?: string) => {
    setCart((prev) =>
      prev.map((i) => {
        const iKey = (i.extras || []).map((e) => e.option_id).sort().join('|') + '|note:' + (i.note || '');
        const match = i.product_id === productId && (extrasKey === undefined || iKey === extrasKey);
        return match ? { ...i, quantity: Math.max(0, i.quantity + delta) } : i;
      }).filter((i) => i.quantity > 0)
    );
  };

  const removeFromCart = (productId: string, extrasKey?: string) => {
    setCart((prev) => prev.filter((i) => {
      const iKey = (i.extras || []).map((e) => e.option_id).sort().join('|') + '|note:' + (i.note || '');
      return !(i.product_id === productId && (extrasKey === undefined || iKey === extrasKey));
    }));
  };

  const subtotal = cart.reduce((s, i) => s + (i.price + (i.extras || []).reduce((es, e) => es + e.price, 0)) * i.quantity, 0);
  const packagingTotal = cart.reduce((s, i) => s + i.packaging_fee * i.quantity, 0);
  const drsTotal = cart.reduce((s, i) => s + (i.drs_applies ? 50 * i.quantity : 0), 0);
  // Szállítási díj: kizárólag a kiválasztott város alapján (manuálisan beállított)
  // Ingyenes szállítás, ha a részösszeg eléri a város specifikus küszöböt
  const selectedCity = cities.find((c) => c.name === checkoutCity) || null;
  let deliveryFee = deliveryType === 'elvitel' ? 0 : (selectedCity?.delivery_fee ?? 0);
  const cityThreshold = selectedCity?.free_delivery_threshold || 0;
  if (cityThreshold > 0 && subtotal >= cityThreshold) {
    deliveryFee = 0;
  }
  
  // Kedvezmény számítása (kupon)
  const discountPct = appliedCoupon ? appliedCoupon.discount_pct : 0;
  const discountAmount = Math.round((subtotal * Math.min(Math.max(discountPct, 0), 100)) / 100);
  const finalTotal = Math.max(0, subtotal + packagingTotal + drsTotal + deliveryFee - discountAmount - usedPointsAmount);
  const minProgress = Math.min((subtotal / MIN_ORDER) * 100, 100);
  
  // Progressz sáv a Premium/Ingyenes szállításhoz
  let progressTarget = cityThreshold;
  let progressMessage = '';
  if (deliveryType === 'elvitel') {
    progressTarget = 0;
    progressMessage = 'Elvitel esetén nincs szállítási díj!';
  } else if (cityThreshold > 0) {
    const remaining = cityThreshold - subtotal;
    if (remaining > 0) {
      progressMessage = `Még ${remaining.toLocaleString('hu-HU')} Ft az ingyenes szállításig!`;
    } else {
      progressMessage = 'Gratulálunk! Ingyenes a szállításod!';
    }
  } else {
    progressTarget = 0;
    progressMessage = selectedCity ? `Szállítás: ${selectedCity.delivery_fee.toLocaleString('hu-HU')} Ft` : 'Válassz várost a pontos díjhoz!';
  }
  const freeDeliveryProgress = progressTarget > 0 ? Math.min((subtotal / progressTarget) * 100, 100) : 100;

  // Összefűzött szállítási cím (mentéshez + validációhoz)
  const checkoutAddress = [checkoutCity, checkoutStreet].filter(Boolean).join(', ');
  const canOrder = subtotal >= MIN_ORDER && isOpen && !!user && (deliveryType === 'elvitel' || (selectedCity !== null && checkoutStreet.trim().length >= 3));

  // Fizetés gomb megnyomásakor auth ellenőrzés
  const handleGoToCheckout = () => {
    if (!user) {
      // Kosár megmarad localStorage-ban, bejelentkezés után visszatér ide
      setIsCartOpen(false);
      toast.info('Rendeléshez bejelentkezés szükséges!');
      navigate(`/login?redirect=${encodeURIComponent('/menu')}`);
      return;
    }
    setIsCartOpen(false);
    setIsCheckoutOpen(true);
  };

  const handleOrder = async () => {
    if (!user) {
      navigate(`/login?redirect=${encodeURIComponent('/menu')}`);
      return;
    }
    if (subtotal < MIN_ORDER) {
      toast.error(`Minimum rendelési összeg: ${MIN_ORDER} Ft`);
      return;
    }
    const addr = deliveryType === 'elvitel' ? 'Elvitel' : checkoutAddress.trim();
    if (deliveryType === 'szállítás' && !addr) {
      toast.error('Kérjük, adj meg szállítási címet!');
      return;
    }

    try {
      // Ha a cím eltér a profilban mentett címtől, frissítjük a profilt
      if (addr !== user.default_address) {
        await authApi.updateProfile({ default_address: addr });
      }

      const items = cart.map((i) => ({
        product_id: i.product_id,
        name: i.name,
        quantity: i.quantity,
        price: i.price + (i.extras || []).reduce((s, e) => s + e.price, 0),
        packaging_fee: i.packaging_fee,
        drs_applies: i.drs_applies,
        extras: i.extras || [],
        note: i.note,
      }));

      const res = await orderApi.create({
        items,
        payment_method: paymentMethod,
        delivery_type: deliveryType,
        address: addr,
        notes,
        city_id: selectedCity?._id ?? undefined,
        city_name: selectedCity?.name ?? checkoutCity.trim(),
        street: checkoutStreet.trim() || undefined,
        discount_pct: appliedCoupon?.discount_pct ?? 0,
        coupon_code: appliedCoupon?.code || undefined,
        coupon_name: appliedCoupon?.name || undefined,
        used_points: usedPointsAmount,
      });

      // Sikeres fizetés után újra lekérjük a felhasználó adatait (pontlevonás miatt)
      if (usedPointsAmount > 0) {
        try {
           const { authApi } = await import('@/services/api');
           authApi.me().then(res => {
             // Nem frissítem az Auth contextet, de az oldalt esetleg újra tölthetjük vagy a használt pontokat lenullázzuk.
             // Legalább a felhasznált pont mennyiséget nullázzuk.
             setUsedPointsAmount(0);
           });
        } catch {}
      }

      toast.success('Rendelés sikeresen leadva! Köszönjük a rendelését!');
      clearCart();
      setCart([]);
      setNotes('');
      setIsCheckoutOpen(false);
      setCouponCode('');
      setAppliedCoupon(null);
      setUsedPointsAmount(0);
    } catch (err: any) {
      toast.error(err.response?.data?.error || 'Rendelés sikertelen');
    }
  };

  const filteredProducts = Array.isArray(products)
    ? products.filter((p) => p.category === activeCategory)
    : [];

  const cartButton = (
    <Sheet open={isCartOpen} onOpenChange={setIsCartOpen}>
      <SheetTrigger asChild>
        <button
          className={`relative flex items-center gap-2 h-10 px-5 rounded-full font-bold text-sm transition-all duration-300 ${
            isCartBouncing ? 'bg-white text-primary scale-110 shadow-[0_0_30px_rgba(255,255,255,0.8)]' : 'bg-[#ea5a0c] text-white hover:opacity-90'
          }`}
        >
          <ShoppingCart className={`w-4 h-4 transition-transform duration-300 ${isCartBouncing ? 'scale-125' : ''}`} />
          <span>Kosár</span>
          {cart.length > 0 && (
            <span className={`absolute -top-1.5 -right-1.5 text-[#111] text-[11px] rounded-full w-5 h-5 flex items-center justify-center font-bold leading-none bg-white transition-transform duration-300 ${isCartBouncing ? 'scale-150 bg-green-500' : ''}`}>
              {cart.reduce((s, i) => s + i.quantity, 0)}
            </span>
          )}
        </button>
      </SheetTrigger>
      <SheetContent className="theme-restaurant w-full sm:max-w-md max-h-screen overflow-y-auto bg-card border-l border-border text-foreground">
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2 text-foreground">
            <ShoppingCart className="w-5 h-5 text-primary" />
            Kosár
          </SheetTitle>
        </SheetHeader>
        <div className="mt-4 space-y-4">
          {cart.length === 0 ? (
            <p className="text-center py-12 text-muted-foreground">A kosár üres</p>
          ) : (
            <>
              {cart.map((item, idx) => {
                const extrasKey = (item.extras || []).map((e) => e.option_id).sort().join('|') + '|note:' + (item.note || '');
                return (
                  <div key={item.product_id + extrasKey} className="flex items-center gap-3 rounded-xl p-3 bg-muted border border-border animate-in fade-in slide-in-from-right-8 fill-mode-both" style={{ animationDuration: '400ms', animationDelay: `${idx * 100}ms` }}>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium truncate text-foreground">{item.name}</p>
                      <p className="text-sm text-muted-foreground">{item.price} Ft/db</p>
                      {(item.extras || []).length > 0 && (
                        <p className="text-xs mt-0.5 text-primary">
                          {(item.extras || []).map((e) => e.option_name).join(', ')}
                        </p>
                      )}
                      {item.note && (
                        <p className="text-xs mt-0.5 text-primary italic">
                          Megjegyzés: {item.note}
                        </p>
                      )}
                      {item.packaging_fee > 0 && <p className="text-xs text-muted-foreground">+{item.packaging_fee} Ft csomagolás</p>}
                      {item.drs_applies && <p className="text-xs text-destructive">+50 Ft DRS</p>}
                    </div>
                    <div className="flex items-center gap-1.5 shrink-0">
                      <button className="h-8 w-8 flex items-center justify-center rounded-md transition-opacity hover:opacity-80 bg-secondary border border-border text-secondary-foreground" onClick={() => updateQuantity(item.product_id, -1, extrasKey)}>
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="font-bold w-6 text-center text-sm text-foreground">{item.quantity}</span>
                      <button className="h-8 w-8 flex items-center justify-center rounded-md transition-opacity hover:opacity-80 bg-secondary border border-border text-secondary-foreground" onClick={() => updateQuantity(item.product_id, 1, extrasKey)}>
                        <Plus className="w-3 h-3" />
                      </button>
                      <button className="h-8 w-8 flex items-center justify-center rounded-md text-destructive" onClick={() => removeFromCart(item.product_id, extrasKey)}>
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                );
              })}

              <div className="h-px bg-white/10" />

              {/* Ingyenes szállítás progress bar */}
              <div className="space-y-2 p-3 bg-primary/5 border border-primary/20 rounded-xl">
                <div className="flex justify-between text-xs font-medium">
                  <span className="text-white/80">{progressMessage}</span>
                  <span className={freeDeliveryProgress >= 100 ? "text-green-400 font-bold" : "text-primary font-bold"}>
                    {Math.min(freeDeliveryProgress, 100).toFixed(0)}%
                  </span>
                </div>
                <div className="h-2 rounded-full overflow-hidden bg-black/50 border border-white/5">
                  <div className={`h-full rounded-full transition-all duration-500 shadow-[0_0_10px_rgba(234,90,12,0.5)] ${freeDeliveryProgress >= 100 ? "bg-green-500 shadow-[0_0_10px_rgba(34,197,94,0.5)]" : "bg-primary"}`} style={{ width: `${freeDeliveryProgress}%` }} />
                </div>
              </div>

              {/* Upsell szekció */}
              {cart.length > 0 && products.filter(p => ['Üdítő', 'Desszert', 'Szósz'].includes(p.category) && !cart.some(c => c.product_id === p._id)).slice(0, 2).length > 0 && (
                <div className="space-y-3 pt-2">
                  <h4 className="text-sm font-semibold text-white/90">Esetleg hozzáadjuk?</h4>
                  <div className="grid grid-cols-2 gap-2">
                    {products.filter(p => ['Üdítő', 'Desszert', 'Szósz'].includes(p.category) && !cart.some(c => c.product_id === p._id)).slice(0, 2).map(upsellProduct => (
                      <div key={`upsell-${upsellProduct._id}`} className="bg-white/5 border border-white/10 rounded-xl p-2.5 flex items-center justify-between group">
                        <div className="flex-1 min-w-0 pr-2">
                          <p className="text-xs font-semibold text-white truncate">{upsellProduct.name}</p>
                          <p className="text-[10px] text-primary">+{upsellProduct.price} Ft</p>
                        </div>
                        <button 
                          onClick={() => addToCart(upsellProduct)}
                          className="w-7 h-7 rounded-full bg-primary/20 text-primary flex items-center justify-center shrink-0 transition-colors group-hover:bg-primary group-hover:text-white"
                        >
                          <Plus className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="h-px bg-white/10" />

              <div className="space-y-1.5 text-sm rounded-xl p-4 bg-[#0a0806] border border-[#2e2616]">
                <div className="flex justify-between text-muted-foreground"><span>Részösszeg</span><span>{subtotal} Ft</span></div>
                {packagingTotal > 0 && <div className="flex justify-between text-muted-foreground"><span>Csomagolás</span><span>{packagingTotal} Ft</span></div>}
                {drsTotal > 0 && <div className="flex justify-between text-muted-foreground"><span>DRS</span><span>{drsTotal} Ft</span></div>}
                {discountAmount > 0 && (
                  <div className="flex justify-between text-green-500">
                    <span>Kedvezmény ({appliedCoupon?.name})</span>
                    <span>-{discountAmount.toLocaleString('hu-HU')} Ft</span>
                  </div>
                )}
                <div className="flex justify-between font-bold text-base pt-1.5 border-t border-border text-foreground">
                  <span>Fizetendő</span>
                  <span className="text-primary">{finalTotal.toLocaleString('hu-HU')} Ft</span>
                </div>
              </div>

              {!user ? (
                <div className="space-y-2">
                  <p className="text-xs text-center py-2 px-3 rounded-lg text-primary bg-primary/10 border border-primary/20">
                    Rendeléshez bejelentkezés szükséges. A kosár megmarad!
                  </p>
                  <div className="grid grid-cols-2 gap-2">
                    <button className="flex items-center justify-center gap-1.5 h-10 rounded-xl font-semibold text-sm bg-primary text-primary-foreground shadow-[0_0_15px_rgba(234,90,12,0.3)] transition-all hover:shadow-[0_0_25px_rgba(234,90,12,0.5)]" onClick={() => { setIsCartOpen(false); navigate(`/login?redirect=${encodeURIComponent('/menu')}`); }}>
                      <LogIn className="w-4 h-4" /> Belépés
                    </button>
                    <button className="flex items-center justify-center gap-1.5 h-10 rounded-xl font-medium text-sm border border-primary/50 text-primary bg-primary/5 hover:bg-primary/10 transition-colors" onClick={() => { setIsCartOpen(false); navigate(`/register?redirect=${encodeURIComponent('/menu')}`); }}>
                      <UserPlus className="w-4 h-4" /> Regisztráció
                    </button>
                  </div>
                </div>
              ) : (
                <button
                  className="w-full font-bold h-12 rounded-xl text-base transition-all hover:opacity-90 disabled:opacity-40 disabled:hover:shadow-none bg-primary text-primary-foreground shadow-[0_0_15px_rgba(234,90,12,0.3)] hover:shadow-[0_0_25px_rgba(234,90,12,0.5)]"
                  disabled={subtotal < MIN_ORDER || !isOpen}
                  onClick={handleGoToCheckout}
                >
                  {!isOpen ? 'Az étterem zárva van' : subtotal < MIN_ORDER ? `Minimum ${MIN_ORDER} Ft szükséges` : 'Tovább a fizetéshez →'}
                </button>
              )}
            </>
          )}
        </div>
      </SheetContent>
    </Sheet>
  );


  // ── Segédfüggvények a konfiguráló modalhoz ─────────────────────────────────
  const buildExtras = (): import('@/types').OrderItemExtra[] => {
    if (!configProduct) return [];
    const result: import('@/types').OrderItemExtra[] = [];
    for (const [groupId, optionIds] of Object.entries(selectedExtras)) {
      // Keresés a flat toppingGroups listában ÉS a populált group_id objektumban
      let grp: import('@/types').ToppingGroup | undefined = toppingGroups.find((g) => g._id === groupId);
      if (!grp) {
        const tgRef = (configProduct.topping_groups || []).find((tg) =>
          (typeof tg.group_id === 'object' ? (tg.group_id as import('@/types').ToppingGroup)._id : tg.group_id as string) === groupId
        );
        if (tgRef && typeof tgRef.group_id === 'object') grp = tgRef.group_id as import('@/types').ToppingGroup;
      }
      if (!grp) continue;
      for (const optId of optionIds) {
        const opt = grp.options.find((o) => o._id === optId);
        if (opt) result.push({ group_id: grp._id, group_name: grp.name, option_id: opt._id ?? '', option_name: opt.name, price: opt.price });
      }
    }
    return result;
  };

  const canConfirmConfig = (): boolean => {
    if (!configProduct) return false;
    for (const tg of (configProduct.topping_groups || [])) {
      const grp = typeof tg.group_id === 'object'
        ? tg.group_id as import('@/types').ToppingGroup
        : toppingGroups.find((g) => g._id === (tg.group_id as string));
      if (!grp) continue;
      if (tg.required) {
        const sel = selectedExtras[grp._id] || [];
        if (sel.length === 0) return false;
      }
    }
    return true;
  };

  return (
    <div className="theme-restaurant min-h-screen bg-background text-foreground selection:bg-primary/30 flex flex-col">
      <AppHeader isOpen={isOpen} rightSlot={cartButton} darkMode />

      {!isOpen && (
        <div className="text-center py-2 px-4 text-sm font-medium bg-destructive/10 text-destructive border-b border-destructive/20 sticky top-[65px] z-40">
          Az étterem jelenleg zárva van. Következő nyitás: {nextOpenTime}
        </div>
      )}

      {/* Hero szekció - Új dizájn */}
      <section className="relative min-h-[550px] flex items-center bg-[#0c0a07] border-b border-[#2e2616] overflow-hidden mt-[-65px] pt-[65px]">
        {/* Bal oldali sötét maszk a szöveg mögé */}
        <div className="absolute inset-y-0 left-0 w-full md:w-3/5 bg-gradient-to-r from-[#0c0a07] via-[#0c0a07]/90 to-transparent z-10" />
        
        {/* Jobb oldali nagy kép */}
        <div 
          className="absolute inset-0 md:left-1/3 bg-cover bg-center bg-no-repeat opacity-60 md:opacity-100"
          style={{ 
            backgroundImage: 'url(https://miaoda-site-img.s3cdn.medo.dev/images/KLing_4f0b1fee-5c7c-4302-b9c5-2b779dce9519.jpg)',
            maskImage: 'linear-gradient(to right, transparent, black 20%)',
            WebkitMaskImage: 'linear-gradient(to right, transparent, black 20%)'
          }}
        />
        
        {/* Nyitvatartás Badge (Jobb alsó sarok) */}
        <div className="absolute bottom-8 right-8 z-20 hidden lg:flex flex-col bg-[#16120b]/85 backdrop-blur-xl border border-white/10 rounded-2xl p-5 shadow-2xl min-w-[200px]">
          <div className="flex items-center gap-2 mb-4 text-white">
            <Clock className="w-5 h-5 text-primary" />
            <span className="text-base font-bold tracking-wide">Nyitvatartás</span>
          </div>
          <div className="flex flex-col gap-2.5 text-sm">
            <div className="flex justify-between items-center"><span className="text-white/60">Hétfő</span><span className="font-semibold text-white">11:00 - 21:00</span></div>
            <div className="flex justify-between items-center"><span className="text-white/60">Kedd</span><span className="font-semibold text-white">11:00 - 21:00</span></div>
            <div className="flex justify-between items-center"><span className="text-white/60">Szerda</span><span className="font-semibold text-white">11:00 - 21:00</span></div>
            <div className="flex justify-between items-center"><span className="text-white/60">Csütörtök</span><span className="font-semibold text-white">11:00 - 21:00</span></div>
            <div className="flex justify-between items-center"><span className="text-white/60">Péntek</span><span className="font-semibold text-white">11:00 - 21:30</span></div>
            <div className="flex justify-between items-center"><span className="text-white/60">Szombat</span><span className="font-semibold text-white">11:00 - 21:30</span></div>
            <div className="flex justify-between items-center pt-2 mt-1 border-t border-white/10"><span className="text-white/80 font-medium">Vasárnap</span><span className="font-bold text-primary">11:00 - 19:00</span></div>
          </div>
        </div>

        <div className="relative max-w-6xl mx-auto px-6 py-20 flex flex-col items-center justify-center text-center gap-6 w-full z-20 animate-in fade-in slide-in-from-bottom-8 duration-1000">
          
          <div className="flex items-center gap-3 text-primary font-bold tracking-[0.2em] text-xs md:text-sm uppercase mb-2">
            <span className="w-12 h-px bg-primary/60"></span>
            KIVÁLÓ MINŐSÉG, GYORS KISZÁLLÍTÁS
            <span className="w-12 h-px bg-primary/60"></span>
          </div>
          
          <h1 className="font-black tracking-tight leading-[1.05] text-balance max-w-4xl mx-auto">
            <span className="block text-5xl md:text-7xl text-white drop-shadow-2xl">Szesztestvérek</span>
            <span className="block text-6xl md:text-8xl mt-2 bg-gradient-to-r from-[#d4af37] via-[#f3e5ab] to-[#d4af37] bg-clip-text text-transparent drop-shadow-lg">Falatház</span>
          </h1>
          
          <p className="text-lg md:text-xl text-white/70 font-medium mt-4 text-pretty leading-relaxed max-w-2xl mx-auto">
            Rendelj kényelmesen online, mi pedig frissen készítjük el és házhoz visszük kedvenc ételeidet!
          </p>

          <div className="flex flex-wrap gap-4 justify-center mt-6 mb-4">
            <div className="flex items-center gap-2 rounded-full px-5 py-2.5 text-sm bg-black/40 backdrop-blur-md border border-[#d4af37]/30 text-white/90">
              <MapPin className="w-4 h-4 text-primary" />
              <span>Szuhogy, József Attila út 78.</span>
            </div>
            <div className="flex items-center gap-2 rounded-full px-5 py-2.5 text-sm bg-black/40 backdrop-blur-md border border-[#d4af37]/30 text-white/90">
              <Truck className="w-4 h-4 text-primary" />
              <span>Min. rendelés: {MIN_ORDER} Ft</span>
            </div>
          </div>

          <div className="flex justify-center mt-4">
            <button
              className="flex items-center gap-3 font-bold h-14 px-10 text-sm md:text-base rounded-full transition-all duration-300 hover:scale-105 bg-gradient-to-r from-[#c59b27] to-[#e8c86b] text-black shadow-[0_8px_30px_rgba(212,175,55,0.3)] border border-[#f3e5ab]/50"
              onClick={() => document.getElementById('etlap')?.scrollIntoView({ behavior: 'smooth' })}
            >
              <UtensilsCrossed className="w-5 h-5" />
              ÉTLAP MEGTEKINTÉSE
            </button>
          </div>
        </div>
      </section>

      {/* Étlap */}
      <main id="etlap" className="max-w-6xl mx-auto w-full px-4 py-12 flex-1">
        
        {/* Kategória fejléc */}
        <div className="flex flex-col items-center justify-center mb-8">
          <div className="flex items-center gap-2 text-primary font-bold tracking-widest text-xs uppercase mb-2">
            <span className="w-8 h-px bg-primary"></span>
            VÁLOGASS KEDVEDRE
            <span className="w-8 h-px bg-primary"></span>
          </div>
          <h2 className="text-3xl md:text-4xl font-black text-white">Kategóriáink</h2>
        </div>

        {/* Kategória tab-ok */}
        <div className="flex gap-3 md:gap-4 overflow-x-auto pb-6 pt-2 snap-x justify-start md:justify-center mb-10 w-full" style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}>
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`snap-center shrink-0 px-6 py-3 rounded-2xl transition-all duration-300 font-bold tracking-wide text-sm md:text-base shadow-sm ${
                activeCategory === cat
                  ? "bg-primary text-primary-foreground shadow-[0_0_20px_rgba(234,90,12,0.3)] scale-105"
                  : "bg-secondary text-white/70 hover:text-white hover:bg-white/10"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Termék rácsozat (fejléc nélkül) */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 pt-8">
          {products.filter((p) => p.category === activeCategory).map((product, idx) => (
            <div
              key={product._id}
              className={`group flex flex-col overflow-hidden rounded-2xl bg-[#0c0a07] border border-[#2e2616] transition-all duration-300 hover:-translate-y-1.5 hover:shadow-[0_12px_40px_rgba(234,88,12,0.12)] animate-in fade-in zoom-in-95 fill-mode-both ${product.is_available === false ? 'opacity-50' : ''}`} style={{ animationDuration: '600ms', animationDelay: `${idx * 75}ms` }}
            >
              {/* Termék kép */}
              <div className="relative overflow-hidden w-full aspect-[4/3] bg-muted/30">
                <img
                  src={product.image || getDefaultImage(product.category)}
                  alt={product.name}
                  className={`w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 ${product.is_available === false ? 'grayscale' : ''}`}
                />
                {product.is_available === false && (
                  <div className="absolute inset-0 flex items-center justify-center bg-black/60 backdrop-blur-sm z-20">
                    <span className="text-xs font-bold px-3 py-1.5 rounded-full text-white bg-destructive border border-destructive/50 shadow-lg">NEM ELÉRHETŐ</span>
                  </div>
                )}
                {/* Alsó árnyék effektus a képen */}
                <div className="absolute inset-x-0 bottom-0 h-40 bg-gradient-to-t from-[#0c0a07] via-[#0c0a07]/80 to-transparent z-10" />
              </div>

              {/* Termék info - Most egy fekete doboz kártyán belül */}
              <div className="p-4 pt-16 flex flex-col flex-1 relative z-10 bg-transparent mt-[-5rem]">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-bold text-lg leading-tight text-balance text-white">{product.name}</h3>
                  <button 
                    onClick={(e) => toggleFavorite(e, product._id)}
                    className={`transition-all shrink-0 ml-2 ${favorites.includes(product._id) ? 'text-primary' : 'text-white/30 hover:text-primary'}`} 
                    title="Kedvencekhez adás"
                  >
                    <Heart className={`w-5 h-5 ${favorites.includes(product._id) ? 'fill-primary' : ''}`} />
                  </button>
                </div>
                <div className="flex flex-col flex-1">
                  <p className="text-sm mb-4 line-clamp-2 flex-1 text-pretty text-white/70 font-medium leading-relaxed">{product.description}</p>
                </div>

                {(product.packaging_fee > 0 || product.drs_applies) && (
                  <div className="flex flex-wrap gap-2 mb-4">
                    {product.packaging_fee > 0 && (
                      <span className="text-[11px] font-medium px-2 py-0.5 rounded-md bg-white/5 text-white/60 border border-white/10">
                        +{product.packaging_fee} Ft csomag.
                      </span>
                    )}
                    {product.drs_applies && (
                      <span className="text-[11px] font-medium px-2 py-0.5 rounded-md bg-white/5 text-white/60 border border-white/10">
                        +50 Ft DRS
                      </span>
                    )}
                  </div>
                )}

                <div className="flex items-center justify-between mt-auto">
                  <div className="flex flex-col">
                    {product.original_price && (
                      <span className="text-xs font-medium text-white/50 line-through mb-0.5">
                        {product.original_price.toLocaleString('hu-HU')} Ft
                      </span>
                    )}
                    <span className="font-extrabold text-xl text-primary">
                      {product.price.toLocaleString('hu-HU')} Ft
                    </span>
                  </div>
                  {product.is_available === false ? (
                    <div className="h-10 px-4 flex items-center justify-center rounded-full text-sm font-bold cursor-not-allowed bg-white/5 text-white/40 border border-white/10">
                      Kifogyott
                    </div>
                  ) : (
                    <button
                      className="w-10 h-10 shrink-0 rounded-full flex items-center justify-center font-bold transition-all hover:scale-110 active:scale-95 bg-[#ea5a0c] text-white shadow-[0_4px_14px_rgba(234,88,12,0.3)] hover:shadow-[0_6px_20px_rgba(234,88,12,0.5)]"
                      onClick={() => addToCart(product)}
                    >
                      <Plus className="w-5 h-5" />
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </main>

      {/* Checkout panel */}
      <Sheet open={isCheckoutOpen} onOpenChange={setIsCheckoutOpen}>
        <SheetContent className="theme-restaurant bg-background text-foreground w-full sm:max-w-lg overflow-y-auto border-l border-border">
          <SheetHeader>
            <SheetTitle className="text-foreground flex items-center gap-2">
              <CreditCard className="w-5 h-5 text-primary" />
              Rendelés véglegesítése
            </SheetTitle>
          </SheetHeader>
          <div className="mt-6 space-y-5">

            <div>
              <Label className="text-sm text-muted-foreground mb-2 block">Fizetési mód</Label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setPaymentMethod('Készpénz')}
                  className={`flex items-center gap-2 justify-center py-3 rounded-xl border text-sm font-medium transition-all ${
                    paymentMethod === 'Készpénz'
                      ? 'bg-primary/15 border-primary/60 text-primary'
                      : 'bg-muted border-border text-muted-foreground hover:border-primary/30'
                  }`}
                >
                  <Banknote className="w-4 h-4" /> Készpénz
                </button>
                <button
                  type="button"
                  onClick={() => setPaymentMethod('Bankkártya')}
                  className={`flex items-center gap-2 justify-center py-3 rounded-xl border text-sm font-medium transition-all ${
                    paymentMethod === 'Bankkártya'
                      ? 'bg-primary/15 border-primary/60 text-primary'
                      : 'bg-muted border-border text-muted-foreground hover:border-primary/30'
                  }`}
                >
                  <CreditCard className="w-4 h-4" /> Bankkártya
                </button>
              </div>
            </div>

            {/* Kupon kód */}
            <div className="space-y-2">
              <Label className="text-sm text-muted-foreground">Kupon kód</Label>
              {appliedCoupon ? (
                <div className="flex items-center gap-2 p-2.5 rounded-lg border border-green-500/30 bg-green-500/10">
                  <Check className="w-4 h-4 text-green-400 shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-green-300">{appliedCoupon.name} (-{appliedCoupon.discount_pct}%)</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => { setAppliedCoupon(null); setCouponCode(''); }}
                    className="text-xs text-muted-foreground hover:text-foreground shrink-0"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <div className="flex gap-2">
                  <Input
                    value={couponCode}
                    onChange={(e) => setCouponCode(e.target.value.toUpperCase())}
                    placeholder="Kupon kód"
                    className="h-10 flex-1"
                  />
                  <Button
                    type="button"
                    variant="outline"
                    onClick={async () => {
                      if (!couponCode.trim()) return;
                      setCouponLoading(true);
                      try {
                        const res = await couponApi.validate(couponCode.trim());
                        setAppliedCoupon(res.data);
                        toast.success(`Kupon alkalmazva: ${res.data.name} (-${res.data.discount_pct}%)`);
                      } catch (err: any) {
                        toast.error(err.response?.data?.error || 'Érvénytelen kuponkód');
                      } finally {
                        setCouponLoading(false);
                      }
                    }}
                    disabled={couponLoading || !couponCode.trim()}
                    className="h-10 shrink-0"
                  >
                    {couponLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Alkalmaz'}
                  </Button>
                </div>
              )}
            </div>

            {/* Pontfelhasználás */}
            {user && user.role !== 'admin' && (
              <div className="space-y-2 pt-2 border-t border-border">
                <div className="flex justify-between items-center">
                  <Label className="text-sm text-muted-foreground">Pontok felhasználása</Label>
                  <span className="text-xs font-medium text-primary">Elérhető: {(user as any).points || 0} pont</span>
                </div>
                <div className="flex gap-2 items-center">
                  <Input
                    type="number"
                    min="0"
                    max={Math.min((user as any).points || 0, loyaltySettings.points_usable_per_order || 1000)}
                    value={usedPointsAmount || ''}
                    onChange={(e) => {
                      const val = parseInt(e.target.value) || 0;
                      const maxUsable = Math.min((user as any).points || 0, loyaltySettings.points_usable_per_order || 1000);
                      setUsedPointsAmount(Math.min(val, maxUsable));
                    }}
                    placeholder="Felhasználni kívánt pontok"
                    className="h-10 flex-1"
                  />
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      const maxUsable = Math.min((user as any).points || 0, loyaltySettings.points_usable_per_order || 1000);
                      setUsedPointsAmount(maxUsable);
                    }}
                    className="h-10 shrink-0 px-3 text-xs"
                  >
                    Max ({Math.min((user as any).points || 0, loyaltySettings.points_usable_per_order || 1000)})
                  </Button>
                </div>
                {usedPointsAmount > 0 && (
                  <p className="text-xs text-green-400 mt-1">-{usedPointsAmount} Ft kedvezmény a pontokból</p>
                )}
              </div>
            )}

            {/* Rendelés típusa toggle */}
              <div className="space-y-2">
                <Label className="text-sm text-muted-foreground">Rendelés típusa</Label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setDeliveryType('szállítás')}
                    className={`flex items-center gap-2 justify-center py-3 rounded-xl border text-sm font-medium transition-all ${
                      deliveryType === 'szállítás'
                        ? 'bg-primary/15 border-primary/60 text-primary'
                        : 'bg-muted border-border text-muted-foreground hover:border-primary/30'
                    }`}
                  >
                    <Truck className="w-4 h-4" /> Szállítás
                  </button>
                  <button
                    type="button"
                    onClick={() => setDeliveryType('elvitel')}
                    className={`flex items-center gap-2 justify-center py-3 rounded-xl border text-sm font-medium transition-all ${
                      deliveryType === 'elvitel'
                        ? 'bg-primary/15 border-primary/60 text-primary'
                        : 'bg-muted border-border text-muted-foreground hover:border-primary/30'
                    }`}
                  >
                    <Package className="w-4 h-4" /> Elvitel
                  </button>
                </div>
                {deliveryType === 'elvitel' && (
                <p className="text-primary font-medium text-xs flex items-center gap-1.5 mt-2">
                  <Check className="w-3 h-3" /> Elvitelnél nincs szállítási díj — vedd át személyesen!
                </p>
              )}
            </div>

            {deliveryType === 'szállítás' && (
            <div className="space-y-2">
              <Label className="text-sm text-muted-foreground flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-primary" /> Szállítási cím
              </Label>
              <div className="flex gap-2">
                <select
                  value={checkoutCity}
                  onChange={(e) => setCheckoutCity(e.target.value)}
                  className="profile-input w-2/5 shrink-0 appearance-none cursor-pointer"
                >
                  <option value="">-- Válassz várost --</option>
                  {cities.map((c) => (
                    <option key={c._id} value={c.name}>{c.name}</option>
                  ))}
                </select>
                <Input
                  value={checkoutStreet}
                  onChange={(e) => setCheckoutStreet(e.target.value)}
                  placeholder="Utca, házszám"
                  className="profile-input flex-1 min-w-0"
                />
              </div>
              {selectedCity && (
                <div className="flex items-start gap-1.5 text-xs text-primary">
                  <Check className="w-3 h-3 mt-0.5 shrink-0" />
                  <span className="text-pretty">
                    {selectedCity.name} — {deliveryFee === 0 ? 'Ingyenes szállítás' : `${selectedCity.delivery_fee.toLocaleString('hu-HU')} Ft szállítás`}
                  </span>
                </div>
              )}
              {cityThreshold > 0 && deliveryType === 'szállítás' && deliveryFee > 0 && (
                <div className="flex items-start gap-1.5 text-xs text-primary">
                  <Info className="w-3 h-3 mt-0.5 shrink-0" />
                  <span className="text-pretty">
                    {cityThreshold.toLocaleString('hu-HU')} Ft felett ingyenes a szállítás ide: {checkoutCity}! (Még {(cityThreshold - subtotal).toLocaleString('hu-HU')} Ft)
                  </span>
                </div>
              )}
              {cityThreshold > 0 && deliveryType === 'szállítás' && deliveryFee === 0 && (
                <div className="flex items-start gap-1.5 text-xs text-primary">
                  <Check className="w-3 h-3 mt-0.5 shrink-0" />
                  <span className="text-pretty">
                    Gratulálunk! A rendelésedre ingyenes szállítás jár!
                  </span>
                </div>
              )}
              {!selectedCity && checkoutCity && (
                <p className="text-xs text-destructive">A város nem található a listában.</p>
              )}
              {(!checkoutCity.trim() || !checkoutStreet.trim()) && deliveryType === 'szállítás' && (
                <p className="text-xs text-destructive">Város és utca megadása kötelező</p>
              )}
            </div>
            )}

            <div>
              <Label className="text-sm text-muted-foreground mb-2 block">Megjegyzés</Label>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Pl. ERŐSEN CSÍPŐS!, HAGYMA NÉLKÜL!"
                className="w-full profile-input rounded-lg p-3 text-sm resize-none"
                rows={3}
              />
            </div>

            <div className="neon-divider" />

            <div className="space-y-1.5 text-sm">
              <div className="flex justify-between text-muted-foreground"><span>Részösszeg</span><span>{subtotal} Ft</span></div>
              {packagingTotal > 0 && <div className="flex justify-between text-muted-foreground"><span>Csomagolási díj</span><span>{packagingTotal} Ft</span></div>}
              {drsTotal > 0 && <div className="flex justify-between text-muted-foreground"><span>DRS visszaváltási díj</span><span>{drsTotal} Ft</span></div>}
              <div className="flex justify-between text-muted-foreground items-center">
                <span>{deliveryType === 'elvitel' ? 'Szállítás' : 'Szállítási díj'}</span>
                <span>
                  {deliveryType === 'elvitel'
                    ? <span className="text-primary font-medium">Személyes átvétel — ingyenes</span>
                    : selectedCity
                      ? (deliveryFee === 0
                          ? <span className="text-primary">Ingyenes {cityThreshold > 0 && selectedCity.delivery_fee > 0 ? '(küszöb alapján)' : ''}</span>
                          : <span className="text-foreground">{selectedCity.delivery_fee.toLocaleString('hu-HU')} Ft</span>)
                      : <span className="text-muted-foreground text-xs">—</span>
                  }
                </span>
              </div>
              {discountAmount > 0 && (
                <div className="flex justify-between text-primary">
                  <span>Kedvezmény ({appliedCoupon?.name})</span>
                  <span>-{discountAmount.toLocaleString('hu-HU')} Ft</span>
                </div>
              )}
              <div className="flex justify-between text-foreground font-bold text-lg pt-2 border-t border-border">
                <span>Fizetendő</span>
                <span className="text-primary">{finalTotal.toLocaleString('hu-HU')} Ft</span>
              </div>
            </div>

            <Button
              className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-bold text-base h-12 rounded-xl shadow-[0_0_15px_rgba(234,90,12,0.3)] transition-all hover:shadow-[0_0_25px_rgba(234,90,12,0.5)]"
              disabled={!canOrder}
              onClick={handleOrder}
            >
              Rendelés leadása →
            </Button>
            {subtotal < MIN_ORDER && (
              <p className="text-destructive text-xs text-center">
                A minimum rendelési összeg {MIN_ORDER} Ft (jelenleg: {subtotal} Ft)
              </p>
            )}
          </div>
        </SheetContent>
      </Sheet>

      {/* ── Termék konfiguráló modal (öntet / kiegészítő választás) ──────────── */}
      <Dialog open={!!configProduct} onOpenChange={(open) => { 
        if (!open) { 
          setConfigProduct(null); 
          setConfigNote(''); 
        } 
      }}>
        <DialogContent className="bg-card border border-primary/30 max-w-[calc(100%-2rem)] md:max-w-lg max-h-[90dvh] overflow-y-auto" aria-describedby={undefined}>
          <DialogTitle className="sr-only">Termék testreszabása</DialogTitle>
          <DialogHeader>
            <DialogTitle className="text-foreground text-balance">{configProduct?.name}</DialogTitle>
          </DialogHeader>
          {configProduct && (
            <div className="space-y-4 pt-1">
              {configProduct.image && (
                <div className="h-40 rounded-lg overflow-hidden">
                  <img src={configProduct.image} alt={configProduct.name} className="w-full h-full object-cover" />
                </div>
              )}
              <div className="flex items-center gap-2">
                <p className="text-primary font-bold text-lg">
                  {configProduct.price.toLocaleString('hu-HU')} Ft
                </p>
                {configProduct.original_price && (
                  <span className="text-xs text-white/50 line-through">
                    {configProduct.original_price.toLocaleString('hu-HU')} Ft
                  </span>
                )}
              </div>
              {configProduct.description && (
                <p className="text-muted-foreground text-sm text-pretty">{configProduct.description}</p>
              )}

              {/* Öntet-csoportok */}
              {(configProduct.topping_groups || []).map((tgRef) => {
                const grp = typeof tgRef.group_id === 'object'
                  ? tgRef.group_id as import('@/types').ToppingGroup
                  : toppingGroups.find((g) => g._id === (tgRef.group_id as string));
                if (!grp) return null;
                const sel = selectedExtras[grp._id] || [];
                const maxSel = tgRef.max_select ?? grp.max_select ?? 1;
                const isRequired = tgRef.required ?? grp.required ?? false;
                const isSingle = maxSel === 1;
                return (
                  <div key={grp._id} className="space-y-2">
                    <div className="flex items-center gap-2">
                      <h4 className="text-foreground font-semibold text-sm">{grp.name}</h4>
                      {isRequired
                        ? <span className="text-xs px-1.5 py-0.5 rounded bg-red-500/20 text-red-400">Kötelező</span>
                        : <span className="text-xs px-1.5 py-0.5 rounded bg-card/10 text-muted-foreground">Opcionális</span>
                      }
                      {!isSingle && <span className="text-xs text-muted-foreground">max {maxSel} db</span>}
                    </div>
                    {/* Darabszám-számláló több-választásos csoporthoz */}
                    {!isSingle && (
                      <p className={`text-xs mb-1 ${sel.length >= maxSel ? 'text-primary font-medium' : 'text-muted-foreground'}`}>
                        {sel.length}/{maxSel} kiválasztva{sel.length >= maxSel ? ' — maximum elérve' : ''}
                      </p>
                    )}
                    <div className="space-y-1.5">
                      {grp.options.map((opt, optIdx) => {
                        const isSelected = sel.includes(opt._id ?? '');
                        const maxReached = !isSingle && sel.length >= maxSel && !isSelected;
                        return (
                          <button
                            key={opt._id ?? optIdx}
                            disabled={maxReached}
                            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg border transition-colors text-left ${
                              isSelected
                                ? 'border-primary bg-primary/10'
                                : maxReached
                                  ? 'border-border bg-card opacity-40 cursor-not-allowed'
                                  : 'border-border bg-secondary hover:border-primary/40'
                            }`}
                            onClick={() => {
                              if (maxReached) return;
                              setSelectedExtras((prev) => {
                                const current = prev[grp._id] || [];
                                if (isSingle) {
                                  return { ...prev, [grp._id]: isSelected ? [] : [opt._id ?? ''] };
                                } else {
                                  if (isSelected) {
                                    return { ...prev, [grp._id]: current.filter((id) => id !== (opt._id ?? '')) };
                                  } else if (current.length < maxSel) {
                                    return { ...prev, [grp._id]: [...current, opt._id ?? ''] };
                                  }
                                  return prev;
                                }
                              });
                            }}
                          >
                            <div className="flex items-center gap-2.5">
                              <div className={`w-4 h-4 rounded-${isSingle ? 'full' : 'sm'} border-2 flex items-center justify-center shrink-0 ${
                                isSelected ? 'border-primary bg-primary' : 'border-white/30'
                              }`}>
                                {isSelected && <Check className="w-2.5 h-2.5 text-primary-foreground" />}
                              </div>
                              <span className="text-sm text-white">{opt.name}</span>
                            </div>
                            <span className={`text-sm shrink-0 ${opt.price > 0 ? 'text-primary font-medium' : 'text-white/40'}`}>
                              {opt.price > 0 ? `+${opt.price.toLocaleString('hu-HU')} Ft` : 'Ingyenes'}
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                );
              })}

              <div className="space-y-2 mt-4 mb-2">
                <Label className="text-sm font-semibold text-foreground">Tételszintű megjegyzés <span className="text-muted-foreground font-normal text-xs">(opcionális)</span></Label>
                <textarea
                  className="w-full h-20 p-3 rounded-lg border border-border bg-secondary text-sm focus:outline-none focus:border-primary resize-none text-foreground"
                  placeholder="Pl.: Hagyma nélkül, kevésbé csípősen..."
                  value={configNote}
                  onChange={(e) => setConfigNote(e.target.value)}
                />
              </div>

              <Button
                className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-semibold h-12 shadow-[0_0_15px_rgba(234,90,12,0.3)] transition-all hover:shadow-[0_0_25px_rgba(234,90,12,0.5)]"
                disabled={!canConfirmConfig()}
                onClick={() => {
                  const extras = buildExtras();
                  addToCartWithExtras(configProduct, extras, configNote);
                  setConfigProduct(null);
                  setSelectedExtras({});
                  setConfigNote('');
                }}
              >
                <ShoppingCart className="w-5 h-5 mr-2" />
                Kosárba
                {buildExtras().reduce((sum, e) => sum + e.price, 0) > 0 && (
                  <span className="ml-1.5 text-primary-foreground/80 font-normal">
                    (+{buildExtras().reduce((sum, e) => sum + e.price, 0).toLocaleString('hu-HU')} Ft)
                  </span>
                )}
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
