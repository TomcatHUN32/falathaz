import React, { useEffect, useState } from 'react';
import { superadminApi } from '../services/superadminApi';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Trash2, Edit2, LogOut } from 'lucide-react';

const SuperAdmin = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [restaurants, setRestaurants] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  
  const [form, setForm] = useState({ name: '', county: '', city: '', address: '', license_type: 'monthly', license_expiry: '' });
  const [editingId, setEditingId] = useState<string | null>(null);

  useEffect(() => {
    if (!user || user.role !== 'superadmin') {
      navigate('/login');
      return;
    }
    loadData();
  }, [user, navigate]);

  const loadData = async () => {
    try {
      const res = await superadminApi.getRestaurants();
      setRestaurants(res.data);
    } catch (e) {
      toast.error('Hiba az éttermek lekérésekor');
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingId) {
        await superadminApi.updateRestaurant(editingId, form);
        toast.success('Étterem frissítve');
      } else {
        await superadminApi.createRestaurant(form);
        toast.success('Étterem létrehozva');
      }
      setForm({ name: '', county: '', city: '', address: '', license_type: 'monthly', license_expiry: '' });
      setEditingId(null);
      loadData();
    } catch (e: any) {
      toast.error(e.response?.data?.error || 'Hiba mentéskor');
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Biztosan törlöd ezt az éttermet?')) return;
    try {
      await superadminApi.deleteRestaurant(id);
      toast.success('Étterem törölve');
      loadData();
    } catch (e) {
      toast.error('Hiba törléskor');
    }
  };

  if (loading) return null;

  return (
    <div className="min-h-screen w-full bg-background text-foreground p-6 md:p-12">
      <div className="max-w-7xl mx-auto space-y-8">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold">Szuper-Admin Felület</h1>
            <p className="text-muted-foreground">Éttermek és licencek kezelése</p>
          </div>
          <Button variant="outline" onClick={logout}>
            <LogOut className="w-4 h-4 mr-2" />
            Kijelentkezés
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <Card className="md:col-span-1 h-fit">
            <CardHeader>
              <CardTitle>{editingId ? 'Étterem Szerkesztése' : 'Új Étterem'}</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSave} className="space-y-4">
                <Input placeholder="Étterem neve" value={form.name} onChange={e => setForm({...form, name: e.target.value})} required />
                <Input placeholder="Megye" value={form.county} onChange={e => setForm({...form, county: e.target.value})} required />
                <Input placeholder="Város" value={form.city} onChange={e => setForm({...form, city: e.target.value})} required />
                <Input placeholder="Pontos cím" value={form.address} onChange={e => setForm({...form, address: e.target.value})} required />
                
                <Select value={form.license_type} onValueChange={(v) => {
                  let expiry = form.license_expiry;
                  if (v !== 'perpetual') {
                    const d = new Date();
                    if (v === 'monthly') d.setMonth(d.getMonth() + 1);
                    else if (v === 'quarterly') d.setMonth(d.getMonth() + 3);
                    else if (v === 'yearly') d.setFullYear(d.getFullYear() + 1);
                    // Adjust to YYYY-MM-DD for the date input
                    const yyyy = d.getFullYear();
                    const mm = String(d.getMonth() + 1).padStart(2, '0');
                    const dd = String(d.getDate()).padStart(2, '0');
                    expiry = `${yyyy}-${mm}-${dd}T00:00:00.000Z`;
                  } else {
                    expiry = '';
                  }
                  setForm({...form, license_type: v, license_expiry: expiry});
                }}>
                  <SelectTrigger><SelectValue placeholder="Licenc típusa" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="monthly">Havi</SelectItem>
                    <SelectItem value="quarterly">Negyedéves</SelectItem>
                    <SelectItem value="yearly">Éves</SelectItem>
                    <SelectItem value="perpetual">Örökös</SelectItem>
                  </SelectContent>
                </Select>

                {form.license_type !== 'perpetual' && (
                  <Input type="date" value={form.license_expiry ? form.license_expiry.split('T')[0] : ''} onChange={e => setForm({...form, license_expiry: e.target.value})} required />
                )}

                <div className="flex gap-2 pt-4">
                  <Button type="submit" className="flex-1">{editingId ? 'Mentés' : 'Létrehozás'}</Button>
                  {editingId && (
                    <Button type="button" variant="outline" onClick={() => { setEditingId(null); setForm({ name: '', county: '', city: '', address: '', license_type: 'monthly', license_expiry: '' }); }}>
                      Mégse
                    </Button>
                  )}
                </div>
              </form>
            </CardContent>
          </Card>

          <div className="md:col-span-2 space-y-4">
            <h2 className="text-xl font-bold">Regisztrált éttermek ({restaurants.length})</h2>
            <div className="grid gap-4">
              {restaurants.map(r => (
                <Card key={r._id} className="flex flex-col">
                  <CardContent className="p-4 flex justify-between items-center flex-1">
                    <div>
                      <h3 className="font-bold text-lg">{r.name}</h3>
                      <p className="text-sm text-muted-foreground">{r.county}, {r.city}, {r.address}</p>
                      <div className="text-sm mt-1">
                        <span className="font-semibold text-primary">
                          {r.license_type === 'perpetual' ? 'Örökös' : `Lejár: ${new Date(r.license_expiry).toLocaleDateString('hu-HU')}`}
                        </span>
                        {" | URL azonosító: "}
                        <span className="font-mono bg-muted px-1 py-0.5 rounded">{r._id}</span>
                      </div>
                    </div>
                    <div className="flex flex-col gap-2 shrink-0 ml-4">
                      <Button variant="outline" size="sm" onClick={() => {
                        setEditingId(r._id);
                        setForm({
                          name: r.name,
                          county: r.county,
                          city: r.city,
                          address: r.address,
                          license_type: r.license_type || 'monthly',
                          license_expiry: r.license_expiry || ''
                        });
                      }}>
                        <Edit2 className="w-4 h-4 mr-2" /> Szerkesztés
                      </Button>
                      <Button variant="destructive" size="sm" onClick={() => handleDelete(r._id)}>
                        <Trash2 className="w-4 h-4 mr-2" /> Törlés
                      </Button>
                      <Button variant="secondary" size="sm" onClick={() => window.open(`/${r._id}/menu`, '_blank')}>
                        Étlap
                      </Button>
                      <Button className="bg-[#b5255e] text-white hover:bg-[#b5255e]/90" size="sm" onClick={() => window.open(`/${r._id}/admin`, '_blank')}>
                        Admin Panel (Pro)
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
              {restaurants.length === 0 && (
                <p className="text-muted-foreground py-8 text-center">Még nincs regisztrált étterem.</p>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SuperAdmin;
