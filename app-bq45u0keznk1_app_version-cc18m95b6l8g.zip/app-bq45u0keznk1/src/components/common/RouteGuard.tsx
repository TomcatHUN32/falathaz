import { useEffect } from 'react';
import { useNavigate, useLocation, Navigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { routes } from '@/routes';

interface RouteGuardProps {
  children: React.ReactNode;
}

const SYSTEM_PUBLIC_ROUTES = ['/login', '/register', '/403', '/404'];
const routePublicPaths = routes.filter(r => r.public).map(r => r.path);
const PUBLIC_ROUTES = [...new Set([...SYSTEM_PUBLIC_ROUTES, ...routePublicPaths])];

function matchPublicRoute(path: string, patterns: string[]) {
  return patterns.some(pattern => {
    const regexStr = '^' + pattern.replace(/:[^/]+/g, '[^/]+').replace('*', '.*') + '$';
    return new RegExp(regexStr).test(path);
  });
}

export function RouteGuard({ children }: RouteGuardProps) {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const path = location.pathname;

  useEffect(() => {
    if (loading) return;
    const isPublic = matchPublicRoute(path, PUBLIC_ROUTES);
    if (!user && !isPublic) {
      navigate(`/login?redirect=${encodeURIComponent(path)}`, { replace: true });
    }
  }, [user, loading, path, navigate]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#0a0a0a]">
        <div className="flex flex-col items-center gap-3">
          <div className="w-12 h-12 rounded-full bg-gradient-to-br from-[#ff6000] to-[#cc0000] animate-pulse" />
          <p className="text-muted-foreground text-sm">Betöltés...</p>
        </div>
      </div>
    );
  }

  // Bejelentkezett felhasználó átirányítása a login/register oldalakról
  if (user && (path === '/login' || path === '/register')) {
    if (user.role === 'admin') return <Navigate to="/admin" replace />;
    if (user.role === 'courier') return <Navigate to="/courier" replace />;
    return <Navigate to="/" replace />;
  }

  // Szerepkör-alapú hozzáférés-védelem
  if (user && path === '/admin' && user.role !== 'admin') {
    return <Navigate to="/" replace />;
  }
  if (user && path === '/courier' && user.role !== 'courier' && user.role !== 'admin') {
    return <Navigate to="/" replace />;
  }

  return <>{children}</>;
}