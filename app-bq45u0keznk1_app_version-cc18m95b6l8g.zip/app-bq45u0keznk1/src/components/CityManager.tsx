import { useState, useEffect } from 'react';
import { cityApi } from '@/services/api';
import type { City } from '@/types';
import { toast } from 'sonner';
import { Plus, Trash2, Edit2, Check, X, MapPin } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';

export default function CityManager() {
  const [cities, setCities] = useState<City[]>([]);
  const [loading, setLoading] = useState(true);
  const [name, setName] = useState('');
  const [fee, setFee] = useState('');
  const [threshold, setThreshold] = useState('');
  const [editing, setEditing] = useState<City | null>(null);
  const [editName, setEditName] = useState('');
  const [editFee, setEditFee] = useState('');
  const [editThreshold, setEditThreshold] = useState('');

  const load = async () => {
    try {
      setLoading(true);
      const res = await cityApi.getAllAdmin();
      setCities(Array.isArray(res.data) ? res.data : []);
    } catch {
      toast.error('Városok betöltése sikertelen');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const handleAdd = async () => {
    const trimmed = name.trim();
    if (trimmed.length < 2) { toast.error('A város neve legalább 2 karakter legyen'); return; }
    const feeNum = Number(fee);
    if (isNaN(feeNum) || feeNum < 0) { toast.error('A szállítási díj nem lehet negatív'); return; }
    const threshNum = threshold === '' ? 0 : Number(threshold);
    if (isNaN(threshNum) || threshNum < 0) { toast.error('Az ingyenes szállítási küszöb nem lehet negatív'); return; }
    try {
      await cityApi.create({ name: trimmed, delivery_fee: feeNum, free_delivery_threshold: threshNum });
      toast.success('Város hozzáadva');
      setName(''); setFee(''); setThreshold('');
      load();
    } catch (err: any) {
      toast.error(err.response?.data?.error || 'Hozzáadás sikertelen');
    }
  };

  const handleUpdate = async () => {
    if (!editing) return;
    const trimmed = editName.trim();
    if (trimmed.length < 2) { toast.error('A város neve legalább 2 karakter legyen'); return; }
    const feeNum = Number(editFee);
    if (isNaN(feeNum) || feeNum < 0) { toast.error('A szállítási díj nem lehet negatív'); return; }
    const threshNum = editThreshold === '' ? 0 : Number(editThreshold);
    if (isNaN(threshNum) || threshNum < 0) { toast.error('Az ingyenes szállítási küszöb nem lehet negatív'); return; }
    try {
      await cityApi.update(editing._id, { name: trimmed, delivery_fee: feeNum, free_delivery_threshold: threshNum });
      toast.success('Város frissítve');
      setEditing(null);
      load();
    } catch (err: any) {
      toast.error(err.response?.data?.error || 'Frissítés sikertelen');
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Biztosan törlöd ezt a várost?')) return;
    try {
      await cityApi.delete(id);
      toast.success('Város törölve');
      load();
    } catch {
      toast.error('Törlés sikertelen');
    }
  };

  const handleToggle = async (city: City) => {
    try {
      await cityApi.update(city._id, { active: !city.active });
      load();
    } catch {
      toast.error('Állapot váltása sikertelen');
    }
  };

  return (
    <div className="space-y-6 w-full">
      {/* Új város */}
      <Card className="bg-card shadow-sm border-border">
        <CardHeader className="pb-3 border-b border-border bg-muted/30">
          <CardTitle className="text-base flex items-center gap-2">
            Új település rögzítése
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-4">
          <div className="flex flex-col sm:flex-row gap-4 items-end">
            <div className="flex-1 w-full">
              <Label className="text-xs text-muted-foreground block mb-1">Település neve</Label>
              <Input
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="pl. Budapest"
                className="w-full"
              />
            </div>
            <div className="w-full sm:w-32">
              <Label className="text-xs text-muted-foreground block mb-1">Szállítási díj (Ft)</Label>
              <Input
                type="number"
                min={0}
                value={fee}
                onChange={(e) => setFee(e.target.value)}
                placeholder="0"
                className="w-full"
              />
            </div>
            <div className="w-full sm:w-32">
              <Label className="text-xs text-muted-foreground block mb-1">Ingyen szállítás (Ft)</Label>
              <Input
                type="number"
                min={0}
                value={threshold}
                onChange={(e) => setThreshold(e.target.value)}
                placeholder="Nincs"
                className="w-full"
              />
            </div>
            <Button onClick={handleAdd} className="w-full sm:w-auto h-9">
              <Plus className="w-4 h-4 mr-1" /> Hozzáad
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Lista */}
      <Card className="bg-card shadow-sm border-border overflow-hidden">
        <CardHeader className="pb-3 border-b border-border bg-muted/30">
          <div className="flex items-center gap-2">
            <MapPin className="w-4 h-4 text-primary" />
            <CardTitle className="text-base">Települések listája</CardTitle>
          </div>
        </CardHeader>
        {loading ? (
          <div className="p-8 text-center text-muted-foreground text-sm">Betöltés...</div>
        ) : cities.length === 0 ? (
          <div className="p-8 text-center text-muted-foreground text-sm">Még nincs település felvéve.</div>
        ) : (
          <div className="divide-y divide-border">
            {cities.map((city) => (
              <div key={city._id} className="flex flex-col sm:flex-row sm:items-center justify-between px-4 py-3 gap-3 hover:bg-muted/10 transition-colors">
                {editing?._id === city._id ? (
                  <div className="flex-1 flex flex-wrap items-center gap-2">
                    <Input
                      value={editName}
                      onChange={(e) => setEditName(e.target.value)}
                      className="flex-1 min-w-[150px] h-8"
                    />
                    <Input
                      type="number"
                      min={0}
                      value={editFee}
                      onChange={(e) => setEditFee(e.target.value)}
                      className="w-24 h-8"
                    />
                    <Input
                      type="number"
                      min={0}
                      value={editThreshold}
                      onChange={(e) => setEditThreshold(e.target.value)}
                      className="w-24 h-8"
                      placeholder="Ingyen tól"
                    />
                    <Button variant="ghost" size="icon" className="text-green-600 hover:text-green-700 hover:bg-green-50 h-8 w-8" onClick={handleUpdate}>
                      <Check className="w-4 h-4" />
                    </Button>
                    <Button variant="ghost" size="icon" className="text-red-500 hover:text-red-600 hover:bg-red-50 h-8 w-8" onClick={() => setEditing(null)}>
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                ) : (
                  <>
                    <div className="flex flex-wrap items-center gap-3 flex-1 min-w-0">
                      <span className="font-semibold text-sm text-foreground truncate max-w-[200px]">{city.name}</span>
                      <span className="text-xs font-medium px-2 py-1 rounded bg-muted text-muted-foreground">
                        Szállítás: {city.delivery_fee === 0 ? 'Ingyenes' : `${city.delivery_fee.toLocaleString()} Ft`}
                      </span>
                      {(city.free_delivery_threshold || 0) > 0 && (
                        <span className="text-xs font-medium px-2 py-1 rounded bg-emerald-50 border border-emerald-100 text-emerald-600">
                          {city.free_delivery_threshold?.toLocaleString()} Ft-tól ingyenes
                        </span>
                      )}
                      {!city.active && <span className="text-[10px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded bg-gray-100 text-gray-500">Inaktív</span>}
                    </div>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleToggle(city)}
                        className={`h-7 px-2 text-xs font-semibold ${city.active ? 'border-green-200 text-green-700 bg-green-50 hover:bg-green-100' : 'border-gray-200 text-gray-500 bg-gray-50 hover:bg-gray-100'}`}
                      >
                        {city.active ? 'Aktív' : 'Inaktív'}
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => { setEditing(city); setEditName(city.name); setEditFee(String(city.delivery_fee)); setEditThreshold(city.free_delivery_threshold !== undefined && city.free_delivery_threshold !== null ? String(city.free_delivery_threshold) : ''); }}
                        className="h-7 w-7 text-muted-foreground"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleDelete(city._id)}
                        className="h-7 w-7 text-muted-foreground hover:text-red-500 hover:bg-red-50"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </Button>
                    </div>
                  </>
                )}
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}
