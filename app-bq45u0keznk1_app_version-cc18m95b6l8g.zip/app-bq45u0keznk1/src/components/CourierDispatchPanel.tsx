import { useState, useEffect } from 'react';
import type { Order, User } from '@/types';
import { X, ChevronDown, ChevronUp, Clock, Home } from 'lucide-react';

import { Bike, Navigation } from 'lucide-react';

function getCourierId(courierId: Order['courier_id']): string | null {
  if (!courierId) return null;
  if (typeof courierId === 'object') return (courierId as any)._id ?? (courierId as User).id ?? null;
  return courierId as string;
}

function ageMinutes(createdAt: string): number {
  return Math.floor((Date.now() - new Date(createdAt).getTime()) / 60_000);
}

interface Props {
  orders: Order[];
  couriers: User[];
  onStatusChange: (orderId: string, status: string, courierId?: string | null, courierStatus?: string) => void;
}

function CourierTimer({ startedAt }: { startedAt?: string | null }) {
  const [seconds, setSeconds] = useState(0);
  useEffect(() => {
    if (!startedAt) return;
    const update = () => {
      setSeconds(Math.floor((Date.now() - new Date(startedAt).getTime()) / 1000));
    };
    update();
    const id = setInterval(update, 1000);
    return () => clearInterval(id);
  }, [startedAt]);
  if (!startedAt) return null;
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return (
    <span className="text-xs text-foreground whitespace-nowrap">
      <Clock className="w-3.5 h-3.5 inline mr-1 text-muted-foreground" />
      Elindult: {m < 1 ? `${s} mp` : `${m} perc`}
    </span>
  );
}

function AddressRow({ order, selected, onToggle }: { order: Order; selected: boolean; onToggle: () => void }) {
  const age = ageMinutes(order.createdAt);
  return (
    <div
      onClick={onToggle}
      className={`flex items-center cursor-pointer select-none transition-colors border-b border-[#d0d4d8] ${selected ? 'bg-white' : 'bg-transparent hover:bg-white/40'}`}
    >
      <div className="w-2 shrink-0 self-stretch">
        <div className={`w-0.5 h-full mx-auto transition-colors ${selected ? 'bg-[hsl(var(--primary))]' : 'bg-[#999]'}`} />
      </div>
      <div className="w-7 shrink-0 flex items-center justify-center">
        {selected ? (
          <svg className="w-4 h-4 text-[hsl(var(--primary))]" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
          </svg>
        ) : (
          <div className="w-4 h-4 border border-[#bbb] rounded-sm" />
        )}
      </div>
      <div className="w-16 shrink-0 leading-tight">
        <div className="text-[11px] text-muted-foreground">#{(order as any).order_number ?? order._id.slice(-2)}</div>
        <div className="text-[11px] text-foreground font-medium">{new Date(order.createdAt).toLocaleTimeString('hu-HU', { hour: '2-digit', minute: '2-digit' })}</div>
      </div>
      <div className={`w-12 shrink-0 text-[11px] font-bold ${age < 15 ? 'text-green-600' : age < 30 ? 'text-yellow-600' : 'text-red-500'}`}>
        {age < 1 ? 'Most' : `${age}p`}
      </div>
      <div className="flex-1 min-w-0 px-1 py-2.5">
        <p className="text-xs text-foreground truncate leading-tight">{order.address}</p>
      </div>
      <div className="w-32 shrink-0 text-[11px] text-foreground text-right px-2 py-2.5 leading-tight">{order.payment_method}</div>
    </div>
  );
}

export default function CourierDispatchPanel({ orders, couriers, onStatusChange }: Props) {
  const [filterNum, setFilterNum] = useState('');
  const [filterStreet, setFilterStreet] = useState('');
  const [selectedOrderIds, setSelectedOrderIds] = useState<Set<string>>(new Set());
  const [expandedCouriers, setExpandedCouriers] = useState<Set<string>>(new Set());

  const unassigned = orders.filter(
    (o) => o.status === 'accepted' && (o.delivery_type as string) !== 'elvitel' && (o.delivery_type as string) !== 'beülős' && !o.courier_id
  );
  const delivering = orders.filter((o) => o.status === 'delivering');

  const filteredUnassigned = unassigned.filter((o) => {
    if (filterNum && !String(o.order_number ?? o._id.slice(-4)).includes(filterNum)) return false;
    if (filterStreet && !(o.address ?? '').toLowerCase().includes(filterStreet.toLowerCase())) return false;
    return true;
  });

  const activeCouriers = couriers.filter((c) => c.role === 'courier' || !(c as any).role);

  const toggleOrder = (id: string) => {
    setSelectedOrderIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const toggleCourier = (id: string) => {
    setExpandedCouriers((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const assignToCourier = (courierId: string) => {
    selectedOrderIds.forEach((orderId) => onStatusChange(orderId, 'delivering', courierId));
    setSelectedOrderIds(new Set());
    setExpandedCouriers((prev) => new Set(prev).add(courierId));
  };

  const startCourier = (courierId: string) => {
    delivering.filter((o) => getCourierId(o.courier_id) === courierId).forEach((o) => {
      onStatusChange(o._id, 'delivering', courierId, 'on_the_way');
    });
  };

  const finishCourier = (courierId: string) => {
    delivering.filter((o) => getCourierId(o.courier_id) === courierId).forEach((o) => {
      onStatusChange(o._id, 'delivered');
    });
  };

  const returnOrder = (orderId: string) => {
    onStatusChange(orderId, 'accepted', null);
  };

  const selectedCount = selectedOrderIds.size;

  return (
    <div className="h-full flex flex-col overflow-hidden bg-[#dce2e6]">
      {/* Fejléc */}
      <div className="shrink-0 flex items-center gap-2 px-3 py-2 bg-white border-b border-[#c5cacf]">
        <div className="flex items-center gap-1 flex-1 min-w-0">
          <input value={filterStreet} onChange={(e) => setFilterStreet(e.target.value)} placeholder="Utca"
            className="text-xs bg-[#f3f4f6] rounded px-2 py-1 outline-none flex-1 min-w-0 border border-transparent focus:border-[hsl(var(--primary))]/30" />
          {filterStreet && <button onClick={() => setFilterStreet('')} className="text-muted-foreground hover:text-foreground px-1 shrink-0"><X className="w-3.5 h-3.5" /></button>}
        </div>
        <div className="flex items-center gap-1 flex-1 min-w-0">
          <input value={filterNum} onChange={(e) => setFilterNum(e.target.value)} placeholder="Számláló"
            className="text-xs bg-[#f3f4f6] rounded px-2 py-1 outline-none flex-1 min-w-0 border border-transparent focus:border-[hsl(var(--primary))]/30" />
          {filterNum && <button onClick={() => setFilterNum('')} className="text-muted-foreground hover:text-foreground px-1 shrink-0"><X className="w-3.5 h-3.5" /></button>}
        </div>
      </div>

      {/* Kétrészes panel */}
      <div className="flex-1 flex overflow-hidden flex-col md:flex-row">
        {/* BAL: Címek */}
        <div className="flex-1 overflow-y-auto min-w-0" style={{ borderRight: '1px solid #c5cacf' }}>
          <div className="px-3 py-2 text-xs font-bold text-foreground uppercase tracking-wide">Címek</div>
          {filteredUnassigned.length === 0 ? (
            <div className="mx-3 bg-white rounded p-3 text-center shadow-sm">
              <p className="text-xs text-muted-foreground">Jelenleg minden cím ki van osztva.</p>
            </div>
          ) : (
            <div className="mx-1">{filteredUnassigned.map((order) => (
              <AddressRow key={order._id} order={order} selected={selectedOrderIds.has(order._id)} onToggle={() => toggleOrder(order._id)} />
            ))}</div>
          )}
        </div>

        {/* JOBB: Futárok */}
        <div className="w-full md:w-[340px] shrink-0 overflow-y-auto">
          <div className="px-3 py-2 text-xs font-bold text-foreground uppercase tracking-wide">Futárok</div>
          {activeCouriers.length === 0 ? (
            <div className="mx-2 bg-white rounded p-3 text-center shadow-sm">
              <p className="text-xs text-muted-foreground">Nincsenek aktív futárok.</p>
            </div>
          ) : (
            activeCouriers.map((courier) => {
              const courierId = courier.id ?? (courier as any)._id;
              const courierOrders = delivering.filter((o) => getCourierId(o.courier_id) === courierId);
              const assignedOrders = courierOrders.filter((o) => o.courier_status !== 'on_the_way');
              const onTheWayOrders = courierOrders.filter((o) => o.courier_status === 'on_the_way');
              
              const assignedCount = assignedOrders.length;
              const onTheWayCount = onTheWayOrders.length;

              const isExpanded = expandedCouriers.has(courierId);
              const hasOrders = courierOrders.length > 0;
              const hasNotStarted = assignedCount > 0;
              const isOnTheWay = onTheWayCount > 0;

              return (
                <div 
                  key={courierId} 
                  className={`mx-2 mb-2 bg-white rounded shadow-sm overflow-hidden border transition-colors ${selectedCount > 0 ? 'border-[hsl(var(--primary))] cursor-pointer hover:bg-primary/5' : 'border-[#e2e6ea]'}`}
                  onClick={() => {
                    if (selectedCount > 0) {
                      assignToCourier(courierId);
                    } else if (hasOrders) {
                      toggleCourier(courierId);
                    }
                  }}
                >
                  {/* Futár fejléc */}
                  <div className="flex items-center px-3 py-3 gap-3">
                    <div className="w-9 h-9 rounded-full bg-[#f3f4f6] shrink-0 flex items-center justify-center">
                      <Bike className="w-4 h-4 text-[#9ca3af]" />
                    </div>
                    
                    <div className="flex-1 min-w-0 flex flex-col justify-center">
                      <span className="font-bold text-[13px] text-foreground truncate">{courier.name}</span>
                      <span className="text-[11px] text-[#9ca3af] mt-0.5">{assignedCount} kiosztva · {onTheWayCount} úton</span>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      {selectedCount > 0 ? (
                         <span className="text-[hsl(var(--primary))] text-[11px] font-bold uppercase tracking-wider pr-1">Átadás</span>
                      ) : hasOrders ? (
                         <button 
                           onClick={(e) => { e.stopPropagation(); toggleCourier(courierId); }} 
                           className="text-[#9ca3af] hover:text-foreground transition-colors p-1"
                         >
                           {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                         </button>
                      ) : null}
                    </div>
                  </div>

                  {hasOrders && isExpanded && (
                    <div className="border-t border-[#e8ecef] bg-[#f4f5f7] flex flex-col" onClick={(e) => e.stopPropagation()}>
                      {/* Címek listája */}
                      <div>
                        {courierOrders.map((o) => (
                          <div key={o._id} className="flex items-center gap-2 px-3 py-2.5 border-b border-[#e2e6ea] last:border-b-0">
                            <div className="w-7 shrink-0 text-[11px] font-bold text-foreground">#{(o as any).order_number ?? o._id.slice(-2)}</div>
                            <div className="w-10 shrink-0 text-[11px] text-muted-foreground">{ageMinutes(o.createdAt) < 1 ? 'Most' : `${ageMinutes(o.createdAt)}p`}</div>
                            <div className="flex-1 min-w-0"><p className="text-xs text-foreground truncate leading-tight">{o.address}</p></div>
                            <div className="w-20 shrink-0 text-[11px] text-foreground text-right leading-tight">{o.payment_method}</div>
                            <button className="shrink-0 w-6 h-6 flex items-center justify-center text-muted-foreground hover:text-red-500 hover:bg-red-50 rounded transition-colors"
                              onClick={() => returnOrder(o._id)} title="Vissza a címekhez"><X className="w-3.5 h-3.5" /></button>
                          </div>
                        ))}
                      </div>
                      
                      {/* Futár akció gombok */}
                      <div className="bg-white border-t border-[#e2e6ea] p-2 flex items-center gap-2 justify-between">
                        {isOnTheWay && courierOrders[0]?.courier_started_at ? (
                          <div className="px-2"><CourierTimer startedAt={courierOrders[0].courier_started_at} /></div>
                        ) : <div />}

                        <div className="flex gap-2">
                          {hasNotStarted && (
                            <button className="flex items-center gap-1.5 px-3 py-1.5 rounded text-[11px] font-bold bg-[hsl(var(--primary))] text-white hover:bg-[hsl(var(--primary)/0.8)] transition-colors shadow-sm"
                              onClick={() => startCourier(courierId)}>
                              Elindult <Navigation className="w-3 h-3" />
                            </button>
                          )}
                          {isOnTheWay && !hasNotStarted && (
                            <button className="flex items-center gap-1.5 px-3 py-1.5 rounded text-[11px] font-bold bg-green-600 text-white hover:bg-green-700 transition-colors shadow-sm"
                              onClick={() => finishCourier(courierId)}>
                              Visszaérkezett <Home className="w-3 h-3" />
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}
