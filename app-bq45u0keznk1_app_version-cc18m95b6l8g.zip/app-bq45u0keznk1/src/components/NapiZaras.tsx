import { useState, useMemo } from 'react';
import type { Order } from '@/types';
import { Download, Printer, Search, Calendar } from 'lucide-react';

interface Props {
  orders: Order[];
  fromDate: string;
  toDate: string;
  onFromChange: (v: string) => void;
  onToChange: (v: string) => void;
  onSearch: () => void;
}

interface ColData {
  total: number;
  count: number;
  serviceFee: number;
  discount: number;
  cancelled: number;
  cardOnline: number;
  cardAtCourier: number;
  cash: number;
  szepCardOnline: number;
  sodexo: number;
  ticket: number;
  transfer: number;
}

function calcColData(orders: Order[]): ColData {
  let total = 0;
  let count = 0;
  let serviceFee = 0;
  let discount = 0;
  let cancelled = 0;
  let cardOnline = 0;
  let cardAtCourier = 0;
  let cash = 0;
  let szepCardOnline = 0;
  let sodexo = 0;
  let ticket = 0;
  let transfer = 0;

  for (const o of orders) {
    if (o.status === 'cancelled') {
      cancelled += o.total;
      continue;
    }
    total += o.total;
    count += 1;
    serviceFee += 0; // nincs külön szervízdíj mező
    discount += 0;   // nincs külön kedvezmény mező

    switch (o.payment_method) {
      case 'Készpénz': cash += o.total; break;
      case 'Bankkártya': cardAtCourier += o.total; break;
      default:
        // Ha nem ismert, készpénzbe soroljuk
        cash += o.total;
    }
  }

  return { total, count, serviceFee, discount, cancelled, cardOnline: 0, cardAtCourier, cash, szepCardOnline: 0, sodexo: 0, ticket: 0, transfer: 0 };
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between py-1.5 text-sm" style={{ borderBottom: '1px solid #e8ecef', color: '#444' }}>
      <span>{label}</span>
      <span className="font-medium" style={{ color: '#222' }}>{value}</span>
    </div>
  );
}

function ColCard({ title, data }: { title: string; data: ColData }) {
  return (
    <div className="bg-white rounded shadow-sm overflow-hidden">
      <div className="px-4 py-3 font-bold text-sm" style={{ background: '#f5f6f8', color: '#333', borderBottom: '1px solid #e2e6ea' }}>
        {title}
      </div>
      <div className="px-4 py-2">
        <Row label="Összesen" value={`${data.total.toLocaleString('hu-HU')} Ft`} />
        <Row label="Összesen (db)" value={`${data.count}`} />
        <Row label="Szervízdíj" value={`${data.serviceFee.toLocaleString('hu-HU')} Ft`} />
        <Row label="Kedvezmény" value={`${data.discount.toLocaleString('hu-HU')} Ft`} />
        <Row label="Sztornózott" value={`${data.cancelled.toLocaleString('hu-HU')} Ft`} />
        <Row label="Bankkártya" value={`${data.cardAtCourier.toLocaleString('hu-HU')} Ft`} />
        <Row label="Készpénz" value={`${data.cash.toLocaleString('hu-HU')} Ft`} />
      </div>
    </div>
  );
}

export default function NapiZaras({ orders, fromDate, toDate, onFromChange, onToChange, onSearch }: Props) {
  const todayStr = new Date().toISOString().slice(0, 10);

  const { overall, dineIn, delivery } = useMemo(() => {
    const all = orders;
    const dine = orders.filter((o) => (o.delivery_type as string) === 'beülős');
    const del = orders.filter((o) => (o.delivery_type as string) !== 'elvitel' && (o.delivery_type as string) !== 'beülős');
    return {
      overall: calcColData(all),
      dineIn: calcColData(dine),
      delivery: calcColData(del),
    };
  }, [orders]);

  return (
    <div className="h-full flex flex-col" style={{ background: '#dde1e6' }}>
      {/* Fejléc */}
      <div className="shrink-0 flex items-center gap-3 px-4 py-3" style={{ background: '#fff', borderBottom: '1px solid #c5cacf' }}>
        <h2 className="font-bold text-lg" style={{ color: '#333' }}>Napi zárás</h2>
        <div className="flex items-center gap-2 ml-auto">
          <div className="flex items-center gap-1 bg-white border border-[#c5cacf] rounded px-2 py-1">
            <Calendar className="w-3.5 h-3.5 text-muted-foreground" />
            <input
              type="date"
              value={fromDate}
              max={toDate || todayStr}
              onChange={(e) => onFromChange(e.target.value)}
              className="text-sm bg-transparent outline-none w-28"
            />
          </div>
          <div className="flex items-center gap-1 bg-white border border-[#c5cacf] rounded px-2 py-1">
            <Calendar className="w-3.5 h-3.5 text-muted-foreground" />
            <input
              type="date"
              value={toDate}
              min={fromDate}
              max={todayStr}
              onChange={(e) => onToChange(e.target.value)}
              className="text-sm bg-transparent outline-none w-28"
            />
          </div>
          <button
            onClick={() => { onFromChange(todayStr); onToChange(todayStr); }}
            className="text-xs font-medium px-3 py-1.5 rounded border border-[#c5cacf]"
            style={{ color: '#555' }}
          >
            Mai nap
          </button>
          <button
            onClick={onSearch}
            className="flex items-center gap-1.5 text-xs font-medium px-4 py-1.5 rounded text-white"
            style={{ background: '#b5255e' }}
          >
            <Search className="w-3.5 h-3.5" /> Keresés
          </button>
        </div>
        <div className="flex items-center gap-2">
          <button className="flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded border border-[#c5cacf]" style={{ color: '#555' }}>
            <Download className="w-3.5 h-3.5" /> Blokk letöltése
          </button>
          <button
            onClick={() => window.print()}
            className="flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded border border-[#c5cacf] print-hidden"
            style={{ color: '#555' }}
          >
            <Printer className="w-3.5 h-3.5" /> Nyomtatás
          </button>
        </div>
      </div>

      {/* 3 oszlop */}
      <div className="flex-1 overflow-y-auto p-4 print-container">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-5xl mx-auto print-grid">
          <ColCard title="Összesített bevétel" data={overall} />
          <ColCard title="Beülős bevétel" data={dineIn} />
          <ColCard title="Kiszállítás bevétel" data={delivery} />
        </div>
      </div>
    </div>
  );
}
