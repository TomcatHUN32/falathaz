// Napi kassza-zárás PDF riport generátor
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { FileDown, Loader2, Receipt } from 'lucide-react';
import { toast } from 'sonner';
import type { Stats, Order } from '@/types';

interface DailyReportPDFProps {
  stats: Stats;
  orders: Order[];
  reportDate: string; // YYYY-MM-DD
}

function getUserLabel(order: Order): string {
  if (order.delivery_type === 'elvitel') return 'Elvitel';
  if (order.delivery_type === 'beülős') return 'Beülős';
  if (order.guest_name) return order.guest_name;
  if (typeof order.user_id === 'object' && order.user_id && 'name' in order.user_id) {
    return (order.user_id as any).name || '—';
  }
  return '—';
}

export default function DailyReportPDF({ stats, orders, reportDate }: DailyReportPDFProps) {
  const [generating, setGenerating] = useState(false);

  const handleGenerate = async () => {
    setGenerating(true);
    try {
      // Dinamikus import — nem töri a build ha nincs telepítve
      const { default: jsPDF } = await import('jspdf');
      const { default: autoTable } = await import('jspdf-autotable');

      const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
      const pageW = doc.internal.pageSize.getWidth();
      const now = new Date();
      const dateLabel = new Date(reportDate).toLocaleDateString('hu-HU', { year: 'numeric', month: 'long', day: 'numeric' });

      // ── Fejléc ─────────────────────────────────────────────────
      doc.setFillColor(20, 20, 20);
      doc.rect(0, 0, pageW, 32, 'F');
      doc.setTextColor(255, 102, 0);
      doc.setFontSize(18);
      doc.setFont('helvetica', 'bold');
      doc.text('Szesztestverek Falathaz', 14, 13);
      doc.setFontSize(10);
      doc.setTextColor(180, 180, 180);
      doc.text('Napi kassza-zaras riport', 14, 21);
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(11);
      doc.text(dateLabel, pageW - 14, 13, { align: 'right' });
      doc.setFontSize(9);
      doc.setTextColor(150, 150, 150);
      doc.text(`Keszult: ${now.toLocaleString('hu-HU')}`, pageW - 14, 21, { align: 'right' });

      let y = 40;

      // ── Összesítő kártyák ───────────────────────────────────────
      doc.setTextColor(255, 102, 0);
      doc.setFontSize(12);
      doc.setFont('helvetica', 'bold');
      doc.text('NAPI OSSZESITO', 14, y);
      y += 7;

      const cardData = [
        ['Osszes rendeles', `${stats.totalOrders} db`],
        ['Teljes bevetel', `${stats.totalRevenue.toLocaleString('hu-HU')} Ft`],
        ['Etelbevel', `${stats.foodRevenue.toLocaleString('hu-HU')} Ft`],
        ['Csomagolasi dij', `${stats.packagingRevenue.toLocaleString('hu-HU')} Ft`],
        ['DRS alap', `${stats.drsRevenue.toLocaleString('hu-HU')} Ft`],
      ];

      autoTable(doc, {
        startY: y,
        head: [['Megnevezes', 'Ertek']],
        body: cardData,
        theme: 'grid',
        headStyles: { fillColor: [255, 102, 0], textColor: [255, 255, 255], fontStyle: 'bold', fontSize: 10 },
        bodyStyles: { fontSize: 10, textColor: [30, 30, 30] },
        alternateRowStyles: { fillColor: [245, 245, 245] },
        columnStyles: { 0: { cellWidth: 100 }, 1: { cellWidth: 60, halign: 'right', fontStyle: 'bold' } },
        margin: { left: 14, right: 14 },
      });

      y = (doc as any).lastAutoTable.finalY + 10;

      // ── Fizetési módok bontás ───────────────────────────────────
      doc.setTextColor(255, 102, 0);
      doc.setFontSize(12);
      doc.setFont('helvetica', 'bold');
      doc.text('FIZETESI MODOK BONTASA', 14, y);
      y += 7;

      const payData = [
        ['Keszpenz (osszes)', `${stats.cashRevenue.toLocaleString('hu-HU')} Ft`],
        ['Bankkarya (osszes)', `${stats.cardRevenue.toLocaleString('hu-HU')} Ft`],
        ['Futar keszpenz', `${(stats.courierCashRevenue ?? 0).toLocaleString('hu-HU')} Ft`],
        ['Futar bankkartya', `${(stats.courierCardRevenue ?? 0).toLocaleString('hu-HU')} Ft`],
      ];

      autoTable(doc, {
        startY: y,
        head: [['Fizetesi mod', 'Bevetel']],
        body: payData,
        theme: 'grid',
        headStyles: { fillColor: [80, 80, 80], textColor: [255, 255, 255], fontStyle: 'bold', fontSize: 10 },
        bodyStyles: { fontSize: 10, textColor: [30, 30, 30] },
        alternateRowStyles: { fillColor: [245, 245, 245] },
        columnStyles: { 0: { cellWidth: 100 }, 1: { cellWidth: 60, halign: 'right', fontStyle: 'bold' } },
        margin: { left: 14, right: 14 },
      });

      y = (doc as any).lastAutoTable.finalY + 10;

      // ── Szállítás/elvitel bontás ────────────────────────────────
      doc.setTextColor(255, 102, 0);
      doc.setFontSize(12);
      doc.setFont('helvetica', 'bold');
      doc.text('RENDELES TIPUSOK', 14, y);
      y += 7;

      const typeData = [
        ['Hazhoz szallitas', `${stats.deliveryCount ?? 0} db`, `${(stats.deliveryRevenue ?? 0).toLocaleString('hu-HU')} Ft`],
        ['Elvitel', `${stats.pickupCount ?? 0} db`, `${(stats.pickupRevenue ?? 0).toLocaleString('hu-HU')} Ft`],
      ];

      autoTable(doc, {
        startY: y,
        head: [['Tipus', 'Darab', 'Bevetel']],
        body: typeData,
        theme: 'grid',
        headStyles: { fillColor: [80, 80, 80], textColor: [255, 255, 255], fontStyle: 'bold', fontSize: 10 },
        bodyStyles: { fontSize: 10, textColor: [30, 30, 30] },
        alternateRowStyles: { fillColor: [245, 245, 245] },
        columnStyles: { 0: { cellWidth: 80 }, 1: { cellWidth: 30, halign: 'center' }, 2: { cellWidth: 50, halign: 'right', fontStyle: 'bold' } },
        margin: { left: 14, right: 14 },
      });

      y = (doc as any).lastAutoTable.finalY + 10;

      // ── Top termékek ───────────────────────────────────────────
      if (stats.topProducts?.length > 0) {
        doc.setTextColor(255, 102, 0);
        doc.setFontSize(12);
        doc.setFont('helvetica', 'bold');
        doc.text('TOP TERMEKEK', 14, y);
        y += 7;

        autoTable(doc, {
          startY: y,
          head: [['Termek neve', 'Darab', 'Bevetel']],
          body: stats.topProducts.slice(0, 10).map((p, i) => [
            `${i + 1}. ${p.name}`,
            `${p.quantity} db`,
            `${p.revenue.toLocaleString('hu-HU')} Ft`,
          ]),
          theme: 'grid',
          headStyles: { fillColor: [80, 80, 80], textColor: [255, 255, 255], fontStyle: 'bold', fontSize: 10 },
          bodyStyles: { fontSize: 9, textColor: [30, 30, 30] },
          alternateRowStyles: { fillColor: [245, 245, 245] },
          columnStyles: { 0: { cellWidth: 100 }, 1: { cellWidth: 25, halign: 'center' }, 2: { cellWidth: 45, halign: 'right' } },
          margin: { left: 14, right: 14 },
        });

        y = (doc as any).lastAutoTable.finalY + 10;
      }

      // ── Új oldal: részletes rendelés lista ─────────────────────
      doc.addPage();
      y = 20;

      doc.setFillColor(20, 20, 20);
      doc.rect(0, 0, pageW, 16, 'F');
      doc.setTextColor(255, 102, 0);
      doc.setFontSize(13);
      doc.setFont('helvetica', 'bold');
      doc.text('RESZLETES RENDELES LISTA', 14, 11);
      doc.setTextColor(150, 150, 150);
      doc.setFontSize(9);
      doc.text(dateLabel, pageW - 14, 11, { align: 'right' });

      y = 24;

      const deliveredOrders = orders.filter(o => o.status === 'delivered' || o.status === 'delivering' || o.status === 'ready' || o.status === 'accepted' || o.status === 'preparing');

      const orderRows = (deliveredOrders.length > 0 ? deliveredOrders : orders).map((o) => {
        const time = new Date(o.createdAt).toLocaleTimeString('hu-HU', { hour: '2-digit', minute: '2-digit' });
        const name = getUserLabel(o);
        const itemsSummary = o.items.map(i => `${i.name} x${i.quantity}`).join(', ');
        const shortItems = itemsSummary.length > 45 ? itemsSummary.slice(0, 42) + '...' : itemsSummary;
        const dt = (o as any).delivery_type === 'elvitel' ? 'Elvitel' : 'Szallitas';
        return [time, name, shortItems, dt, o.payment_method === 'Készpénz' ? 'KP' : 'KARTYA', `${o.total.toLocaleString('hu-HU')} Ft`];
      });

      autoTable(doc, {
        startY: y,
        head: [['Ido', 'Ugyfel', 'Tetelek', 'Tipus', 'Fizetes', 'Osszeg']],
        body: orderRows,
        theme: 'striped',
        headStyles: { fillColor: [255, 102, 0], textColor: [255, 255, 255], fontStyle: 'bold', fontSize: 9 },
        bodyStyles: { fontSize: 8, textColor: [30, 30, 30] },
        alternateRowStyles: { fillColor: [248, 248, 248] },
        columnStyles: {
          0: { cellWidth: 14, halign: 'center' },
          1: { cellWidth: 28 },
          2: { cellWidth: 68 },
          3: { cellWidth: 20, halign: 'center' },
          4: { cellWidth: 22, halign: 'center' },
          5: { cellWidth: 30, halign: 'right', fontStyle: 'bold' },
        },
        margin: { left: 14, right: 14 },
      });

      // ── Lábléc minden oldalon ──────────────────────────────────
      const totalPages = doc.getNumberOfPages();
      for (let i = 1; i <= totalPages; i++) {
        doc.setPage(i);
        const pw = doc.internal.pageSize.getWidth();
        const ph = doc.internal.pageSize.getHeight();
        doc.setDrawColor(255, 102, 0);
        doc.setLineWidth(0.3);
        doc.line(14, ph - 12, pw - 14, ph - 12);
        doc.setFontSize(8);
        doc.setTextColor(150, 150, 150);
        doc.text('Szesztestverek Falathaz — Bizalmas uzleti dokumentum', 14, ph - 7);
        doc.text(`${i} / ${totalPages}`, pw - 14, ph - 7, { align: 'right' });
      }

      // ── Mentés ─────────────────────────────────────────────────
      const filename = `kassza_zaras_${reportDate}.pdf`;
      doc.save(filename);
      toast.success(`PDF elkészült: ${filename}`);
    } catch (err) {
      console.error('PDF generálási hiba:', err);
      toast.error('PDF generálás sikertelen');
    } finally {
      setGenerating(false);
    }
  };

  // Összefoglaló számok a preview kártyán
  const totalOrders = stats?.totalOrders ?? 0;
  const totalRevenue = stats?.totalRevenue ?? 0;
  const cashRevenue = stats?.cashRevenue ?? 0;
  const cardRevenue = stats?.cardRevenue ?? 0;

  return (
    <Card className="bg-[#111111] border border-[#ff6600]/20">
      <CardHeader className="pb-3">
        <CardTitle className="text-white text-base flex items-center gap-2">
          <Receipt className="w-4 h-4 text-[#ff6600]" /> Napi kassza-zárás
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Gyors előnézet */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <div className="bg-[#1a1a1a] rounded-lg p-3 border border-[#ff6600]/10 text-center">
            <p className="text-muted-foreground text-xs">Rendelések</p>
            <p className="text-2xl font-bold text-white mt-1">{totalOrders} db</p>
          </div>
          <div className="bg-[#1a1a1a] rounded-lg p-3 border border-[#ff6600]/10 text-center">
            <p className="text-muted-foreground text-xs">Teljes bevétel</p>
            <p className="text-xl font-bold text-[#ff6600] mt-1">{totalRevenue.toLocaleString('hu-HU')} Ft</p>
          </div>
          <div className="bg-[#1a1a1a] rounded-lg p-3 border border-green-500/20 text-center">
            <p className="text-muted-foreground text-xs">Készpénz</p>
            <p className="text-xl font-bold text-green-400 mt-1">{cashRevenue.toLocaleString('hu-HU')} Ft</p>
          </div>
          <div className="bg-[#1a1a1a] rounded-lg p-3 border border-blue-500/20 text-center">
            <p className="text-muted-foreground text-xs">Bankkártya</p>
            <p className="text-xl font-bold text-blue-400 mt-1">{cardRevenue.toLocaleString('hu-HU')} Ft</p>
          </div>
        </div>

        {/* Futár bontás */}
        <div className="bg-[#1a1a1a] rounded-lg p-3 border border-[#ff6600]/10">
          <p className="text-muted-foreground text-xs mb-2">Futár bevétel bontás</p>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <p className="text-xs text-muted-foreground">Futár készpénz (beszedhető)</p>
              <p className="text-lg font-bold text-green-400">{(stats?.courierCashRevenue ?? 0).toLocaleString('hu-HU')} Ft</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Futár bankkártya (terminál)</p>
              <p className="text-lg font-bold text-blue-400">{(stats?.courierCardRevenue ?? 0).toLocaleString('hu-HU')} Ft</p>
            </div>
          </div>
        </div>

        {/* PDF export gomb */}
        <Button
          className="w-full btn-primary-gradient text-white font-semibold h-11"
          onClick={handleGenerate}
          disabled={generating || totalOrders === 0}
        >
          {generating
            ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> PDF generálása...</>
            : <><FileDown className="w-4 h-4 mr-2" /> Kassza-zárás PDF letöltése</>
          }
        </Button>
        {totalOrders === 0 && (
          <p className="text-xs text-muted-foreground text-center">Nincs rendelés a kiválasztott időszakban</p>
        )}
      </CardContent>
    </Card>
  );
}
