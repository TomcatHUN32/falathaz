import { useState } from 'react';
import { Badge } from '@/components/ui/badge';

import type { Order, User } from '@/types';
import {
  Phone, MapPin, Clock, Banknote, CreditCard, StickyNote,
  ChevronDown, ChevronUp, Printer, CheckCircle,
  ShoppingBag, Utensils, Package, XCircle, ArrowRight,
  Globe, MonitorSmartphone,
} from 'lucide-react';

// ─── Segédfüggvény: sztornó megerősítés ─────────────────────────────────────
function confirmCancel(orderId: string, onStatusChange: (id: string, status: string) => void) {
  if (window.confirm('Biztosan sztornózod ezt a rendelést? Ez a művelet nem vonható vissza!')) {
    onStatusChange(orderId, 'cancelled');
  }
}

// ─── Típusok / konstansok ────────────────────────────────────────────────────

const STATUS_LABELS: Record<string, string> = {
  pending:    'Várakozik',
  accepted:   'Elfogadva',
  delivering: 'Kiszállítás alatt',
  delivered:  'Kiszállítva',
  cancelled:  'Sztornózva',
};

const LEFT_BORDER: Record<string, string> = {
  pending:    'border-l-yellow-500',
  accepted:   'border-l-blue-500',
  delivering: 'border-l-green-500',
  delivered:  'border-l-slate-400',
  cancelled:  'border-l-red-700',
};

function getUserName(userId: Order['user_id'] | null | undefined): string {
  if (!userId || typeof userId !== 'object') return 'Vendég';
  return (userId as User).name || 'Vendég';
}
function getUserPhone(userId: Order['user_id'] | null | undefined): string {
  if (!userId || typeof userId !== 'object') return '';
  return (userId as User).phone || '';
}
function ageLabel(createdAt: string, status: string): { text: string; cls: string } | null {
  if (['delivered', 'cancelled'].includes(status)) return null;
  const m = Math.floor((Date.now() - new Date(createdAt).getTime()) / 60_000);
  if (m < 1)  return { text: 'Most érkezett', cls: 'text-green-600' };
  if (m < 30) return { text: `${m} perce`, cls: 'text-green-600' };
  if (m < 60) return { text: `${m} perce`, cls: 'text-yellow-600' };
  return { text: `${m} perce`, cls: 'text-red-500' };
}

// Forrás ikon
function SourceIcon({ source }: { source?: string }) {
  if (!source) return <Globe className="w-3.5 h-3.5 text-muted-foreground" />;
  const s = source.toLowerCase();
  if (s.includes('wolt')) return <span className="text-[10px] font-bold text-blue-600 bg-blue-100 rounded px-1">W</span>;
  if (s.includes('foodpanda') || s.includes('panda')) return <span className="text-[10px] font-bold text-pink-600 bg-pink-100 rounded px-1">🐼</span>;
  if (s.includes('telefonos') || s.includes('telefon')) return <MonitorSmartphone className="w-3.5 h-3.5 text-primary" />;
  if (s.includes('falatozz') || s.includes('böngész') || s.includes('web')) return <Globe className="w-3.5 h-3.5 text-foreground" />;
  return <Globe className="w-3.5 h-3.5 text-muted-foreground" />;
}

// ─── Props ───────────────────────────────────────────────────────────────────

interface Props {
  order: Order;
  couriers: User[];
  now: number;
  onOpen: (order: Order) => void;
  onStatusChange: (orderId: string, status: string, courierId?: string) => void;
  onPrint: (order: Order) => void;
}

// ─── Fő komponens ────────────────────────────────────────────────────────────

export default function OrderRow({ order, couriers, onOpen, onStatusChange, onPrint }: Props) {
  const [expanded, setExpanded] = useState(false);

  const isPickup = order.delivery_type === 'elvitel';
  const isDineIn = order.delivery_type === 'beülős';

  const name  = isPickup ? 'Elvitel' : (isDineIn ? 'Beülős' : (order.guest_name || getUserName(order.user_id)));
  const phone = (isPickup || isDineIn) ? '' : ((order as any).phone || getUserPhone(order.user_id));
  const age   = ageLabel(order.createdAt, order.status);
  const borderLeft  = LEFT_BORDER[order.status] ?? 'border-l-slate-400';
  const isDone = ['delivered', 'cancelled'].includes(order.status);
  const orderNum = (order as any).order_number ?? order._id.slice(-4).toUpperCase();
  const courierName = (() => {
    if (!order.courier_id) return null;
    const cid = typeof order.courier_id === 'object' ? (order.courier_id as any)._id || (order.courier_id as User).id : order.courier_id;
    const found = couriers.find((c) => c.id === cid || (c as any)._id === cid);
    if (found) return found.name;
    if (typeof order.courier_id === 'object') return (order.courier_id as User).name || null;
    return null;
  })();

  const handleRowClick = () => {
    if (order.status === 'pending') {
      onStatusChange(order._id, 'accepted');
      setExpanded(true);
    } else {
      setExpanded((v) => !v);
    }
  };

  return (
    <div className={`border-b border-border/40 ${borderLeft} border-l-[4px] ${order.status === 'cancelled' ? 'bg-red-50/50' : (isDone ? 'opacity-60 bg-card' : 'bg-card')} hover:bg-slate-100 transition-all duration-200`}>
      {/* ── Fő sor – kártya-szerű ── */}
      <div
        className="flex items-start gap-0 cursor-pointer select-none py-3.5"
        onClick={handleRowClick}
      >
        {/* Sorszám */}
        <div className="w-16 shrink-0 flex items-start justify-center px-4">
          <span className="text-foreground font-bold text-sm leading-tight">{orderNum}</span>
        </div>

        {/* Név */}
        <div className="w-40 shrink-0 min-w-0 px-3 border-l border-border/40">
          <p className="text-foreground font-medium text-sm truncate">{name}</p>
        </div>

        {/* Cím + telefon + forrás + futár */}
        <div className="flex-1 min-w-0 px-3 border-l border-border/40">
          <div className="flex items-start gap-2 min-w-0">
            <div className="flex-1 min-w-0">
              {(!isPickup && !isDineIn && order.address) && (
                <p className="text-muted-foreground text-xs truncate">{order.address}</p>
              )}
              {phone && (
                <a
                  href={`tel:${phone}`}
                  onClick={(e) => e.stopPropagation()}
                  className="text-foreground text-xs hover:text-primary transition-colors font-medium"
                >
                  {phone}
                </a>
              )}
              {/* Forrás + futár sor */}
              <div className="flex items-center gap-1.5 mt-1 flex-wrap">
                <SourceIcon source={(order as any).source} />
                {courierName && (
                  <span className="text-xs text-muted-foreground">
                    Futár: <span className="font-semibold text-foreground">- {courierName}</span>
                  </span>
                )}
                {age && (
                  <span className={`text-xs font-medium ${age.cls}`}>· {age.text}</span>
                )}
              </div>
              <div className="mt-1.5 text-xs text-muted-foreground truncate border-t border-border/40 pt-1">
                <span className="font-medium text-foreground">Tételek: </span>
                {order.items.map((i) => `${i.quantity}x ${i.name}`).join(', ')}
              </div>
            </div>
          </div>
        </div>

        {/* Idő */}
        <div className="w-14 shrink-0 text-right">
          <span className="text-muted-foreground text-xs">
            {new Date(order.createdAt).toLocaleTimeString('hu-HU', { hour: '2-digit', minute: '2-digit' })}
          </span>
        </div>

        {/* Fizetési mód */}
        <div className="w-40 shrink-0">
          <span className="text-foreground text-xs truncate">{order.payment_method || '—'}</span>
        </div>

        {/* Összeg + nyíl */}
        <div className="w-28 shrink-0 flex items-center justify-end gap-1">
          <span className="text-foreground font-bold text-sm">| {order.total.toLocaleString('hu-HU')} Ft</span>
          <ArrowRight className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
        </div>
      </div>

      {/* ── Kibontott tartalom ── */}
      {expanded && (
        <div className="border-t border-border/40 bg-muted/20 rounded-b-xl">
          {/* Tételek */}
          <div className="px-5 py-4">
            <h4 className="text-sm font-semibold text-foreground mb-3 flex items-center gap-1.5">
              <Utensils className="w-4 h-4 text-primary" /> Rendelés tartalma
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
              {order.items.map((item, i) => (
                <div key={i} className="flex flex-col bg-card border border-border/60 rounded-xl p-3 shadow-sm relative overflow-hidden group hover:border-primary/30 transition-colors">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-start gap-3 min-w-0 flex-1">
                      <span className="bg-primary/10 text-primary font-black px-2 py-1 rounded-md text-sm shrink-0 min-w-[2.5rem] text-center shadow-sm">
                        {item.quantity}×
                      </span>
                      <div className="flex flex-col min-w-0 pt-0.5">
                        <span className="text-foreground font-bold text-sm leading-tight">
                          {item.name}
                        </span>
                        {(item.extras || []).length > 0 && (
                          <span className="text-muted-foreground text-xs mt-1.5 leading-relaxed bg-muted/50 px-2 py-1 rounded border border-border/40">
                            <span className="font-semibold">Extrák:</span> {(item.extras || []).map((e: any) => e.option_name).join(', ')}
                          </span>
                        )}
                      </div>
                    </div>
                    <span className="text-foreground font-bold text-sm shrink-0 whitespace-nowrap pt-0.5">
                      {(item.price * item.quantity).toLocaleString()} Ft
                    </span>
                  </div>
                  {item.note && (
                    <div className="mt-2.5 bg-red-500/10 text-red-600 dark:bg-red-950/30 dark:text-red-400 px-3 py-2 rounded-lg text-xs font-semibold flex items-start gap-2 border border-red-500/30 dark:border-red-900/50 shadow-sm">
                      <StickyNote className="w-3.5 h-3.5 shrink-0 mt-0.5" />
                      <span>{item.note}</span>
                    </div>
                  )}
                </div>
              ))}
            </div>

            {/* Fő Megjegyzés */}
            {order.notes && (
              <div className="flex items-start gap-2 bg-red-500/10 border border-red-500/30 dark:bg-red-950/30 dark:border-red-900/50 rounded-xl px-4 py-3 mb-4 shadow-sm">
                <StickyNote className="w-4 h-4 text-red-600 dark:text-red-400 shrink-0 mt-0.5" />
                <div className="flex flex-col">
                  <span className="text-red-700 dark:text-red-300 font-bold text-xs mb-0.5 uppercase tracking-wider">A rendeléshez tartozó megjegyzés:</span>
                  <p className="text-red-800 dark:text-red-200 text-sm font-semibold leading-snug">{order.notes}</p>
                </div>
              </div>
            )}

            {/* Akció gombok */}
            <div className="flex items-center gap-2 flex-wrap">
              <button
                onClick={(e) => { e.stopPropagation(); onOpen(order); }}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-border/60 bg-card text-foreground text-xs font-medium hover:border-primary/40 hover:shadow-sm transition-all"
              >
                <Package className="w-3 h-3" /> Részletek
              </button>

              {order.status === 'pending' && (
                <>
                  <button onClick={(e) => { e.stopPropagation(); onStatusChange(order._id, 'accepted'); }}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-green-500/30 bg-green-500/10 text-green-600 dark:bg-green-950/30 dark:border-green-900/50 dark:text-green-400 text-xs font-semibold hover:bg-green-500/20 hover:shadow-sm transition-all shadow-[0_0_8px_rgba(225,29,72,0.15)] dark:shadow-none">
                    <CheckCircle className="w-3 h-3" /> Elfogadás
                  </button>
                  <button onClick={(e) => { e.stopPropagation(); onPrint(order); }}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-border bg-card text-foreground text-xs font-medium hover:border-primary/40 hover:shadow-sm transition-all hover:shadow-[0_2px_8px_rgba(225,29,72,0.05)] dark:hover:shadow-none">
                    <Printer className="w-3 h-3" /> Nyomtatás
                  </button>
                  <button onClick={(e) => { e.stopPropagation(); confirmCancel(order._id, onStatusChange); }}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-red-500/30 bg-red-500/10 text-red-600 dark:bg-red-950/30 dark:border-red-900/50 dark:text-red-400 text-xs font-semibold hover:bg-red-500/20 hover:shadow-sm transition-all">
                    <XCircle className="w-3 h-3" /> Sztornó
                  </button>
                </>
              )}

              {order.status === 'accepted' && (
                <>
                  <button onClick={(e) => { e.stopPropagation(); onPrint(order); }}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-border bg-card text-foreground text-xs font-medium hover:border-primary/40 hover:shadow-sm transition-all hover:shadow-[0_2px_8px_rgba(225,29,72,0.05)] dark:hover:shadow-none">
                    <Printer className="w-3 h-3" /> Nyomtatás
                  </button>
                  {(isPickup || isDineIn) && (
                    <button onClick={(e) => { e.stopPropagation(); onStatusChange(order._id, 'delivered'); }}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-green-500/30 bg-green-500/10 text-green-600 dark:bg-green-950/30 dark:border-green-900/50 dark:text-green-400 text-xs font-semibold hover:bg-green-500/20 hover:shadow-sm transition-all shadow-[0_0_8px_rgba(225,29,72,0.15)] dark:shadow-none">
                      <CheckCircle className="w-3 h-3" /> Kiadva
                    </button>
                  )}
                  <button onClick={(e) => { e.stopPropagation(); confirmCancel(order._id, onStatusChange); }}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-red-500/30 bg-red-500/10 text-red-600 dark:bg-red-950/30 dark:border-red-900/50 dark:text-red-400 text-xs font-semibold hover:bg-red-500/20 hover:shadow-sm transition-all">
                    <XCircle className="w-3 h-3" /> Sztornó
                  </button>
                </>
              )}

              {order.status === 'preparing' && (
                <>
                  <button onClick={(e) => { e.stopPropagation(); onPrint(order); }}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-border bg-card text-foreground text-xs font-medium hover:border-primary/40 hover:shadow-sm transition-all hover:shadow-[0_2px_8px_rgba(225,29,72,0.05)] dark:hover:shadow-none">
                    <Printer className="w-3 h-3" /> Nyomtatás
                  </button>
                  <button onClick={(e) => { e.stopPropagation(); onStatusChange(order._id, 'ready'); }}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-green-500/30 bg-green-500/10 text-green-600 dark:bg-green-950/30 dark:border-green-900/50 dark:text-green-400 text-xs font-semibold hover:bg-green-500/20 hover:shadow-sm transition-all shadow-[0_0_8px_rgba(225,29,72,0.15)] dark:shadow-none">
                    <CheckCircle className="w-3 h-3" /> Kész
                  </button>
                  <button onClick={(e) => { e.stopPropagation(); confirmCancel(order._id, onStatusChange); }}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-red-500/30 bg-red-500/10 text-red-600 dark:bg-red-950/30 dark:border-red-900/50 dark:text-red-400 text-xs font-semibold hover:bg-red-500/20 hover:shadow-sm transition-all">
                    <XCircle className="w-3 h-3" /> Sztornó
                  </button>
                </>
              )}

              {order.status === 'ready' && (
                <>
                  <button onClick={(e) => { e.stopPropagation(); onPrint(order); }}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-border/60 bg-card text-foreground text-xs font-medium hover:border-primary/40 hover:shadow-sm transition-all">
                    <Printer className="w-3 h-3" /> Nyomtatás
                  </button>
                  {(isPickup || isDineIn) && (
                    <button onClick={(e) => { e.stopPropagation(); onStatusChange(order._id, 'delivered'); }}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-green-500/30 bg-green-500/10 text-green-600 dark:bg-green-950/30 dark:border-green-900/50 dark:text-green-400 text-xs font-semibold hover:bg-green-500/20 hover:shadow-sm transition-all shadow-[0_0_8px_rgba(225,29,72,0.15)] dark:shadow-none">
                      <CheckCircle className="w-3 h-3" /> Kiadva
                    </button>
                  )}
                  <button onClick={(e) => { e.stopPropagation(); confirmCancel(order._id, onStatusChange); }}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-red-500/30 bg-red-500/10 text-red-600 dark:bg-red-950/30 dark:border-red-900/50 dark:text-red-400 text-xs font-semibold hover:bg-red-500/20 hover:shadow-sm transition-all">
                    <XCircle className="w-3 h-3" /> Sztornó
                  </button>
                </>
              )}

              {order.status === 'delivering' && (
                <>
                  <button onClick={(e) => { e.stopPropagation(); onStatusChange(order._id, 'delivered'); }}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-green-500/30 bg-green-500/10 text-green-600 dark:bg-green-950/30 dark:border-green-900/50 dark:text-green-400 text-xs font-semibold hover:bg-green-500/20 hover:shadow-sm transition-all shadow-[0_0_8px_rgba(225,29,72,0.15)] dark:shadow-none">
                    <CheckCircle className="w-3 h-3" /> Kiszállítva
                  </button>
                  <button onClick={(e) => { e.stopPropagation(); confirmCancel(order._id, onStatusChange); }}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-red-500/30 bg-red-500/10 text-red-600 dark:bg-red-950/30 dark:border-red-900/50 dark:text-red-400 text-xs font-semibold hover:bg-red-500/20 hover:shadow-sm transition-all">
                    <XCircle className="w-3 h-3" /> Sztornó
                  </button>
                </>
              )}

              {order.status === 'delivered' && (
                <button onClick={(e) => { e.stopPropagation(); confirmCancel(order._id, onStatusChange); }}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-red-500/30 bg-red-500/10 text-red-600 dark:bg-red-950/30 dark:border-red-900/50 dark:text-red-400 text-xs font-semibold hover:bg-red-500/20 hover:shadow-sm transition-all">
                  <XCircle className="w-3 h-3" /> Sztornó
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
