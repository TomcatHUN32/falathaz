import { useState, useMemo } from 'react';
import type { Order, User } from '@/types';
import { Download, Printer, Search, Calendar } from 'lucide-react';

interface Props {
  orders: Order[];
  couriers: User[];
  fromDate: string;
  toDate: string;
  onFromChange: (v: string) => void;
  onToChange: (v: string) => void;
  onSearch: () => void;
  onReassign?: (orderId: string) => void;
}

function getCourierName(courierId: Order['courier_id'], couriers: User[]): string {
  if (!courierId) return 'Nincs futár';
  const cid = typeof courierId === 'object' ? (courierId as any)._id ?? (courierId as User).id : courierId;
  const found = couriers.find((c) => c.id === cid || (c as any)._id === cid);
  if (found) return found.name;
  if (typeof courierId === 'object') return (courierId as User).name ?? 'Ismeretlen';
  return 'Ismeretlen';
}

function getCourierId(courierId: Order['courier_id']): string | null {
  if (!courierId) return null;
  if (typeof courierId === 'object') return (courierId as any)._id ?? (courierId as User).id ?? null;
  return courierId as string;
}

interface CourierStats {
  cash: number;
  card: number;
  total: number;
  addressCount: number;
  cancelled: number;
  serviceFee: number;
  tip: number;
}

function calcCourierStats(orders: Order[]): CourierStats {
  let cash = 0;
  let card = 0;
  let total = 0;
  let addressCount = 0;
  let cancelled = 0;
  for (const o of orders) {
    if (o.status === 'cancelled') {
      cancelled += o.total;
      continue;
    }
    total += o.total;
    addressCount += 1;
    if (o.payment_method === 'Készpénz') cash += o.total;
    else card += o.total;
  }
  return { cash, card, total, addressCount, cancelled, serviceFee: 0, tip: 0 };
}

export default function FutarZaras({ orders, couriers, fromDate, toDate, onFromChange, onToChange, onSearch, onReassign }: Props) {
  const todayStr = new Date().toISOString().slice(0, 10);
  const [selectedCourierId, setSelectedCourierId] = useState<string | null>(null);

  const courierList = useMemo(() => {
    return couriers.filter((c) => c.role === 'courier' || !(c as any).role);
  }, [couriers]);

  // Szűrt rendelések dátum alapján
  const filteredOrders = useMemo(() => {
    const from = fromDate ? new Date(fromDate + 'T00:00:00').getTime() : 0;
    const to = toDate ? new Date(toDate + 'T23:59:59').getTime() : Infinity;
    return orders.filter((o) => {
      const t = new Date(o.createdAt).getTime();
      return t >= from && t <= to;
    });
  }, [orders, fromDate, toDate]);

  // Kiválasztott futár rendelései
  const courierOrders = useMemo(() => {
    if (!selectedCourierId) return [];
    return filteredOrders.filter((o) => {
      const cid = getCourierId(o.courier_id);
      return cid === selectedCourierId;
    });
  }, [filteredOrders, selectedCourierId]);

  const stats = useMemo(() => calcCourierStats(courierOrders), [courierOrders]);

  const selectedCourier = courierList.find((c) => c.id === selectedCourierId || (c as any)._id === selectedCourierId);

  return (
    <div className="h-full flex flex-col" style={{ background: '#dde1e6' }}>
      {/* Fejléc */}
      <div className="shrink-0 flex items-center gap-3 px-4 py-3" style={{ background: '#fff', borderBottom: '1px solid #c5cacf' }}>
        <h2 className="font-bold text-lg" style={{ color: '#333' }}>Futár zárás</h2>
        <div className="flex items-center gap-2 ml-auto">
          <div className="flex items-center gap-1 bg-white border border-[#c5cacf] rounded px-2 py-1">
            <Calendar className="w-3.5 h-3.5 text-muted-foreground" />
            <input
              type="date"
              value={fromDate}
              max={toDate || todayStr}
              onChange={(e) => onFromChange(e.target.value)}
              className="text-sm bg-transparent outline-none w-28"
            />
          </div>
          <div className="flex items-center gap-1 bg-white border border-[#c5cacf] rounded px-2 py-1">
            <Calendar className="w-3.5 h-3.5 text-muted-foreground" />
            <input
              type="date"
              value={toDate}
              min={fromDate}
              max={todayStr}
              onChange={(e) => onToChange(e.target.value)}
              className="text-sm bg-transparent outline-none w-28"
            />
          </div>
          <button
            onClick={() => { onFromChange(todayStr); onToChange(todayStr); }}
            className="text-xs font-medium px-3 py-1.5 rounded border border-[#c5cacf]"
            style={{ color: '#555' }}
          >
            Mai nap
          </button>
          <button
            onClick={onSearch}
            className="flex items-center gap-1.5 text-xs font-medium px-4 py-1.5 rounded text-white"
            style={{ background: '#b5255e' }}
          >
            <Search className="w-3.5 h-3.5" /> Keresés
          </button>
          <button className="flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded border border-[#c5cacf]" style={{ color: '#555' }}>
            <Printer className="w-3.5 h-3.5" /> Minden futár nyomtatás
          </button>
        </div>
      </div>

      {/* Háromrészes panel */}
      <div className="flex-1 flex overflow-hidden">
        {/* BAL: Futár lista */}
        <div className="w-48 shrink-0 overflow-y-auto" style={{ background: '#fff', borderRight: '1px solid #c5cacf' }}>
          <div className="px-3 py-2 text-xs font-bold uppercase tracking-wide" style={{ background: '#f5f6f8', color: '#555', borderBottom: '1px solid #e2e6ea' }}>
            Futárok
          </div>
          {courierList.length === 0 ? (
            <div className="p-4 text-sm text-center" style={{ color: '#888' }}>Nincs futár</div>
          ) : (
            courierList.map((c) => {
              const cid = c.id ?? (c as any)._id;
              const isActive = selectedCourierId === cid;
              return (
                <button
                  key={cid}
                  onClick={() => setSelectedCourierId(cid)}
                  className="w-full text-left px-3 py-2.5 text-sm transition-colors"
                  style={{
                    background: isActive ? '#f0f1f3' : '#fff',
                    color: isActive ? '#b5255e' : '#333',
                    borderLeft: isActive ? '3px solid #b5255e' : '3px solid transparent',
                    borderBottom: '1px solid #e8ecef',
                  }}
                >
                  {c.name}
                </button>
              );
            })
          )}
        </div>

        {/* KÖZÉP: Kiválasztott futár statisztikái */}
        <div className="w-80 shrink-0 overflow-y-auto p-4" style={{ background: '#f5f6f8', borderRight: '1px solid #c5cacf' }}>
          {selectedCourier ? (
            <div className="space-y-4">
              <h3 className="font-bold text-base" style={{ color: '#333' }}>- {selectedCourier.name}</h3>
              <div className="flex gap-2">
                <button className="flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded border border-[#c5cacf]" style={{ color: '#555' }}>
                  <Download className="w-3.5 h-3.5" /> Blokk letöltése
                </button>
                <button
                  onClick={() => window.print()}
                  className="flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded border border-[#c5cacf] print-hidden"
                  style={{ color: '#555' }}
                >
                  <Printer className="w-3.5 h-3.5" /> Nyomtatás
                </button>
              </div>

              {/* Statisztika grid */}
              <div className="bg-white rounded p-4 space-y-3 shadow-sm print-container">
                <div className="grid grid-cols-2 gap-4 print-grid">
                  <div>
                    <div className="text-xs text-muted-foreground">Készpénzes</div>
                    <div className="text-sm font-bold" style={{ color: '#222' }}>{stats.cash.toLocaleString('hu-HU')} Ft</div>
                  </div>
                  <div>
                    <div className="text-xs text-muted-foreground">Bankkártyás</div>
                    <div className="text-sm font-bold" style={{ color: '#222' }}>{stats.card.toLocaleString('hu-HU')} Ft</div>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <div className="text-xs text-muted-foreground">Összesen</div>
                    <div className="text-sm font-bold" style={{ color: '#222' }}>{stats.total.toLocaleString('hu-HU')} Ft</div>
                  </div>
                  <div>
                    <div className="text-xs text-muted-foreground">Címek</div>
                    <div className="text-sm font-bold" style={{ color: '#222' }}>{stats.addressCount} db</div>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <div className="text-xs text-muted-foreground">Sztornózott</div>
                    <div className="text-sm font-bold" style={{ color: '#222' }}>{stats.cancelled.toLocaleString('hu-HU')} Ft</div>
                  </div>
                  <div>
                    <div className="text-xs text-muted-foreground">Szervízdíj</div>
                    <div className="text-sm font-bold" style={{ color: '#222' }}>{stats.serviceFee.toLocaleString('hu-HU')} Ft</div>
                  </div>
                </div>
                <div>
                  <div className="text-xs text-muted-foreground">Futár borravaló</div>
                  <div className="text-sm font-bold" style={{ color: '#222' }}>{stats.tip.toLocaleString('hu-HU')} Ft</div>
                </div>
              </div>

              {/* Alsó összesítő */}
              <div className="bg-white rounded p-3 space-y-1.5 shadow-sm text-sm">
                <div className="flex justify-between" style={{ color: '#555' }}><span>Sztornózott</span><span>{stats.cancelled.toLocaleString('hu-HU')} Ft</span></div>
                <div className="flex justify-between" style={{ color: '#555' }}><span>Bankkártya</span><span>{stats.card.toLocaleString('hu-HU')} Ft</span></div>
                <div className="flex justify-between" style={{ color: '#555' }}><span>Készpénz</span><span>{stats.cash.toLocaleString('hu-HU')} Ft</span></div>
                <div className="flex justify-between" style={{ color: '#555' }}><span>Kedvezmény</span><span>0 Ft</span></div>
                <div className="flex justify-between" style={{ color: '#555' }}><span>Egyéb</span><span>0 Ft</span></div>
              </div>
            </div>
          ) : (
            <div className="flex items-center justify-center h-full text-sm" style={{ color: '#888' }}>
              Válassz egy futárt a listából
            </div>
          )}
        </div>

        {/* JOBB: Kiszállított címek */}
        <div className="flex-1 overflow-y-auto" style={{ background: '#fff' }}>
          <div className="px-4 py-2 text-xs font-bold uppercase tracking-wide" style={{ background: '#f5f6f8', color: '#555', borderBottom: '1px solid #e2e6ea' }}>
            Kiszállított címek
          </div>
          {selectedCourier ? (
            courierOrders.length === 0 ? (
              <div className="flex items-center justify-center py-12 text-sm" style={{ color: '#888' }}>Nincs kiszállított cím.</div>
            ) : (
              <div className="divide-y divide-[#e8ecef]">
                {courierOrders.map((o) => (
                  <div key={o._id} className="flex items-center gap-3 px-4 py-3">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate" style={{ color: '#222' }}>
                        {typeof o.user_id === 'object' ? (o.user_id as any).name || 'Vendég' : 'Vendég'}
                      </p>
                      <p className="text-xs truncate" style={{ color: '#888' }}>{o.address}</p>
                    </div>
                    <div className="text-right shrink-0">
                      <p className="text-sm font-medium" style={{ color: '#222' }}>{o.total.toLocaleString('hu-HU')} Ft</p>
                      {o.delivery_fee > 0 && (
                        <p className="text-xs" style={{ color: '#888' }}>Száll.: {o.delivery_fee.toLocaleString('hu-HU')} Ft</p>
                      )}
                    </div>
                    <div className="w-32 shrink-0 text-xs" style={{ color: '#666' }}>
                      {o.payment_method}
                    </div>
                    {onReassign && (
                      <button
                        onClick={() => onReassign(o._id)}
                        className="text-xs shrink-0 hover:underline"
                        style={{ color: '#b5255e' }}
                      >
                        Hozzárendelés valaki máshoz
                      </button>
                    )}
                  </div>
                ))}
              </div>
            )
          ) : (
            <div className="flex items-center justify-center py-12 text-sm" style={{ color: '#888' }}>Válassz egy futárt a listából</div>
          )}
        </div>
      </div>
    </div>
  );
}
