import { useState, useEffect, useRef } from 'react';
import { useSocket } from '@/contexts/SocketContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Send, MessageCircle, X } from 'lucide-react';

export interface ChatMessage {
  from: 'admin' | 'courier';
  senderName: string;
  message: string;
  timestamp: string;
}

// ── Messenger-stílusú hangjelzés (Web Audio API) ──────────────────────────────
function playMessengerSound() {
  try {
    const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    const now = ctx.currentTime;

    // Két rövid, emelkedő hang — klasszikus messenger ding
    const tones = [
      { freq: 880, start: 0,    dur: 0.12 },
      { freq: 1100, start: 0.13, dur: 0.14 },
    ];
    tones.forEach(({ freq, start, dur }) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + start);
      gain.gain.setValueAtTime(0, now + start);
      gain.gain.linearRampToValueAtTime(0.35, now + start + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, now + start + dur);
      osc.start(now + start);
      osc.stop(now + start + dur + 0.05);
    });
  } catch {
    // Böngésző nem támogatja — csendben folytatjuk
  }
}

// ─────────────────────────────────────────────────────────────
// Admin oldali panel — egy futárhoz
// ─────────────────────────────────────────────────────────────
interface AdminChatPanelProps {
  courierId: string;
  courierName: string;
  adminName?: string;
  // Ha meg van adva, az új üzenet olvasottnak számít (a panel éppen nyitva van erre a futárra)
  isActive?: boolean;
  onNewMessage?: (courierId: string) => void;
}

export function AdminChatPanel({
  courierId,
  courierName,
  adminName = 'Admin',
  isActive = true,
  onNewMessage,
}: AdminChatPanelProps) {
  const { socket } = useSocket();
  const storageKey = `chat_admin_${courierId}`;
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    try { return JSON.parse(localStorage.getItem(storageKey) || '[]'); } catch { return []; }
  });
  const [input, setInput] = useState('');
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    try { localStorage.setItem(storageKey, JSON.stringify(messages.slice(-100))); } catch {}
  }, [messages, storageKey]);

  useEffect(() => {
    if (!socket) return;
    const handleFromCourier = (data: any) => {
      if (data.courierId !== courierId) return;
      setMessages((prev) => [...prev, {
        from: 'courier',
        senderName: data.senderName ?? data.courierName ?? 'Futár',
        message: data.message,
        timestamp: data.timestamp,
      }]);
      // Hang és értesítés csak ha ez a panel nincs éppen aktív fókuszban
      if (!isActive) {
        playMessengerSound();
        onNewMessage?.(courierId);
      }
    };
    socket.on('chat_message_from_courier', handleFromCourier);
    return () => { socket.off('chat_message_from_courier', handleFromCourier); };
  }, [socket, courierId, isActive, onNewMessage]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const sendMessage = () => {
    const msg = input.trim();
    if (!msg || !socket) return;
    const ts = new Date().toISOString();
    socket.emit('chat_to_courier', { courierId, message: msg, senderName: adminName, timestamp: ts });
    setMessages((prev) => [...prev, { from: 'admin', senderName: adminName, message: msg, timestamp: ts }]);
    setInput('');
  };

  return (
    <div className="flex flex-col h-full bg-muted rounded-xl border border-primary/30 overflow-hidden">
      <div className="flex items-center gap-2 px-4 py-3 border-b border-primary/30 bg-card">
        <MessageCircle className="w-4 h-4 text-primary" />
        <span className="text-white font-semibold text-sm">{courierName}</span>
        <span className="text-muted-foreground text-xs ml-auto">Élő chat</span>
      </div>
      <ScrollArea className="flex-1 px-3 py-3 min-h-0">
        {messages.length === 0 && (
          <p className="text-center text-muted-foreground text-xs py-6">Még nincs üzenet — írj a futárnak!</p>
        )}
        {messages.map((m, i) => (
          <div key={i} className={`flex mb-3 ${m.from === 'admin' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[80%] rounded-2xl px-3 py-2 text-sm ${
              m.from === 'admin'
                ? 'bg-primary text-white rounded-br-sm'
                : 'bg-secondary text-white border border-primary/30 rounded-bl-sm'
            }`}>
              <p className="break-words">{m.message}</p>
              <p className={`text-[10px] mt-1 ${m.from === 'admin' ? 'text-orange-200' : 'text-muted-foreground'}`}>
                {new Date(m.timestamp).toLocaleTimeString('hu-HU', { hour: '2-digit', minute: '2-digit' })}
              </p>
            </div>
          </div>
        ))}
        <div ref={bottomRef} />
      </ScrollArea>
      <div className="flex items-center gap-2 px-3 py-3 border-t border-primary/30 bg-card">
        <Input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
          placeholder="Írj üzenetet a futárnak..."
          className="bg-secondary border-primary/30 text-white placeholder:text-muted-foreground text-sm"
        />
        <Button size="icon" className="bg-primary hover:bg-[#cc5200] text-white shrink-0" onClick={sendMessage} disabled={!input.trim()}>
          <Send className="w-4 h-4" />
        </Button>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Globális lebegő chat gomb + összes futár panel (admin)
// ─────────────────────────────────────────────────────────────
interface CourierEntry {
  courierId: string;
  courierName: string;
}

interface GlobalAdminChatProps {
  activeCouriers: CourierEntry[];  // aktuálisan aktív (rendeléssel rendelkező) futárok
}

export function GlobalAdminChat({ activeCouriers }: GlobalAdminChatProps) {
  const { socket } = useSocket();
  const [open, setOpen] = useState(false);
  const [activeCourierId, setActiveCourierId] = useState<string | null>(null);
  // unreadCounts: courierId → olvasatlan üzenetek száma
  const [unreadCounts, setUnreadCounts] = useState<Record<string, number>>({});

  const totalUnread = Object.values(unreadCounts).reduce((s, n) => s + n, 0);

  // Globális socket figyelő — MINDEN futártól érkező üzenetet elkapja
  useEffect(() => {
    if (!socket) return;
    const handler = (data: any) => {
      const cid: string = data.courierId;
      const isCurrentlyViewing = open && activeCourierId === cid;
      if (!isCurrentlyViewing) {
        playMessengerSound();
        setUnreadCounts((prev) => ({ ...prev, [cid]: (prev[cid] ?? 0) + 1 }));
      }
    };
    socket.on('chat_message_from_courier', handler);
    return () => { socket.off('chat_message_from_courier', handler); };
  }, [socket, open, activeCourierId]);

  // Ha megnyitjuk az adott futár chatjét, töröljük az unread-et
  const openChat = (courierId: string) => {
    setActiveCourierId(courierId);
    setUnreadCounts((prev) => ({ ...prev, [courierId]: 0 }));
    setOpen(true);
  };

  // Ha nincs egyetlen futár sem és nincs olvasatlan üzenet, rejtjük a gombot
  if (activeCouriers.length === 0 && totalUnread === 0) return null;

  const currentCourier = activeCouriers.find((c) => c.courierId === activeCourierId)
    ?? (activeCouriers.length > 0 ? activeCouriers[0] : null);

  return (
    <>
      {/* Lebegő gomb — mindig látható (minden tab-on) */}
      <button
        onClick={() => {
          if (!open) {
            const first = activeCouriers[0];
            if (first) openChat(first.courierId);
            else setOpen(true);
          } else {
            setOpen(false);
          }
        }}
        className="fixed bottom-6 right-6 z-50 flex items-center gap-2 bg-primary hover:bg-[#cc5200] text-white rounded-full shadow-lg shadow-primary/40 transition-all active:scale-95 px-4 py-3 font-semibold text-sm"
      >
        <MessageCircle className="w-5 h-5" />
        <span className="hidden md:inline">Futár chat</span>
        {totalUnread > 0 && (
          <span className="absolute -top-1.5 -right-1.5 bg-red-500 text-white text-[10px] font-bold min-w-5 h-5 rounded-full flex items-center justify-center px-1 animate-bounce">
            {totalUnread}
          </span>
        )}
      </button>

      {/* Chat panel — slide-up overlay */}
      {open && (
        <div className="fixed bottom-20 right-4 md:right-6 z-50 w-[calc(100%-2rem)] md:w-[400px] max-h-[75dvh] bg-muted rounded-2xl border border-primary/30 shadow-2xl flex flex-col overflow-hidden">
          {/* Panel fejléc */}
          <div className="flex items-center gap-3 px-4 py-3 bg-card border-b border-primary/30 shrink-0">
            <MessageCircle className="w-4 h-4 text-primary" />
            <span className="text-white font-bold text-sm flex-1">Futár chat</span>
            <button onClick={() => setOpen(false)} className="text-muted-foreground hover:text-foreground transition-colors">
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Futár tabfülek */}
          {activeCouriers.length > 1 && (
            <div className="flex gap-1 px-3 pt-2 pb-1 bg-muted shrink-0 overflow-x-auto">
              {activeCouriers.map((c) => {
                const unread = unreadCounts[c.courierId] ?? 0;
                const isActive = activeCourierId === c.courierId;
                return (
                  <button
                    key={c.courierId}
                    onClick={() => openChat(c.courierId)}
                    className={`relative flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all shrink-0 ${
                      isActive
                        ? 'bg-primary text-white'
                        : 'bg-secondary text-muted-foreground hover:text-foreground border border-primary/30'
                    }`}
                  >
                    {c.courierName}
                    {unread > 0 && (
                      <span className="bg-red-500 text-white text-[9px] font-bold w-4 h-4 rounded-full flex items-center justify-center shrink-0">
                        {unread}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          )}

          {/* Üres állapot ha nincs aktív futár */}
          {activeCouriers.length === 0 ? (
            <div className="flex-1 flex items-center justify-center text-muted-foreground text-sm p-8 text-center">
              <div>
                <MessageCircle className="w-10 h-10 mx-auto mb-2 opacity-30" />
                <p>Nincsenek regisztrált futárok</p>
              </div>
            </div>
          ) : (
            /* Chat tartalom */
            <div className="flex-1 min-h-0" style={{ height: 380 }}>
              {currentCourier && (
                <AdminChatPanel
                  key={activeCourierId ?? currentCourier.courierId}
                  courierId={activeCourierId ?? currentCourier.courierId}
                  courierName={currentCourier.courierName}
                  isActive={true}
                  onNewMessage={(cid) => {
                    playMessengerSound();
                    setUnreadCounts((prev) => ({ ...prev, [cid]: (prev[cid] ?? 0) + 1 }));
                  }}
                />
              )}
            </div>
          )}
        </div>
      )}
    </>
  );
}

// ─────────────────────────────────────────────────────────────
// Futár oldali panel — adminnak küld
// ─────────────────────────────────────────────────────────────
interface CourierChatPanelProps {
  courierId: string;
  courierName: string;
}

export function CourierChatPanel({ courierId, courierName }: CourierChatPanelProps) {
  const { socket } = useSocket();
  const storageKey = `chat_courier_${courierId}`;
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    try { return JSON.parse(localStorage.getItem(storageKey) || '[]'); } catch { return []; }
  });
  const [input, setInput] = useState('');
  const [unread, setUnread] = useState(0);
  const [open, setOpen] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    try { localStorage.setItem(storageKey, JSON.stringify(messages.slice(-100))); } catch {}
  }, [messages, storageKey]);

  useEffect(() => {
    if (!socket) return;
    const handleFromAdmin = (data: ChatMessage) => {
      setMessages((prev) => [...prev, data]);
      if (!open) {
        setUnread((n) => n + 1);
        playMessengerSound();
      }
    };
    socket.on('chat_message', handleFromAdmin);
    return () => { socket.off('chat_message', handleFromAdmin); };
  }, [socket, open]);

  useEffect(() => {
    if (open) {
      setUnread(0);
      bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [open, messages]);

  const sendMessage = () => {
    const msg = input.trim();
    if (!msg || !socket) return;
    const ts = new Date().toISOString();
    socket.emit('chat_to_admin', { courierId, courierName, message: msg, timestamp: ts });
    setMessages((prev) => [...prev, { from: 'courier', senderName: courierName, message: msg, timestamp: ts }]);
    setInput('');
  };

  if (!open) {
    return (
      <button
        onClick={() => setOpen(true)}
        className="relative flex items-center gap-2 bg-primary text-white rounded-full px-4 py-2.5 font-semibold text-sm shadow-lg shadow-primary/30 active:scale-95 transition-transform"
      >
        <MessageCircle className="w-4 h-4" />
        Chat adminnal
        {unread > 0 && (
          <span className="absolute -top-1.5 -right-1.5 bg-red-500 text-white text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center">
            {unread}
          </span>
        )}
      </button>
    );
  }

  return (
    <div className="fixed inset-x-4 bottom-4 z-50 max-w-sm mx-auto bg-muted rounded-2xl border border-primary/30 shadow-2xl flex flex-col overflow-hidden" style={{ maxHeight: '60vh' }}>
      <div className="flex items-center gap-2 px-4 py-3 border-b border-primary/30 bg-card">
        <MessageCircle className="w-4 h-4 text-primary" />
        <span className="text-white font-semibold text-sm flex-1">Chat — Admin</span>
        <button onClick={() => setOpen(false)} className="text-muted-foreground hover:text-foreground text-lg leading-none px-1">
          <X className="w-4 h-4" />
        </button>
      </div>
      <ScrollArea className="flex-1 px-3 py-3 min-h-0">
        {messages.length === 0 && (
          <p className="text-center text-muted-foreground text-xs py-6">Még nincs üzenet — írj az adminnak!</p>
        )}
        {messages.map((m, i) => (
          <div key={i} className={`flex mb-3 ${m.from === 'courier' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[80%] rounded-2xl px-3 py-2 text-sm ${
              m.from === 'courier'
                ? 'bg-primary text-white rounded-br-sm'
                : 'bg-secondary text-white border border-primary/30 rounded-bl-sm'
            }`}>
              <p className="break-words">{m.message}</p>
              <p className={`text-[10px] mt-1 ${m.from === 'courier' ? 'text-orange-200' : 'text-muted-foreground'}`}>
                {new Date(m.timestamp).toLocaleTimeString('hu-HU', { hour: '2-digit', minute: '2-digit' })}
              </p>
            </div>
          </div>
        ))}
        <div ref={bottomRef} />
      </ScrollArea>
      <div className="flex items-center gap-2 px-3 py-3 border-t border-primary/30 bg-card">
        <Input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
          placeholder="Üzenet az adminnak..."
          className="bg-secondary border-primary/30 text-white placeholder:text-muted-foreground text-sm"
        />
        <Button size="icon" className="bg-primary hover:bg-[#cc5200] text-white shrink-0" onClick={sendMessage} disabled={!input.trim()}>
          <Send className="w-4 h-4" />
        </Button>
      </div>
    </div>
  );
}

