import { ChevronRight, Phone } from 'lucide-react';
import type { Order, User } from '@/types';

interface Props {
  orders: Order[];
  couriers: User[];
  onOpenOrder: (order: Order) => void;
}

function getUserName(userId: any): string {
  if (!userId) return 'Vendég';
  if (typeof userId === 'object') return userId.name || 'Vendég';
  return 'Vendég';
}

function getCourierName(courierId: any, couriers: User[]): string {
  if (!courierId) return 'Nincs kiosztva';
  const id = typeof courierId === 'object' ? courierId._id || courierId.id : courierId;
  const c = couriers.find(x => x.id === id);
  return c ? c.name : 'Ismeretlen';
}

export default function OrdersTab({ orders, couriers, onOpenOrder }: Props) {
  // Új rendelések (nem teljesített)
  const activeOrders = orders.filter(o => o.status !== 'delivered' && o.status !== 'cancelled');
  // Teljesítve
  const completedOrders = orders.filter(o => o.status === 'delivered');
  // Sztornó
  const cancelledOrders = orders.filter(o => o.status === 'cancelled');

  const renderRow = (o: Order, isNew: boolean) => {
    const timeStr = new Date(o.createdAt).toLocaleTimeString('hu-HU', { hour: '2-digit', minute: '2-digit' });
    const orderNum = (o as any).order_number || o._id.slice(-3);
    const isPickup = o.delivery_type === 'elvitel';
    const isDineIn = o.delivery_type === 'beülős';
    const uName = isPickup ? 'Elvitel' : (isDineIn ? 'Beülős' : (o.guest_name || getUserName(o.user_id)));
    const cName = getCourierName(o.courier_id, couriers);
    const phone = (isPickup || isDineIn) ? '' : ((o as any).phone || (typeof o.user_id === 'object' ? (o.user_id as any).phone : '') || '');
    
    const isWeb = ((o as any).source === 'weboldal' || !(o as any).source);
    
    return (
      <div 
        key={o._id} 
        onClick={() => onOpenOrder(o)}
        className={`flex items-center mb-2 cursor-pointer transition-colors shadow-sm ${o.status === 'cancelled' ? 'bg-red-50/50 hover:bg-red-100/50' : 'bg-white hover:bg-gray-50'}`}
      >
        <div className={`w-1.5 self-stretch ${isNew ? 'bg-[#e73423]' : 'bg-[#d1d5db]'}`} />
        
        <div className="flex-1 flex items-center px-4 py-3 min-w-0 gap-4">
          <div className="w-10 shrink-0 font-bold text-gray-700">{String(orderNum).padStart(3, '0')}</div>
          
          <div className="w-40 shrink-0 font-bold text-foreground truncate">{uName}</div>
          
          <div className="flex-1 min-w-0 text-sm text-gray-600 flex flex-col justify-center leading-tight">
            <span className="truncate">{o.address || '—'}</span>
            <span className="text-gray-500 font-medium">Futár: {cName}</span>
          </div>
          
          <div className="w-32 shrink-0 text-sm font-medium text-gray-800">{phone}</div>
          
          <div className="w-16 shrink-0 text-sm text-gray-500">{timeStr}</div>
          
          <div className="w-48 shrink-0 flex items-center gap-2 text-sm text-gray-600">
            {!isWeb && <Phone className="w-3.5 h-3.5" />}
            <span>{isWeb ? 'Weboldal' : 'Telefonos'} · {o.payment_method}</span>
          </div>
          
          <div className="w-24 shrink-0 text-right font-bold text-foreground">
            {o.total.toLocaleString('hu-HU')} Ft
          </div>
          
          <div className="w-8 shrink-0 flex justify-end text-gray-400">
            <ChevronRight className="w-5 h-5" />
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="h-full bg-[#eef1f4] p-4 md:p-6 overflow-y-auto">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-base font-bold text-gray-800 mb-3 px-1">Új</h2>
        <div className="mb-8">
          {activeOrders.length === 0 ? (
            <p className="text-sm text-gray-500 px-1">Nincs új rendelés.</p>
          ) : (
            activeOrders.map(o => renderRow(o, true))
          )}
        </div>

        <h2 className="text-base font-bold text-gray-800 mb-3 px-1">Teljesítve</h2>
        <div className="mb-8">
          {completedOrders.length === 0 ? (
            <p className="text-sm text-gray-500 px-1">Nincs teljesített rendelés.</p>
          ) : (
            completedOrders.map(o => renderRow(o, false))
          )}
        </div>

        <h2 className="text-base font-bold text-gray-800 mb-3 px-1">Sztornó</h2>
        <div>
          {cancelledOrders.length === 0 ? (
            <p className="text-sm text-gray-500 px-1">Nincs sztornózott rendelés.</p>
          ) : (
            cancelledOrders.map(o => renderRow(o, false))
          )}
        </div>
      </div>
    </div>
  );
}