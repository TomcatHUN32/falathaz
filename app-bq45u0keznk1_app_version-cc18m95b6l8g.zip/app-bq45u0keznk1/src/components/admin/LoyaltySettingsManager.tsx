import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { settingsApi } from '@/services/api';

export default function LoyaltySettingsManager() {
  const [settings, setSettings] = useState({
    amount_per_point: 100,
    points_usable_per_order: 1000
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    settingsApi.get('loyalty_settings').then(res => {
      const data = res.data?.value || res.data;
      if (data && typeof data === 'object') {
        setSettings({
          amount_per_point: 100,
          points_usable_per_order: 1000,
          ...data
        });
      }
    }).finally(() => setLoading(false));
  }, []);

  const handleSave = async () => {
    try {
      await settingsApi.update('loyalty_settings', settings);
      toast.success('Hűségprogram beállítások mentve!');
    } catch {
      toast.error('Hiba a mentés során');
    }
  };

  if (loading) return null;

  return (
    <Card className="bg-card border-border">
      <CardContent className="p-4 space-y-4">
        <h3 className="font-bold text-lg text-foreground">Hűségprogram Beállítások</h3>
        
        <div className="space-y-3">
          <div>
            <Label className="text-xs text-muted-foreground">Mekkora vásárlási összeg (Ft) ér 1 pontot?</Label>
            <Input 
              type="number" 
              value={settings.amount_per_point} 
              onChange={e => setSettings({...settings, amount_per_point: Number(e.target.value)})} 
            />
            <p className="text-[10px] text-muted-foreground mt-1">Például: ha 100-at adsz meg, akkor egy 5000 Ft-os rendelés után 50 pontot kap a vásárló.</p>
          </div>
          <div>
            <Label className="text-xs text-muted-foreground">Maximálisan felhasználható pont / rendelés</Label>
            <Input 
              type="number" 
              value={settings.points_usable_per_order} 
              onChange={e => setSettings({...settings, points_usable_per_order: Number(e.target.value)})} 
            />
          </div>
        </div>

        <div className="pt-4">
          <Button onClick={handleSave} className="w-full btn-primary-gradient text-white">Mentés</Button>
        </div>
      </CardContent>
    </Card>
  );
}
