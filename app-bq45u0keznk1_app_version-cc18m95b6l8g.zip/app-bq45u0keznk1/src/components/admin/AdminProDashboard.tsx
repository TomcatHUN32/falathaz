import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, Cell, PieChart, Pie, Cell as PieCell } from 'recharts';
import { MapPin, User, Phone, TrendingUp, Navigation, Truck, Package, Clock, ShieldAlert } from 'lucide-react';

const revData = [
  { time: '11:15', value: 12500 },
  { time: '11:30', value: 25000 },
  { time: '12:00', value: 18000 },
  { time: '12:30', value: 45000 },
  { time: '13:00', value: 85000 },
  { time: '13:30', value: 65000 },
  { time: '14:00', value: 40000 },
];

const customerData = [
  { time: '11:15', value: 50 },
  { time: '11:30', value: 120 },
  { time: '12:00', value: 300 },
  { time: '12:30', value: 450 },
  { time: '13:00', value: 680 },
  { time: '13:30', value: 550 },
  { time: '14:00', value: 320 },
];

const segmentData = [
  { name: 'Visszatérő', value: 1200 },
  { name: 'Új', value: 800 },
  { name: 'VIP', value: 1500 },
  { name: 'Lemozsolódó', value: 300 },
];

const inventoryData = [
  { month: 'Jan', value: 2500 },
  { month: 'Feb', value: 2100 },
  { month: 'Mar', value: 1800 },
  { month: 'Apr', value: 1500 },
  { month: 'May', value: 2800 },
  { month: 'Jun', value: 3000 },
  { month: 'Jul', value: 2400 },
  { month: 'Aug', value: 1900 },
  { month: 'Sep', value: 2200 },
  { month: 'Oct', value: 2600 },
];

const AdminProDashboard = () => {
  return (
    <div className="w-full min-h-screen bg-[#1b1f24] text-gray-300 p-2 md:p-4 overflow-y-auto space-y-4 font-sans selection:bg-yellow-500/30">
      
      {/* 2x2 GRID FOR THE MAIN 4 PANELS */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        
        {/* PANEL 1: EXECUTIVE OVERVIEW */}
        <Card className="bg-[#22272d] border-[#30363d] overflow-hidden flex flex-col h-full rounded-xl">
          <CardHeader className="bg-[#2a3036] py-3 px-4 border-b border-[#30363d]">
            <div className="flex items-center justify-between">
              <CardTitle className="text-gray-100 font-bold text-lg">Executive Overview</CardTitle>
              <div className="flex gap-2">
                <Badge variant="outline" className="bg-yellow-500/10 text-yellow-500 border-yellow-500/30 hover:bg-yellow-500/20">
                  Owner
                </Badge>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-4 grid grid-cols-2 gap-4 flex-1">
            <div className="space-y-4">
              <div className="bg-[#1b1f24] p-3 rounded-lg border border-[#30363d]">
                <div className="flex justify-between items-center mb-2">
                  <h4 className="text-sm font-semibold text-gray-400">Heti Forgalom</h4>
                  <TrendingUp className="w-4 h-4 text-yellow-500" />
                </div>
                <div className="h-32">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={revData}>
                      <defs>
                        <linearGradient id="colorRev" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#eab308" stopOpacity={0.4}/>
                          <stop offset="95%" stopColor="#eab308" stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="#30363d" vertical={false} />
                      <XAxis dataKey="time" stroke="#6b7280" fontSize={10} tickLine={false} axisLine={false} />
                      <YAxis stroke="#6b7280" fontSize={10} tickLine={false} axisLine={false} tickFormatter={(val) => `${val/1000}k`} />
                      <Tooltip contentStyle={{ backgroundColor: '#22272d', borderColor: '#30363d' }} itemStyle={{ color: '#eab308' }} />
                      <Area type="monotone" dataKey="value" stroke="#eab308" strokeWidth={2} fillOpacity={1} fill="url(#colorRev)" />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </div>
              <div className="bg-[#1b1f24] p-3 rounded-lg border border-[#30363d]">
                <div className="flex justify-between items-center mb-2">
                  <h4 className="text-sm font-semibold text-gray-400">Új Forgalom</h4>
                  <TrendingUp className="w-4 h-4 text-yellow-500" />
                </div>
                <div className="h-32">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={revData}>
                      <defs>
                        <linearGradient id="colorRev2" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#eab308" stopOpacity={0.4}/>
                          <stop offset="95%" stopColor="#eab308" stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="#30363d" vertical={false} />
                      <XAxis dataKey="time" stroke="#6b7280" fontSize={10} tickLine={false} axisLine={false} />
                      <YAxis stroke="#6b7280" fontSize={10} tickLine={false} axisLine={false} tickFormatter={(val) => `${val/1000}k`} />
                      <Tooltip contentStyle={{ backgroundColor: '#22272d', borderColor: '#30363d' }} itemStyle={{ color: '#eab308' }} />
                      <Area type="monotone" dataKey="value" stroke="#eab308" strokeWidth={2} fillOpacity={1} fill="url(#colorRev2)" />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>
            
            <div className="space-y-4">
              <div className="bg-[#1b1f24] p-3 rounded-lg border border-[#30363d]">
                <div className="flex justify-between items-center mb-2">
                  <h4 className="text-sm font-semibold text-gray-400">Új Vásárlók</h4>
                  <User className="w-4 h-4 text-yellow-500" />
                </div>
                <div className="h-32">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={customerData}>
                      <defs>
                        <linearGradient id="colorCust" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#eab308" stopOpacity={0.4}/>
                          <stop offset="95%" stopColor="#eab308" stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="#30363d" vertical={false} />
                      <XAxis dataKey="time" stroke="#6b7280" fontSize={10} tickLine={false} axisLine={false} />
                      <YAxis stroke="#6b7280" fontSize={10} tickLine={false} axisLine={false} />
                      <Tooltip contentStyle={{ backgroundColor: '#22272d', borderColor: '#30363d' }} itemStyle={{ color: '#eab308' }} />
                      <Area type="monotone" dataKey="value" stroke="#eab308" strokeWidth={2} fillOpacity={1} fill="url(#colorCust)" />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </div>

              <div className="bg-[#1b1f24] p-3 rounded-lg border border-[#30363d] h-[178px] flex flex-col">
                <div className="flex justify-between items-center mb-2 shrink-0">
                  <h4 className="text-sm font-semibold text-gray-400">Rendelési Csúcsidők</h4>
                  <Clock className="w-4 h-4 text-yellow-500" />
                </div>
                <div className="flex-1 grid grid-cols-8 grid-rows-7 gap-0.5 mt-1 overflow-hidden opacity-90 hover:opacity-100 transition-opacity">
                  {/* Heatmap mock grid */}
                  {Array.from({ length: 56 }).map((_, i) => {
                    const heat = Math.random();
                    let bg = 'bg-[#2a3036]';
                    if (heat > 0.8) bg = 'bg-yellow-500';
                    else if (heat > 0.6) bg = 'bg-yellow-500/70';
                    else if (heat > 0.4) bg = 'bg-yellow-500/40';
                    else if (heat > 0.2) bg = 'bg-yellow-500/20';
                    
                    return <div key={i} className={`rounded-[2px] ${bg}`} />
                  })}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* PANEL 2: LOGISZTIKAI IRÁNYÍTÓ */}
        <Card className="bg-[#22272d] border-[#30363d] overflow-hidden flex flex-col h-full rounded-xl">
          <CardHeader className="bg-[#2a3036] py-3 px-4 border-b border-[#30363d]">
            <div className="flex items-center justify-between">
              <CardTitle className="text-gray-100 font-bold text-lg">Logisztikai Irányító</CardTitle>
              <Badge variant="outline" className="bg-yellow-500/10 text-yellow-500 border-yellow-500/30">
                Owner
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="p-4 grid grid-cols-2 gap-4 flex-1">
            {/* Map Placeholder */}
            <div className="bg-[#1b1f24] rounded-lg border border-[#30363d] overflow-hidden relative min-h-[300px]">
              {/* Fake Google Map background */}
              <div className="absolute inset-0 bg-[#252f3d] bg-[url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI0MCIgaGVpZ2h0PSI0MCI+PGVjdCB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzFkMjYzMSIgc3Ryb2tlLXdpZHRoPSIxIi8+PC9zdmc+')]">
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 bg-yellow-500/30 blur-3xl rounded-full mix-blend-screen" />
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-24 h-24 bg-red-500/40 blur-2xl rounded-full mix-blend-screen" />
                <MapPin className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-8 h-8 text-white drop-shadow-md z-10" />
                
                <div className="absolute bottom-3 left-3 bg-[#1b1f24]/90 backdrop-blur border border-[#30363d] p-2 rounded text-xs">
                  <div className="font-semibold text-gray-300">Live ETA predictions</div>
                  <div className="text-green-400 font-bold text-sm">1.2 min</div>
                </div>
              </div>
            </div>

            {/* Courier Status */}
            <div className="space-y-3 flex flex-col">
              <h4 className="text-sm font-semibold text-gray-400 px-1">Courier Status</h4>
              <div className="flex-1 overflow-y-auto space-y-3 pr-2 scrollbar-thin scrollbar-thumb-[#30363d]">
                {[
                  { name: 'Szabi', dist: '8.4 km', time: '10.5 ft', rev: '1.999.259 Ft', active: true },
                  { name: 'Stabi', dist: '8.4 km', time: '10.5 ft', rev: '1.999.259 Ft', active: false },
                  { name: 'Scebi', dist: '8.4 km', time: '10.5 ft', rev: '1.999.259 Ft', active: false },
                  { name: 'Stabi', dist: '8.4 km', time: '10.5 ft', rev: '1.999.259 Ft', active: false },
                ].map((c, i) => (
                  <div key={i} className={`bg-[#1b1f24] border ${c.active ? 'border-yellow-500/50 bg-yellow-500/5' : 'border-[#30363d]'} rounded-lg p-3 relative`}>
                    <div className="flex justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-full bg-[#2a3036] flex items-center justify-center border border-[#30363d]">
                          <User className="w-4 h-4 text-gray-400" />
                        </div>
                        <div>
                          <div className="text-sm font-bold text-gray-200">{c.name}</div>
                          <div className="text-[10px] text-gray-500">0 Nincs kint | {c.dist}</div>
                        </div>
                      </div>
                      {c.active && (
                        <Badge className="bg-yellow-500/20 text-yellow-500 border-yellow-500/50 hover:bg-yellow-500/20 text-[10px] h-5">
                          Online
                        </Badge>
                      )}
                    </div>
                    <div className="grid grid-cols-2 gap-y-1 text-xs">
                      <span className="text-gray-500">Vehicle status:</span>
                      <span className="text-right text-green-400">Jó</span>
                      <span className="text-gray-500">Kiszállítási idő:</span>
                      <span className="text-right text-gray-300">{c.time}</span>
                      <span className="text-gray-500">Bevétel:</span>
                      <span className="text-right text-gray-300">{c.rev}</span>
                    </div>
                    <div className="mt-3 flex items-center gap-1.5 text-xs text-yellow-500">
                      <Truck className="w-3.5 h-3.5" /> Vehicle Status
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* PANEL 3: ÜGYFÉL ÉS MARKETING */}
        <Card className="bg-[#22272d] border-[#30363d] overflow-hidden flex flex-col h-full rounded-xl">
          <CardHeader className="bg-[#2a3036] py-3 px-4 border-b border-[#30363d]">
            <div className="flex items-center justify-between">
              <CardTitle className="text-gray-100 font-bold text-lg">Ügyfél és Marketing Panel</CardTitle>
              <Badge variant="outline" className="bg-yellow-500/10 text-yellow-500 border-yellow-500/30">
                Owner
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="p-4 grid grid-cols-3 gap-4 flex-1">
            {/* CRM Profile */}
            <div className="bg-[#1b1f24] rounded-lg border border-[#30363d] p-3 flex flex-col space-y-4">
              <div className="flex justify-between items-center">
                <h4 className="text-sm font-semibold text-gray-400">CRM Profile</h4>
                <Badge className="bg-yellow-500/20 text-yellow-500 border-none hover:bg-yellow-500/20 text-xs">
                  Prémium
                </Badge>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-[#2a3036] flex items-center justify-center border border-[#30363d]">
                  <User className="w-6 h-6 text-gray-400" />
                </div>
                <div>
                  <div className="font-bold text-gray-200">Szabi</div>
                  <div className="text-xs text-gray-500">0 Rendelés • 0 pont</div>
                </div>
              </div>
              <div className="space-y-1.5 text-xs">
                <div className="flex justify-between"><span className="text-gray-500">Név:</span><span className="text-gray-300">Kiss Szabolcs</span></div>
                <div className="flex justify-between"><span className="text-gray-500">Város:</span><span className="text-gray-300">Tatabánya</span></div>
                <div className="flex justify-between"><span className="text-gray-500">Utca:</span><span className="text-gray-300">Fő tér 1.</span></div>
                <div className="flex justify-between"><span className="text-gray-500">Házszám:</span><span className="text-gray-300">Emelet 2, Ajtó 4</span></div>
                <div className="flex justify-between"><span className="text-gray-500">Telefon:</span><span className="text-gray-300">+36 30 123 4567</span></div>
              </div>
              <div className="space-y-2 pt-2 border-t border-[#30363d] flex-1 flex flex-col justify-end">
                <div>
                  <div className="flex justify-between text-xs mb-1"><span className="text-gray-400">Telefonos</span><span className="text-gray-200">45%</span></div>
                  <div className="h-1.5 bg-[#2a3036] rounded-full overflow-hidden"><div className="h-full bg-yellow-500 w-[45%]" /></div>
                </div>
                <div>
                  <div className="flex justify-between text-xs mb-1"><span className="text-gray-400">Visszatérő</span><span className="text-gray-200">67%</span></div>
                  <div className="h-1.5 bg-[#2a3036] rounded-full overflow-hidden"><div className="h-full bg-yellow-500 w-[67%]" /></div>
                </div>
                <div>
                  <div className="flex justify-between text-xs mb-1"><span className="text-gray-400">Kampányból</span><span className="text-gray-200">12%</span></div>
                  <div className="h-1.5 bg-[#2a3036] rounded-full overflow-hidden"><div className="h-full bg-yellow-500 w-[12%]" /></div>
                </div>
              </div>
            </div>

            {/* Segmentation & Campaigns */}
            <div className="col-span-2 space-y-4 flex flex-col">
              <div className="grid grid-cols-2 gap-4 flex-1">
                <div className="bg-[#1b1f24] rounded-lg border border-[#30363d] p-3 flex flex-col">
                  <h4 className="text-sm font-semibold text-gray-400 mb-2">Auto Segmentation</h4>
                  <div className="flex-1 min-h-[120px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={segmentData} margin={{ top: 5, right: 0, left: 0, bottom: 5 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#30363d" vertical={false} />
                        <XAxis dataKey="name" stroke="#6b7280" fontSize={9} tickLine={false} axisLine={false} />
                        <Tooltip cursor={{ fill: '#2a3036' }} contentStyle={{ backgroundColor: '#22272d', borderColor: '#30363d' }} />
                        <Bar dataKey="value" fill="#eab308" radius={[2, 2, 0, 0]} maxBarSize={30} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>
                <div className="bg-[#1b1f24] rounded-lg border border-[#30363d] p-3 flex flex-col">
                  <h4 className="text-sm font-semibold text-gray-400 mb-2">Ügyfél Segmentation</h4>
                  <div className="flex-1 min-h-[120px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={segmentData.map(d => ({...d, value: d.value * 0.8}))} margin={{ top: 5, right: 0, left: 0, bottom: 5 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#30363d" vertical={false} />
                        <XAxis dataKey="name" stroke="#6b7280" fontSize={9} tickLine={false} axisLine={false} />
                        <Tooltip cursor={{ fill: '#2a3036' }} contentStyle={{ backgroundColor: '#22272d', borderColor: '#30363d' }} />
                        <Bar dataKey="value" fill="#eab308" radius={[2, 2, 0, 0]} maxBarSize={30} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-[#1b1f24] p-3 rounded-lg border border-[#30363d]">
                  <h4 className="text-sm font-semibold text-gray-400 mb-2">Campaign Performance</h4>
                  <div className="h-24">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={customerData}>
                        <defs>
                          <linearGradient id="colorROI1" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#eab308" stopOpacity={0.4}/>
                            <stop offset="95%" stopColor="#eab308" stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <XAxis dataKey="time" hide />
                        <Tooltip contentStyle={{ backgroundColor: '#22272d', borderColor: '#30363d' }} itemStyle={{ color: '#eab308' }} />
                        <Area type="monotone" dataKey="value" stroke="#eab308" strokeWidth={2} fillOpacity={1} fill="url(#colorROI1)" />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </div>
                <div className="bg-[#1b1f24] p-3 rounded-lg border border-[#30363d]">
                  <h4 className="text-sm font-semibold text-gray-400 mb-2">ROI Tracker</h4>
                  <div className="h-24">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={revData}>
                        <defs>
                          <linearGradient id="colorROI2" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#eab308" stopOpacity={0.4}/>
                            <stop offset="95%" stopColor="#eab308" stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <XAxis dataKey="time" hide />
                        <Tooltip contentStyle={{ backgroundColor: '#22272d', borderColor: '#30363d' }} itemStyle={{ color: '#eab308' }} />
                        <Area type="monotone" dataKey="value" stroke="#eab308" strokeWidth={2} fillOpacity={1} fill="url(#colorROI2)" />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* PANEL 4: PÉNZÜGYI & KÉSZLET */}
        <Card className="bg-[#22272d] border-[#30363d] overflow-hidden flex flex-col h-full rounded-xl">
          <CardHeader className="bg-[#2a3036] py-3 px-4 border-b border-[#30363d]">
            <div className="flex items-center justify-between">
              <CardTitle className="text-gray-100 font-bold text-lg">Pénzügyi & Készlet Panel</CardTitle>
              <Badge variant="outline" className="bg-yellow-500/10 text-yellow-500 border-yellow-500/30">
                Owner
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="p-4 grid grid-cols-2 gap-4 flex-1">
            <div className="space-y-4 flex flex-col">
              <div className="bg-[#1b1f24] p-4 rounded-lg border border-[#30363d]">
                <h4 className="text-sm font-semibold text-gray-400 mb-4">Real time Revenue</h4>
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <span className="w-20 text-xs text-gray-400">Revenue</span>
                    <div className="flex-1 h-2 bg-[#2a3036] rounded-full overflow-hidden">
                      <div className="h-full bg-yellow-500 w-[80%]" />
                    </div>
                    <span className="text-xs text-gray-200 font-mono">15.990 Ft</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="w-20 text-xs text-gray-400">Profit Margin</span>
                    <div className="flex-1 h-2 bg-[#2a3036] rounded-full overflow-hidden">
                      <div className="h-full bg-yellow-500 w-[68%]" />
                    </div>
                    <span className="text-xs text-gray-200 font-mono">68.5%</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="w-20 text-xs text-gray-400">Kiadások</span>
                    <div className="flex-1 h-2 bg-[#2a3036] rounded-full overflow-hidden">
                      <div className="h-full bg-yellow-500 w-[30%]" />
                    </div>
                    <span className="text-xs text-gray-200 font-mono">4.500 Ft</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="w-20 text-xs text-gray-400">Adók</span>
                    <div className="flex-1 h-2 bg-[#2a3036] rounded-full overflow-hidden">
                      <div className="h-full bg-yellow-500 w-[15%]" />
                    </div>
                    <span className="text-xs text-gray-200 font-mono">2.250 Ft</span>
                  </div>
                </div>
              </div>
              
              <div className="bg-[#1b1f24] p-3 rounded-lg border border-[#30363d] flex-1 flex flex-col">
                <h4 className="text-sm font-semibold text-gray-400 mb-2">Inventory Forecasting</h4>
                <div className="flex-1 min-h-[140px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={inventoryData} margin={{ top: 5, right: 0, left: 0, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#30363d" vertical={false} />
                      <XAxis dataKey="month" stroke="#6b7280" fontSize={9} tickLine={false} axisLine={false} />
                      <Tooltip cursor={{ fill: '#2a3036' }} contentStyle={{ backgroundColor: '#22272d', borderColor: '#30363d' }} />
                      <Bar dataKey="value" fill="#eab308" radius={[2, 2, 0, 0]} maxBarSize={20} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>

            <div className="space-y-4 flex flex-col">
              <div className="bg-[#1b1f24] p-4 rounded-lg border border-[#30363d] flex flex-col items-center justify-center relative">
                <h4 className="text-sm font-semibold text-gray-400 absolute top-4 left-4">Profit Margin</h4>
                <div className="w-40 h-40 mt-6 relative flex flex-col items-center justify-center">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={[{ value: 68.5 }, { value: 31.5 }]}
                        cx="50%" cy="50%"
                        startAngle={180} endAngle={0}
                        innerRadius={60} outerRadius={80}
                        stroke="none"
                        dataKey="value"
                      >
                        <PieCell fill="#eab308" />
                        <PieCell fill="#2a3036" />
                      </Pie>
                    </PieChart>
                  </ResponsiveContainer>
                  <div className="absolute inset-0 flex items-center justify-center flex-col top-10">
                    <span className="text-2xl font-bold text-green-400">68.5%</span>
                    <span className="text-xs text-gray-500">Margin</span>
                  </div>
                </div>
              </div>

              <div className="bg-[#1b1f24] p-4 rounded-lg border border-[#30363d] flex-1">
                <h4 className="text-sm font-semibold text-gray-400 mb-4">Supply Chain Status</h4>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-gray-400">Supply Chain state</span>
                    <Badge className="bg-green-500/20 text-green-400 border-none hover:bg-green-500/20 text-[10px]">Normál</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-gray-400">Supply Chain inventory</span>
                    <Badge className="bg-yellow-500/20 text-yellow-500 border-none hover:bg-yellow-500/20 text-[10px]">Elégséges</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-gray-400">Supply Chain status</span>
                    <Badge className="bg-red-500/20 text-red-400 border-none hover:bg-red-500/20 text-[10px]">Kritikus</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-gray-400">Supply Chain connection</span>
                    <Badge className="bg-green-500/20 text-green-400 border-none hover:bg-green-500/20 text-[10px]">Online</Badge>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default AdminProDashboard;
