import { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import {
  Phone, Search, CheckCircle, ArrowRight, ArrowLeft, Trash2,
  Plus, Minus, Package, Truck, MapPin, Clock, ChevronRight, X,
  ShoppingCart, Check, ChefHat, Info, AlertCircle, UtensilsCrossed
} from 'lucide-react';
import { toast } from 'sonner';
import type { Product, ToppingGroup, Order, User, OrderItemExtra } from '@/types';
import { orderApi, authApi, cityApi, couponApi, settingsApi } from '@/services/api';

interface CartItem {
  product_id: string;
  name: string;
  quantity: number;
  price: number;
  packaging_fee: number;
  drs_applies: boolean;
  extrasKey?: string;
  extrasLabel?: string;
  extrasArray?: OrderItemExtra[];
  note?: string; // Tételszintű megjegyzés
}

interface Props {
  products: Product[];
  categories: string[];
  toppingGroups: ToppingGroup[];
  onOrderCreated: (order: Order) => void;
}

// Lépések: 0=Vásárló, 1=Kosár (kategória/termék), 2=Fizetés
type Step = 0 | 1 | 2;

export default function CrmPosPanel({ products, categories, toppingGroups, onOrderCreated, initialTable, existingOrderId }: Props & { initialTable?: string, existingOrderId?: string | null }) {
  // ── Lépés ─────────────────────────────────────────────────────
  const [step, setStep] = useState<Step>(0);

  // ── Vásárló adatok (1. lépés) ─────────────────────────────────
  const [phone, setPhone] = useState('');
  const [guestName, setGuestName] = useState('');
  const [foundUser, setFoundUser] = useState<User | null>(null);
  const [userSearched, setUserSearched] = useState(false);
  const [phoneSuggestions, setPhoneSuggestions] = useState<Array<{
    source: string;
    id: string | null;
    name: string;
    phone: string;
    address: string;
    city_name: string;
    street: string;
    house_number: string;
    floor: string;
    door: string;
    bell: string;
  }>>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const phoneInputRef = useRef<HTMLDivElement>(null);
  const [deliveryType, setDeliveryType] = useState<'szállítás' | 'elvitel' | 'beülős'>(initialTable ? 'beülős' : 'szállítás');
  const [city, setCity] = useState('');
  useEffect(() => {
    if (initialTable) {
      setDeliveryType('beülős');
      setStreet(initialTable);
    }
  }, [initialTable]);

  useEffect(() => {
    if (existingOrderId) {
      orderApi.getById(existingOrderId).then((res) => {
        const o = res.data;
        if (o) {
          setDeliveryType(o.delivery_type);
          setStreet(o.address || initialTable || '');
          setPhone(o.phone || '');
          setGuestName(o.guest_name || '');
          setNotes(o.notes || '');
          setPaymentMethod(o.payment_method || 'Készpénz');
          
          if (o.items && Array.isArray(o.items)) {
            const loadedCart: CartItem[] = o.items.map((it: any) => ({
              uid: Math.random().toString(36).substr(2, 9),
              product_id: it.product_id,
              name: it.name,
              price: it.price,
              quantity: it.quantity,
              packaging_fee: it.packaging_fee || 0,
              drs_applies: it.drs_applies || false,
              extrasLabel: it.extras_label || '',
              extrasArray: it.extras || [],
              note: it.note || ''
            }));
            setCart(loadedCart);
          }
          setStep(1); // Ugrás a termékekhez
        }
      }).catch((err) => {
        toast.error('Rendelés betöltése sikertelen');
      });
    }
  }, [existingOrderId]);
  const [street, setStreet] = useState('');
  const [houseNumber, setHouseNumber] = useState('');
  const [floor, setFloor] = useState('');
  const [door, setDoor] = useState('');
  const [bell, setBell] = useState('');
  const [notes, setNotes] = useState('');
  const [cities, setCities] = useState<Array<{ _id: string; name: string; delivery_fee: number; free_delivery_threshold?: number }>>([]);

  // Városok betöltése
  useEffect(() => {
    cityApi.getAll().then((res) => {
      setCities(Array.isArray(res.data) ? res.data : []);
    }).catch(() => {
      setCities([]);
    });
  }, []);

  // ── Kosár navigáció (2. lépés) ────────────────────────────────
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const searchRef = useRef<HTMLInputElement>(null);
  const [searchTick, setSearchTick] = useState(0);

  // ── Kosár ─────────────────────────────────────────────────────
  const [cart, setCart] = useState<CartItem[]>([]);
  // ── Öntet-modal ───────────────────────────────────────────────
  const [configProduct, setConfigProduct] = useState<Product | null>(null);
  const [selectedExtras, setSelectedExtras] = useState<Record<string, string[]>>({});

  // ── Fizetés (3. lépés) ────────────────────────────────────────
  const [paymentMethod, setPaymentMethod] = useState<'Készpénz' | 'Bankkártya'>('Készpénz');
  const [discountPct, setDiscountPct] = useState(0);
  const [couponCode, setCouponCode] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<{ name: string; code: string; discount_pct: number } | null>(null);
  const [couponLoading, setCouponLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  // Felhasználó / korábbi rendelés betöltésekor cím auto-kitöltés
  useEffect(() => {
    if (!foundUser) return;
    setGuestName(foundUser.name || '');
    // Regisztrált felhasználó: default_address alapján
    if ((foundUser as any).source === 'registered' || foundUser.role === 'customer') {
      const addr = foundUser.default_address || '';
      const parts = addr.split(',');
      setCity(parts.length >= 2 ? parts[0].trim() : '');
      setStreet(parts.length >= 2 ? parts.slice(1).join(',').trim() : addr);
      setHouseNumber('');
      setFloor('');
      setDoor('');
      setBell('');
    }
    // Korábbi rendelésből: részletes cím mezők
    if ((foundUser as any).source === 'order_history') {
      const fu = foundUser as any;
      if (fu.city_name) setCity(fu.city_name);
      if (fu.street) setStreet(fu.street);
      if (fu.house_number) setHouseNumber(fu.house_number);
      if (fu.floor) setFloor(fu.floor);
      if (fu.door) setDoor(fu.door);
      if (fu.bell) setBell(fu.bell);
    }
  }, [foundUser]);

  // ── Telefon autocomplete (debounced) ──
  useEffect(() => {
    if (!phone.trim() || phone.trim().length < 3) {
      setPhoneSuggestions([]);
      setShowSuggestions(false);
      return;
    }
    const id = setTimeout(async () => {
      try {
        const res = await authApi.searchSuggestions(phone.trim());
        setPhoneSuggestions(Array.isArray(res.data) ? res.data : []);
        setShowSuggestions(true);
      } catch {
        setPhoneSuggestions([]);
        setShowSuggestions(false);
      }
    }, 300);
    return () => clearTimeout(id);
  }, [phone]);

  // Kattintás a suggestion-en kívülre → bezárás
  useEffect(() => {
    const handle = (e: MouseEvent) => {
      if (phoneInputRef.current && !phoneInputRef.current.contains(e.target as Node)) {
        setShowSuggestions(false);
      }
    };
    document.addEventListener('mousedown', handle);
    return () => document.removeEventListener('mousedown', handle);
  }, []);

  // ── Kalkuláció ─────────────────────────────────────────────────
  const isDineIn = deliveryType === 'beülős';
  const subtotal = cart.reduce((s, i) => s + i.price * i.quantity, 0);
  const packagingTotal = isDineIn ? 0 : cart.reduce((s, i) => s + (i.packaging_fee || 0) * i.quantity, 0);
  const drsTotal = cart.reduce((s, i) => s + (i.drs_applies ? 50 * i.quantity : 0), 0);
  const selectedCity = cities.find((c) => c.name === city) || null;
  let deliveryFee = (deliveryType === 'elvitel' || isDineIn) ? 0 : (selectedCity?.delivery_fee ?? 0);
  const cityThreshold = selectedCity?.free_delivery_threshold || 0;
  if (cityThreshold > 0 && subtotal >= cityThreshold) {
    deliveryFee = 0;
  }
  const effectiveDiscountPct = appliedCoupon ? appliedCoupon.discount_pct : Math.min(Math.max(discountPct, 0), 100);
  const discountAmount = Math.round((subtotal * effectiveDiscountPct) / 100);
  const total = subtotal + packagingTotal + drsTotal + deliveryFee - discountAmount;
  const fullAddress = isDineIn ? 'Beülős' : [city.trim(), street.trim(), houseNumber.trim()].filter(Boolean).join(', ');
  const cartCount = cart.reduce((s, i) => s + i.quantity, 0);

  // ── Segédfüggvények ─────────────────────────────────────────────
  const searchUser = async () => {
    if (!phone.trim() || phone.trim().length < 5) return;
    try {
      const res = await authApi.searchUser(phone.trim());
      setFoundUser(res.data);
      setUserSearched(true);
      if (!res.data) toast.info('Nem regisztrált — vendégként rögzíthető.');
    } catch {
      setFoundUser(null);
      setUserSearched(true);
    }
  };

  const applyCoupon = async () => {
    if (!couponCode.trim()) return;
    setCouponLoading(true);
    try {
      const res = await couponApi.validate(couponCode.trim());
      setAppliedCoupon(res.data);
      setDiscountPct(0);
      toast.success(`Kupon alkalmazva: ${res.data.name} (-${res.data.discount_pct}%)`);
    } catch (err: any) {
      setAppliedCoupon(null);
      toast.error(err.response?.data?.error || 'Érvénytelen kuponkód');
    } finally {
      setCouponLoading(false);
    }
  };

  const clearCoupon = () => {
    setAppliedCoupon(null);
    setCouponCode('');
  };

  const addToCartDirect = (product: Product, extras: OrderItemExtra[] = [], qty = 1, note = '') => {
    const extrasKey = extras.map((e) => e.option_id).sort().join('|') + '|note:' + note;
    const extraPrice = extras.reduce((s, e) => s + e.price, 0);
    setCart((prev) => {
      const existing = prev.find((i) => i.product_id === product._id && (i.extrasKey ?? '') === extrasKey);
      if (existing) {
        return prev.map((i) => (i.product_id === product._id && (i.extrasKey ?? '') === extrasKey) ? { ...i, quantity: i.quantity + qty } : i);
      }
      return [...prev, {
        product_id: product._id,
        name: product.name,
        quantity: qty,
        price: product.price + extraPrice,
        packaging_fee: product.packaging_fee || 0,
        drs_applies: product.drs_applies || false,
        extrasKey,
        extrasLabel: extras.map((e) => e.option_name).join(', '),
        extrasArray: extras,
        note: note || undefined
      }];
    });
    const extrasLabel = extras.map((e) => e.option_name).join(', ');
    const noteLabel = note ? ` [Megj: ${note}]` : '';
    toast.success(`${product.name}${extrasLabel ? ` (${extrasLabel})` : ''}${noteLabel} hozzáadva`, { duration: 1200 });
  };

  const [configNote, setConfigNote] = useState('');

  const addToCart = (product: Product, qty = 1) => {
    // Mindig nyílik a modal, hogy a felhasználó tudjon tételszintű megjegyzést írni
    setConfigProduct(product);
    setSelectedExtras({});
    setConfigNote('');
  };

  const buildExtras = (): OrderItemExtra[] => {
    if (!configProduct) return [];
    const result: OrderItemExtra[] = [];
    for (const [groupId, optionIds] of Object.entries(selectedExtras)) {
      // Keresés a populated group_id objektumban is
      let grp: ToppingGroup | undefined = toppingGroups.find((g) => g._id === groupId);
      if (!grp) {
        const tgRef = (configProduct.topping_groups || []).find((tg) =>
          (typeof tg.group_id === 'object' ? (tg.group_id as ToppingGroup)._id : tg.group_id as string) === groupId
        );
        if (tgRef && typeof tgRef.group_id === 'object') grp = tgRef.group_id as ToppingGroup;
      }
      if (!grp) continue;
      for (const optId of optionIds) {
        const opt = grp.options.find((o) => o._id === optId);
        if (opt) result.push({ group_id: grp._id, group_name: grp.name, option_id: opt._id ?? '', option_name: opt.name, price: opt.price });
      }
    }
    return result;
  };

  const canConfirmConfig = (): boolean => {
    if (!configProduct) return false;
    for (const tg of (configProduct.topping_groups || [])) {
      const grp = typeof tg.group_id === 'object'
        ? tg.group_id as ToppingGroup
        : toppingGroups.find((g) => g._id === (tg.group_id as string));
      if (!grp) continue;
      if (tg.required) {
        const sel = selectedExtras[grp._id] || [];
        if (sel.length === 0) return false;
      }
    }
    return true;
  };



  const changeQty = (productId: string, delta: number, extrasKey?: string) => {
    setCart((prev) => prev.flatMap((i) => {
      if (i.product_id !== productId) return [i];
      if (extrasKey !== undefined && (i.extrasKey ?? '') !== extrasKey) return [i];
      const nq = i.quantity + delta;
      return nq <= 0 ? [] : [{ ...i, quantity: nq }];
    }));
  };

  const removeFromCart = (productId: string, extrasKey?: string) => {
    setCart((prev) => prev.filter((i) => {
      if (i.product_id !== productId) return true;
      if (extrasKey !== undefined && (i.extrasKey ?? '') !== extrasKey) return true;
      return false;
    }));
  };

  const reset = () => {
    setStep(0); setPhone(''); setGuestName(''); setFoundUser(null); setUserSearched(false);
    setDeliveryType('szállítás'); setCity(''); setStreet(''); setHouseNumber(''); setFloor(''); setDoor(''); setBell(''); setNotes('');
    setCart([]); setSelectedCategory(null); setSelectedProduct(null);
    setPaymentMethod('Készpénz'); setDiscountPct(0); setCouponCode(''); setAppliedCoupon(null);
  };

  const handleSubmit = async () => {
    setSubmitting(true);
    try {
      const itemsPayload = cart.map(item => ({
        product_id: item.product_id,
        name: item.name,
        quantity: item.quantity,
        price: item.price,
        packaging_fee: item.packaging_fee,
        drs_applies: item.drs_applies,
        extras: item.extrasArray || [],
        note: item.note
      }));

      if (existingOrderId) {
        // Update existing order (Table order modification)
        await orderApi.updateItems(existingOrderId, {
          items: itemsPayload,
          notes: notes.trim() || undefined,
          payment_method: paymentMethod,
          phone: phone.trim() || undefined,
          guest_name: guestName.trim() || undefined,
          delivery_type: deliveryType,
          address: deliveryType === 'elvitel' ? 'Elvitel' : deliveryType === 'beülős' ? 'Beülős' : fullAddress,
          city_id: selectedCity?._id ?? undefined,
          city_name: selectedCity?.name ?? city.trim(),
          street: street.trim() || undefined,
          house_number: houseNumber.trim() || undefined,
          floor: floor.trim() || undefined,
          door: door.trim() || undefined,
          bell: bell.trim() || undefined,
          coupon_code: appliedCoupon ? appliedCoupon.code : couponCode.trim() || undefined,
          coupon_name: appliedCoupon ? appliedCoupon.name : undefined,
          discount_pct: appliedCoupon ? appliedCoupon.discount_pct : undefined,
          source: 'pos'
        });
        toast.success('Rendelés sikeresen frissítve!');
        // Fejléces állapotfrissítéshez visszahívjuk null result-tal vagy újra lekérve
        // Ideálisan a CrmPosPanel szülőjének kell újra lekérnie a rendeléseket
        onOrderCreated({ _id: existingOrderId } as Order);
      } else {
        const res = await orderApi.create({
          items: itemsPayload,
          payment_method: paymentMethod,
          address: deliveryType === 'elvitel' ? 'Elvitel' : deliveryType === 'beülős' ? 'Beülős' : fullAddress,
          delivery_type: deliveryType,
          notes: notes.trim(),
          user_id_override: foundUser?.id ?? undefined,
          guest_name: guestName.trim() || undefined,
          phone: phone.trim() || undefined,
          city_id: selectedCity?._id ?? undefined,
          city_name: selectedCity?.name ?? city.trim(),
          street: street.trim() || undefined,
          house_number: houseNumber.trim() || undefined,
          floor: floor.trim() || undefined,
          door: door.trim() || undefined,
          bell: bell.trim() || undefined,
          discount_pct: effectiveDiscountPct,
          coupon_code: appliedCoupon?.code || undefined,
          coupon_name: appliedCoupon?.name || undefined,
          source: 'pos'
        });
        toast.success('Rendelés sikeresen rögzítve!');
        onOrderCreated(res.data);
      }
      reset();
    } catch (err: any) {
      toast.error(err.response?.data?.error || 'Rendelés rögzítése sikertelen');
    } finally {
      setSubmitting(false);
    }
  };

  // Szállítási validáció: város megadva + utca legalább 3 karakter + házszám
  const addressOk = isDineIn || deliveryType === 'elvitel' || (city.trim().length >= 2 && street.trim().length >= 3 && houseNumber.trim().length > 0);
  const canProceedToCart = true; // Vásárlói adatok opcionálisak
  // KOSÁR → FIZETÉS: csak kosár + minimum összeg szükséges (cím ellenőrzés leadáskor)
  const canProceedToPayment = cart.length > 0;
  // Leadásnál teljes validáció
  const canSubmit = canProceedToPayment && addressOk;

  // ─────────────────────────────────────────────────────────────────
  // Termék kártya (Kosár lépésnél)
  // ─────────────────────────────────────────────────────────────────
  const ProductCard = ({ product, onAdd, onDetail }: {
    product: Product;
    onAdd: (p: Product) => void;
    onDetail: (p: Product) => void;
  }) => (
    <button
      className="flex flex-col bg-muted/50 border border-border rounded-lg hover:border-primary hover:shadow-lg transition-all text-left group overflow-hidden"
      onClick={() => onAdd(product)}
    >
      {product.image && (
        <div className="w-full aspect-video overflow-hidden border-b border-border">
          <img src={product.image} alt={product.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
        </div>
      )}
      <div className="p-3 flex-1 min-w-0 w-full bg-card">
        <p className="text-foreground text-sm font-semibold leading-tight truncate group-hover:text-primary transition-colors">{product.name}</p>
        <p className="text-primary text-sm font-black mt-1">{product.price.toLocaleString()} Ft</p>
      </div>
    </button>
  );

  // ─────────────────────────────────────────────────────────────────
  // Jobb oldali kosár panel (mindig látható a 2. és 3. lépésnél)
  // ─────────────────────────────────────────────────────────────────
  const CartPanel = () => (
    <div className="flex flex-col h-full bg-muted/30 border-l border-border min-h-0">
      <div className="px-4 pt-4 pb-3 border-b border-border bg-card">
        <div className="flex items-center justify-between">
          <h3 className="text-foreground font-semibold text-sm">Kosár</h3>
          {cartCount > 0 && (
            <button onClick={() => setCart([])} className="text-muted-foreground hover:text-destructive transition-colors">
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
        <p className="text-muted-foreground text-xs mt-0.5">Eddig rendelések száma: {cart.length}</p>
      </div>

      {/* Tételek */}
      <div className="flex-1 overflow-y-auto px-4 py-2 min-h-0 space-y-2">
        {cart.length === 0 ? (
          <p className="text-muted-foreground text-xs text-center py-6">Nincsenek megjelenítendő elemek</p>
        ) : (
          cart.map((item) => (
            <div key={item.product_id + (item.extrasKey ?? '')} className="group py-1">
              <div className="flex items-start gap-2">
                <div className="flex-1 min-w-0">
                  <p className="text-foreground text-xs font-medium leading-tight truncate">{item.name}</p>
                  {item.extrasLabel && <p className="text-primary/70 text-xs truncate">{item.extrasLabel}</p>}
                  {item.note && <p className="text-primary text-xs italic truncate">Megj: {item.note}</p>}
                  <p className="text-muted-foreground text-xs">{item.price.toLocaleString()} Ft</p>
                </div>
                <div className="flex items-center gap-1 shrink-0">
                  <button
                    onClick={() => changeQty(item.product_id, -1, item.extrasKey)}
                    className="w-5 h-5 rounded border border-border bg-muted hover:bg-primary/10 hover:border-primary/50 text-foreground flex items-center justify-center transition-colors"
                  >
                    <Minus className="w-2.5 h-2.5" />
                  </button>
                  <span className="text-foreground text-xs w-4 text-center font-bold">{item.quantity}</span>
                  <button
                    onClick={() => changeQty(item.product_id, 1, item.extrasKey)}
                    className="w-5 h-5 rounded border border-border bg-muted hover:bg-primary/10 hover:border-primary/50 text-foreground flex items-center justify-center transition-colors"
                  >
                    <Plus className="w-2.5 h-2.5" />
                  </button>
                  <button
                    onClick={() => removeFromCart(item.product_id, item.extrasKey)}
                    className="w-5 h-5 rounded text-muted-foreground hover:text-destructive flex items-center justify-center ml-0.5 transition-colors"
                  >
                    <X className="w-2.5 h-2.5" />
                  </button>
                </div>
              </div>
              <p className="text-right text-primary text-xs font-semibold">
                {(item.price * item.quantity).toLocaleString()} Ft
              </p>
            </div>
          ))
        )}
      </div>

      {/* Végösszeg */}
      <div className="border-t border-border bg-card px-4 py-3">
        {cart.length > 0 && (
          <div className="space-y-1 mb-2">
            {packagingTotal > 0 && (
              <div className="flex justify-between text-muted-foreground text-xs">
                <span>Csomagolás</span><span>{packagingTotal.toLocaleString()} Ft</span>
              </div>
            )}
            {drsTotal > 0 && (
              <div className="flex justify-between text-muted-foreground text-xs">
                <span>DRS</span><span>{drsTotal.toLocaleString()} Ft</span>
              </div>
            )}
            {deliveryType === 'szállítás' && (
              <div className="flex justify-between text-muted-foreground text-xs">
                <span>Szállítás</span>
                <span className={deliveryFee === 0 ? 'text-green-600' : ''}>
                  {deliveryFee === 0 ? 'Ingyenes' : `${deliveryFee.toLocaleString()} Ft`}
                </span>
              </div>
            )}
          </div>
        )}
        <div className="flex items-center gap-1">
          <Info className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
          <span className="text-muted-foreground text-sm">Végösszeg</span>
          <span className="ml-auto text-foreground font-bold text-lg">{total.toLocaleString()} Ft</span>
        </div>
      </div>
    </div>
  );

  // ─────────────────────────────────────────────────────────────────
  // Breadcrumb fejléc
  // ─────────────────────────────────────────────────────────────────
  const steps = ['VÁSÁRLÓ', 'KOSÁR', 'FIZETÉS'];
  const PINK = '#b5255e';

  const Header = () => (
    <div className="flex items-stretch min-h-[52px] border-b border-border shrink-0" style={{ background: '#fff' }}>
      {/* Adatok ürítése – pink blokk */}
      <button
        onClick={reset}
        className="flex items-center gap-2 px-4 text-sm font-medium transition-colors shrink-0"
        style={{ background: PINK, color: '#fff' }}
      >
        <Trash2 className="w-3.5 h-3.5" /> Adatok ürítése
      </button>

      {/* Breadcrumb */}
      <div className="flex items-center gap-1 flex-1 justify-center px-4">
        {steps.map((s, i) => (
          <div key={s} className="flex items-center gap-1">
            <button
              onClick={() => { if (i < step) setStep(i as Step); }}
              className="text-xs font-semibold px-3 py-4 transition-colors border-b-2"
              style={{
                color: i === step ? PINK : i < step ? '#666' : '#bbb',
                borderBottomColor: i === step ? PINK : 'transparent',
                cursor: i < step ? 'pointer' : i === step ? 'default' : 'default',
              }}
            >
              {s}
            </button>
            {i < 2 && <span className="text-xs" style={{ color: 'hsl(var(--muted-foreground))' }}>›</span>}
          </div>
        ))}
      </div>

      {/* Tovább / Leadás gomb */}
      {step === 0 && (
        <button
          className="flex items-center gap-1.5 px-6 text-sm font-semibold shrink-0 transition-colors bg-primary text-primary-foreground hover:bg-primary/90"
          onClick={() => setStep(1)}
        >
          Tovább <ArrowRight className="w-4 h-4" />
        </button>
      )}
      {step === 1 && (
        <button
          className={`flex items-center gap-1.5 px-6 text-sm font-semibold shrink-0 transition-colors ${canProceedToPayment ? 'bg-primary text-primary-foreground hover:bg-primary/90' : 'bg-muted text-muted-foreground cursor-not-allowed'}`}
          disabled={!canProceedToPayment}
          onClick={() => canProceedToPayment && setStep(2)}
        >
          Tovább <ArrowRight className="w-4 h-4" />
        </button>
      )}
      {step === 2 && (
        <button
          className={`flex items-center gap-1.5 px-6 text-sm font-semibold shrink-0 transition-colors ${canSubmit && !submitting ? 'bg-green-600 text-white hover:bg-green-700' : 'bg-muted text-muted-foreground cursor-not-allowed'}`}
          disabled={!canSubmit || submitting}
          onClick={handleSubmit}
        >
          {submitting ? 'Rögzítés...' : <>Leadás <ArrowRight className="w-4 h-4" /></>}
        </button>
      )}
    </div>
  );

  // ─────────────────────────────────────────────────────────────────
  // 1. LÉPÉS: Vásárló adatok
  // ─────────────────────────────────────────────────────────────────
  if (step === 0) {
    return (
      <div className="flex flex-col overflow-hidden h-full bg-background">
        <Header />
        <div className="flex-1 overflow-y-auto p-4 space-y-3 max-w-2xl mx-auto w-full">

          {/* Vásárló szekció */}
          <div className="bg-muted/50 rounded shadow-sm overflow-hidden border border-border">
            <div className="px-5 py-3 border-b border-border">
              <h3 className="text-foreground font-semibold text-base">Vásárló</h3>
            </div>
            <div className="px-5 py-4 grid grid-cols-3 gap-3">
              {/* Telefonos */}
              <div ref={phoneInputRef}>
                <label className="text-xs text-muted-foreground block mb-1">Telefonos</label>
                <div className="flex items-center border border-border bg-card rounded h-9 focus-within:border-primary focus-within:ring-1 focus-within:ring-primary/20 transition-all">
                  <input
                    value={phone}
                    onChange={(e) => { setPhone(e.target.value); setUserSearched(false); setFoundUser(null); setShowSuggestions(true); }}
                    onKeyDown={(e) => e.key === 'Enter' && searchUser()}
                    placeholder="Minimum 3 karakter a kereséshez ..."
                    className="flex-1 min-w-0 px-2 py-1 text-sm bg-transparent outline-none text-foreground placeholder:text-muted-foreground"
                  />
                  {phone && (
                    <button onClick={() => { setPhone(''); setFoundUser(null); setUserSearched(false); setPhoneSuggestions([]); setShowSuggestions(false); }} className="px-1.5 text-muted-foreground hover:text-foreground">
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
                {/* Autocomplete dropdown */}
                {showSuggestions && phoneSuggestions.length > 0 && (
                  <div className="bg-card border border-border rounded shadow-lg mt-1 max-h-60 overflow-y-auto" style={{ position: 'relative', zIndex: 50 }}>
                    {phoneSuggestions.map((s, idx) => (
                      <button
                        key={idx}
                        className="w-full text-left px-3 py-2 hover:bg-muted border-b border-border last:border-b-0 text-sm"
                        onClick={() => {
                          setPhone(s.phone);
                          setGuestName(s.name || '');
                          setFoundUser({
                            ...s,
                            id: s.id,
                            source: s.source,
                            role: 'guest',
                            email: '',
                            default_address: s.address,
                          } as any);
                          setUserSearched(true);
                          setShowSuggestions(false);
                          setPhoneSuggestions([]);
                          setCity(s.city_name || '');
                          setStreet(s.street || '');
                          setHouseNumber(s.house_number || '');
                          setFloor(s.floor || '');
                          setDoor(s.door || '');
                          setBell(s.bell || '');
                        }}
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-medium truncate">{s.name || 'Ismeretlen'}</span>
                          <span className="text-xs text-muted-foreground ml-2 shrink-0">{s.phone}</span>
                        </div>
                        <div className="text-xs text-muted-foreground truncate mt-0.5">
                          {s.city_name}{s.city_name && s.street ? ', ' : ''}{s.street}{s.house_number ? ` ${s.house_number}` : ''}
                        </div>
                      </button>
                    ))}
                  </div>
                )}
              </div>
              {deliveryType === 'szállítás' && (
                <>
                  {/* Vezetéknév */}
                  <div>
                    <label className="text-xs text-muted-foreground block mb-1">Vezetéknév</label>
                    <div className="flex items-center border border-border bg-card rounded h-9 focus-within:border-primary focus-within:ring-1 focus-within:ring-primary/20 transition-all">
                      <input
                        value={guestName.split(' ')[0] ?? ''}
                        onChange={(e) => setGuestName(e.target.value + ' ' + (guestName.split(' ').slice(1).join(' ') || ''))}
                        className="flex-1 min-w-0 px-2 py-1 text-sm bg-transparent outline-none text-foreground"
                      />
                      {guestName && (
                        <button onClick={() => setGuestName('')} className="px-1.5 text-muted-foreground hover:text-foreground">
                          <X className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                  {/* Keresztnév */}
                  <div>
                    <label className="text-xs text-muted-foreground block mb-1">Keresztnév</label>
                    <div className="flex items-center border border-border bg-card rounded h-9 focus-within:border-primary focus-within:ring-1 focus-within:ring-primary/20 transition-all">
                      <input
                        value={guestName.split(' ').slice(1).join(' ') ?? ''}
                        onChange={(e) => setGuestName((guestName.split(' ')[0] ?? '') + ' ' + e.target.value)}
                        className="flex-1 min-w-0 px-2 py-1 text-sm bg-transparent outline-none text-foreground"
                      />
                      {guestName && (
                        <button onClick={() => setGuestName('')} className="px-1.5 text-muted-foreground hover:text-foreground">
                          <X className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                </>
              )}
            </div>
            {/* Visszatérő ügyfél info */}
            {userSearched && foundUser && (
              <div className="px-5 pb-4">
                <div className={`flex items-start gap-2 p-3 rounded border text-sm ${(foundUser as any).source === 'registered' ? 'bg-green-500/10 border-green-500/30 text-green-600 dark:bg-green-950/30 dark:border-green-900/50 dark:text-green-400' : 'bg-blue-500/10 border-blue-500/30 text-blue-600 dark:bg-blue-950/30 dark:border-blue-900/50 dark:text-blue-400'}`}>
                  <CheckCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <div className="min-w-0">
                    <p className="font-semibold truncate">{foundUser.name || 'Ismeretlen'}</p>
                    {(foundUser as any).source === 'order_history' && (
                      <p className="text-xs opacity-80">Visszatérő vendég · {(foundUser as any).order_count} korábbi rendelés</p>
                    )}
                    {(foundUser as any).city_name && (
                      <p className="text-xs opacity-80 truncate">
                        {(foundUser as any).city_name}{(foundUser as any).street ? `, ${(foundUser as any).street}` : ''}{(foundUser as any).house_number ? ` ${(foundUser as any).house_number}` : ''}
                      </p>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Cím szekció */}
          <div className="bg-muted/50 rounded shadow-sm overflow-hidden border border-border">
            <div className="px-5 py-3 border-b border-border">
              <h3 className="text-foreground font-semibold text-base">Cím</h3>
            </div>
            <div className="px-5 py-4 space-y-4">
              
              {/* Rendeléstípus választó */}
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setDeliveryType('szállítás')}
                  className={`flex items-center justify-center gap-2 py-2.5 rounded border-2 text-sm font-medium transition-colors ${deliveryType === 'szállítás' ? 'border-primary bg-primary/10 text-primary shadow-[0_0_8px_rgba(225,29,72,0.15)] dark:shadow-none' : 'border-border bg-card text-muted-foreground hover:border-primary/40 hover:shadow-[0_2px_8px_rgba(225,29,72,0.05)] dark:hover:shadow-none'}`}
                >
                  <Truck className="w-4 h-4" /> Szállítás
                </button>
                <button
                  type="button"
                  onClick={() => setDeliveryType('elvitel')}
                  className={`flex items-center justify-center gap-2 py-2.5 rounded border-2 text-sm font-medium transition-colors ${deliveryType === 'elvitel' ? 'border-primary bg-primary/10 text-primary shadow-[0_0_8px_rgba(225,29,72,0.15)] dark:shadow-none' : 'border-border bg-card text-muted-foreground hover:border-primary/40 hover:shadow-[0_2px_8px_rgba(225,29,72,0.05)] dark:hover:shadow-none'}`}
                >
                  <Package className="w-4 h-4" /> Elvitel
                </button>
                <button
                  type="button"
                  onClick={() => setDeliveryType('beülős')}
                  className={`flex items-center justify-center gap-2 py-2.5 rounded border-2 text-sm font-medium transition-colors ${deliveryType === 'beülős' ? 'border-emerald-500 bg-emerald-500/10 text-emerald-600 shadow-[0_0_8px_rgba(16,185,129,0.15)] dark:shadow-none' : 'border-border bg-card text-muted-foreground hover:border-emerald-500/40 hover:shadow-[0_2px_8px_rgba(16,185,129,0.05)] dark:hover:shadow-none'}`}
                >
                  <UtensilsCrossed className="w-4 h-4" /> Beülős
                </button>
              </div>

              {deliveryType === 'szállítás' && (
                <>
                  {/* Város + Utca sor */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <div className="flex items-center gap-1 mb-1">
                    <Info className="w-3 h-3 text-primary" />
                    <label className="text-xs text-muted-foreground">Város *</label>
                  </div>
                  <div className="flex items-center border border-border bg-card rounded h-9 focus-within:border-primary focus-within:ring-1 focus-within:ring-primary/20 transition-all">
                    <input
                      list="cities-list"
                      value={city}
                      onChange={(e) => setCity(e.target.value)}
                      placeholder="Írd be a várost..."
                      className="flex-1 min-w-0 px-2 py-1 text-sm bg-transparent outline-none text-foreground"
                    />
                    <datalist id="cities-list">
                      {cities.map((c) => (
                        <option key={c._id} value={c.name} />
                      ))}
                    </datalist>
                    <span className="px-2 text-muted-foreground text-xs border-l border-border shrink-0">
                      {selectedCity ? `+${selectedCity.delivery_fee.toLocaleString()} Ft` : '—'}
                    </span>
                  </div>
                </div>
                <div>
                  <div className="flex items-center gap-1 mb-1">
                    <label className="text-xs text-muted-foreground">Utca *</label>
                  </div>
                  <div className="flex items-center border border-border bg-card rounded h-9 focus-within:border-primary focus-within:ring-1 focus-within:ring-primary/20 transition-all">
                    <input
                      value={street}
                      onChange={(e) => setStreet(e.target.value)}
                      placeholder="Utca, út, tér..."
                      className="flex-1 min-w-0 px-2 py-1 text-sm bg-transparent outline-none text-foreground"
                    />
                    {street && (
                      <button onClick={() => setStreet('')} className="px-1.5 text-muted-foreground hover:text-foreground">
                        <X className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
              {/* Házszám, Emelet, Ajtó, Csengő */}
              <div className="grid grid-cols-4 gap-3">
                {[
                  { label: 'Házszám *', val: houseNumber, set: setHouseNumber },
                  { label: 'Emelet', val: floor, set: setFloor },
                  { label: 'Ajtó', val: door, set: setDoor },
                  { label: 'Csengő', val: bell, set: setBell },
                ].map((f) => (
                  <div key={f.label}>
                    <label className="text-xs text-muted-foreground block mb-1">{f.label}</label>
                    <div className="flex items-center border border-border bg-card rounded h-9 focus-within:border-primary focus-within:ring-1 focus-within:ring-primary/20 transition-all">
                      <input
                        value={f.val}
                        onChange={(e) => f.set(e.target.value)}
                        className="flex-1 min-w-0 px-2 py-1 text-sm bg-transparent outline-none text-foreground"
                      />
                      {f.val && (
                        <button onClick={() => f.set('')} className="px-1.5 text-muted-foreground hover:text-foreground shrink-0">
                          <X className="w-3 h-3" />
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
              {/* Cím megjegyzés */}
              <div>
                <label className="text-xs text-muted-foreground block mb-1">Cím megjegyzés</label>
                <div className="flex items-start border border-border bg-card rounded focus-within:border-primary focus-within:ring-1 focus-within:ring-primary/20 transition-all">
                  <textarea
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    rows={2}
                    className="flex-1 min-w-0 px-2 py-1.5 text-sm bg-transparent outline-none text-foreground resize-none"
                  />
                  {notes && (
                    <button onClick={() => setNotes('')} className="px-1.5 pt-1.5 text-muted-foreground hover:text-foreground shrink-0">
                      <X className="w-3 h-3" />
                    </button>
                  )}
                </div>
              </div>
              {/* Összeállított cím preview */}
              {fullAddress && (
                <p className="text-xs text-muted-foreground">{fullAddress}</p>
              )}
              {/* Szállítási díj info */}
              {deliveryType === 'szállítás' && selectedCity && (
                <div className="flex items-center gap-4 p-2 bg-green-500/10 border border-green-500/30 rounded text-xs text-green-600 dark:bg-green-950/30 dark:border-green-900/50 dark:text-green-400">
                  <CheckCircle className="w-3.5 h-3.5 shrink-0" />
                  <span>{selectedCity.name}</span>
                  <span>{deliveryFee === 0 ? `Ingyenes szállítás${cityThreshold > 0 && selectedCity.delivery_fee > 0 ? ' (küszöb alapján)' : ''}` : `${selectedCity.delivery_fee.toLocaleString()} Ft szállítás`}</span>
                </div>
              )}
                </>
              )}
            </div>
          </div>

          {/* Általános rendelés megjegyzés szekció (ha nem szállítás) */}
          {deliveryType !== 'szállítás' && (
          <div className="bg-muted/50 rounded shadow-sm overflow-hidden border border-border">
            <div className="px-5 py-3 border-b border-border">
              <h3 className="text-foreground font-semibold text-base">Rendelés megjegyzés</h3>
            </div>
            <div className="px-5 py-4">
              <div className="flex items-start border border-border bg-card rounded">
                <textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  rows={2}
                  className="flex-1 min-w-0 px-2 py-1.5 text-sm bg-transparent outline-none text-foreground resize-none placeholder:text-muted-foreground"
                  placeholder="Általános megjegyzés a rendeléshez..."
                />
              </div>
            </div>
          </div>
          )}

        </div>
      </div>
    );
  }

  // ─────────────────────────────────────────────────────────────────
  // 2. LÉPÉS: Kosár — Kategória / Termékek
  // ─────────────────────────────────────────────────────────────────
  if (step === 1) {
    // Elérhető kategóriák (csak amelyikhez van aktív termék)
    const availableCategories = categories.filter((cat) =>
      products.some((p) => p.category === cat && p.is_available !== false)
    );
    const finalCategories = availableCategories.length > 0
      ? availableCategories
      : [...new Set(products.map((p) => p.category))].filter(Boolean);

    const catProducts = selectedCategory
      ? products.filter((p) => p.category === selectedCategory && p.is_available !== false)
      : [];

    const searchVal = searchRef.current?.value?.toLowerCase() ?? '';

    return (
      <>
      <div className="flex flex-col overflow-hidden h-full bg-background">
        <Header />

        {/* Termék detail modal */}
        {selectedProduct && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60">
            <div className="bg-card border border-border rounded-lg p-6 max-w-sm w-full shadow-2xl">
              {selectedProduct.image && (
                <img src={selectedProduct.image} alt={selectedProduct.name} className="w-full h-40 object-cover rounded mb-4" />
              )}
              <h3 className="text-foreground font-bold text-xl mb-1 text-balance">{selectedProduct.name}</h3>
              {selectedProduct.description && (
                <p className="text-muted-foreground text-sm mb-3 text-pretty">{selectedProduct.description}</p>
              )}
              <p className="text-primary font-bold text-2xl mb-5">{selectedProduct.price.toLocaleString()} Ft</p>
              <div className="flex gap-3">
                <Button variant="outline" className="flex-1 border-border" onClick={() => setSelectedProduct(null)}>
                  <ArrowLeft className="w-4 h-4 mr-1.5" /> Vissza
                </Button>
                <Button className="flex-1 btn-primary-gradient text-primary-foreground font-bold"
                  onClick={() => { addToCart(selectedProduct); setSelectedProduct(null); }}>
                  <Plus className="w-4 h-4 mr-1.5" /> Kosárba
                </Button>
              </div>
            </div>
          </div>
        )}

        <div className="flex flex-1 min-h-0 overflow-hidden" style={{ height: 'calc(100vh - 182px)', minHeight: 480 }}>
          {/* Bal oldal: Termékterület */}
          <div className="flex-1 min-w-0 overflow-y-auto p-3">
            {/* Keresősáv */}
            <div className="mb-3 flex items-center gap-2 bg-card border border-border rounded h-9 px-3">
              <Search className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
              <input
                ref={searchRef}
                placeholder="Termék keresése..."
                className="flex-1 min-w-0 text-sm bg-transparent outline-none text-foreground placeholder:text-muted-foreground"
                onChange={() => setSearchTick((t) => t + 1)}
              />
              {selectedCategory && (
                <button onClick={() => setSelectedCategory(null)} className="text-primary hover:text-primary/80 text-xs shrink-0 flex items-center gap-1 transition-colors">
                  <ArrowLeft className="w-3 h-3" /> Vissza
                </button>
              )}
            </div>

            {/* Tartalom */}
            {(() => {
              const sv = searchRef.current?.value?.toLowerCase() ?? '';
              if (sv.length > 0) {
                const filtered = products.filter((p) =>
                  p.is_available !== false && p.name.toLowerCase().includes(sv)
                );
                return (
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                    {filtered.map((p) => (
                      <ProductCard key={p._id} product={p} onAdd={addToCart} onDetail={setSelectedProduct} />
                    ))}
                    {filtered.length === 0 && (
                      <p className="text-muted-foreground text-sm col-span-full text-center py-8">Nincs találat</p>
                    )}
                  </div>
                );
              }
              if (!selectedCategory) {
                return (
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                    {finalCategories.map((cat) => (
                      <button
                        key={cat}
                        onClick={() => setSelectedCategory(cat)}
                        className="flex items-center justify-between px-3 py-4 bg-muted/50 border border-border hover:border-primary/50 hover:bg-card rounded-lg text-left group transition-all"
                      >
                        <span className="text-foreground text-sm font-medium group-hover:text-primary transition-colors truncate pr-1">{cat}</span>
                        <ChevronRight className="w-4 h-4 text-muted-foreground group-hover:text-primary shrink-0 transition-colors transform group-hover:translate-x-1" />
                      </button>
                    ))}
                    {finalCategories.length === 0 && (
                      <p className="text-muted-foreground text-sm col-span-full text-center py-8">Nincsenek kategóriák</p>
                    )}
                  </div>
                );
              }
              return (
                <div>
                  <h3 className="text-foreground font-bold text-sm mb-2">{selectedCategory}</h3>
                  {catProducts.length === 0 ? (
                    <p className="text-muted-foreground text-sm text-center py-8">Nincs elérhető termék</p>
                  ) : (
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                      {catProducts.map((p) => (
                        <ProductCard key={p._id} product={p} onAdd={addToCart} onDetail={setSelectedProduct} />
                      ))}
                    </div>
                  )}
                </div>
              );
            })()}
          </div>

          {/* Jobb oldal: Kosár */}
          <div className="w-64 shrink-0 flex flex-col min-h-0 hidden md:flex">
            <CartPanel />
          </div>
        </div>

        {/* Mobil: kosár sáv alul */}
        {cart.length > 0 && (
          <div className="md:hidden border-t border-border bg-card px-4 py-3 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ShoppingCart className="w-4 h-4 text-primary" />
              <span className="text-foreground font-bold">{cartCount} tétel</span>
            </div>
            <span className="text-primary font-bold text-lg">{total.toLocaleString()} Ft</span>
          </div>
        )}
      </div>

      {/* ── Öntet konfiguráló modal ─────────────────────────────────────── */}
      {configProduct && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/60" onClick={() => { setConfigProduct(null); setSelectedExtras({}); }}>
          <div
            className="bg-card rounded-lg p-5 max-w-sm w-full shadow-2xl max-h-[90dvh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-2 mb-4">
              <ChefHat className="w-5 h-5 text-primary" />
              <h3 className="text-foreground font-bold text-lg text-balance">{configProduct.name}</h3>
            </div>
            {configProduct.image && (
              <div className="h-36 rounded overflow-hidden mb-4">
                <img src={configProduct.image} alt={configProduct.name} className="w-full h-full object-cover" />
              </div>
            )}
            <p className="text-primary font-bold text-xl mb-4">{configProduct.price.toLocaleString()} Ft</p>
            <div className="space-y-4 mb-5">
              {(configProduct.topping_groups || []).map((tgRef) => {
                const grp = typeof tgRef.group_id === 'object'
                  ? tgRef.group_id as ToppingGroup
                  : toppingGroups.find((g) => g._id === (tgRef.group_id as string));
                if (!grp) return null;
                const sel = selectedExtras[grp._id] || [];
                const maxSel = tgRef.max_select ?? grp.max_select ?? 1;
                const isRequired = tgRef.required ?? grp.required ?? false;
                const isSingle = maxSel === 1;
                return (
                  <div key={grp._id} className="space-y-2">
                    <div className="flex items-center gap-2">
                      <h4 className="text-foreground font-semibold text-sm">{grp.name}</h4>
                      {isRequired
                        ? <span className="text-xs px-1.5 py-0.5 rounded bg-red-950/40 text-red-400 border border-red-900/50">Kötelező</span>
                        : <span className="text-xs px-1.5 py-0.5 rounded bg-muted text-muted-foreground">Opcionális</span>
                      }
                      {!isSingle && <span className="text-xs text-muted-foreground">max {maxSel} db</span>}
                    </div>
                    {!isSingle && (
                      <p className={`text-xs mb-1 ${sel.length >= maxSel ? 'text-primary font-medium' : 'text-muted-foreground'}`}>
                        {sel.length}/{maxSel} kiválasztva{sel.length >= maxSel ? ' — maximum elérve' : ''}
                      </p>
                    )}
                    <div className="space-y-1.5">
                      {grp.options.map((opt, optIdx) => {
                        const isSelected = sel.includes(opt._id ?? '');
                        const maxReached = !isSingle && sel.length >= maxSel && !isSelected;
                        return (
                          <button
                            key={opt._id ?? optIdx}
                            disabled={maxReached}
                            className={`w-full flex items-center justify-between px-3 py-2.5 rounded border transition-colors text-left ${
                              isSelected ? 'border-primary bg-primary/10 shadow-[0_0_8px_rgba(225,29,72,0.15)] dark:shadow-none'
                              : maxReached ? 'border-border bg-muted opacity-40 cursor-not-allowed'
                              : 'border-border bg-card hover:border-primary/50 hover:bg-muted/30 hover:shadow-[0_2px_8px_rgba(225,29,72,0.05)] dark:hover:shadow-none'
                            }`}
                            onClick={() => {
                              if (maxReached) return;
                              setSelectedExtras((prev) => {
                                const current = prev[grp._id] || [];
                                if (isSingle) {
                                  return { ...prev, [grp._id]: isSelected ? [] : [opt._id ?? ''] };
                                } else {
                                  if (isSelected) return { ...prev, [grp._id]: current.filter((id) => id !== (opt._id ?? '')) };
                                  if (current.length < maxSel) return { ...prev, [grp._id]: [...current, opt._id ?? ''] };
                                  return prev;
                                }
                              });
                            }}
                          >
                            <div className="flex items-center gap-2.5">
                              <div className={`w-4 h-4 rounded-${isSingle ? 'full' : 'sm'} border-2 flex items-center justify-center shrink-0 ${
                                isSelected ? 'border-primary bg-primary' : 'border-border'
                              }`}>
                                {isSelected && <Check className="w-2.5 h-2.5 text-primary-foreground" />}
                              </div>
                              <span className="text-sm text-foreground">{opt.name}</span>
                            </div>
                            <span className={`text-sm shrink-0 ${opt.price > 0 ? 'text-primary' : 'text-muted-foreground'}`}>
                              {opt.price > 0 ? `+${opt.price.toLocaleString('hu-HU')} Ft` : 'Ingyenes'}
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
            
            <div className="mb-4">
              <p className="text-sm font-bold text-foreground mb-2">Tételszintű megjegyzés <span className="text-muted-foreground font-normal text-xs">(opcionális)</span></p>
              <textarea
                className="w-full h-20 p-3 rounded-lg border border-border bg-muted text-sm focus:outline-none focus:border-primary resize-none"
                placeholder="Pl.: Hagyma nélkül, kevésbé csípősen..."
                value={configNote}
                onChange={(e) => setConfigNote(e.target.value)}
              />
            </div>
            
            <div className="flex gap-3">
              <Button variant="outline" className="flex-1 border-border" onClick={() => { setConfigProduct(null); setSelectedExtras({}); setConfigNote(''); }}>
                <ArrowLeft className="w-4 h-4 mr-1.5" /> Mégse
              </Button>
              <Button
                className="flex-1 btn-primary-gradient text-primary-foreground font-bold"
                disabled={!canConfirmConfig()}
                onClick={() => {
                  const extras = buildExtras();
                  addToCartDirect(configProduct, extras, 1, configNote);
                  setConfigProduct(null);
                  setSelectedExtras({});
                  setConfigNote('');
                }}
              >
                <ShoppingCart className="w-4 h-4 mr-1.5" /> Kosárba
                {buildExtras().reduce((s, e) => s + e.price, 0) > 0 && (
                  <span className="ml-1 text-primary-foreground/80 text-sm font-normal">
                    (+{buildExtras().reduce((s, e) => s + e.price, 0).toLocaleString()} Ft)
                  </span>
                )}
              </Button>
            </div>
          </div>
        </div>
      )}
      </>
    );
  }

  // ─────────────────────────────────────────────────────────────────
  // 3. LÉPÉS: Fizetés
  // ─────────────────────────────────────────────────────────────────
  return (
    <>
    <div className="flex flex-col overflow-hidden h-full bg-background">
      <Header />
      <div className="flex flex-col md:flex-row flex-1 min-h-0 overflow-hidden">
        {/* Bal: Fizetési adatok */}
        <div className="flex-1 min-w-0 overflow-y-auto p-3 space-y-3">

          {/* Fizetési mód szekció */}
          <div className="bg-muted/50 rounded shadow-sm overflow-hidden border border-border">
            <div className="flex items-center justify-between px-5 py-3 border-b border-border">
              <h3 className="text-foreground font-semibold text-base">Fizetési mód</h3>
              <div className="flex items-center gap-1 border border-primary rounded px-2 py-0.5 shadow-[0_0_8px_rgba(225,29,72,0.15)] dark:shadow-none">
                <span className="text-primary text-xs font-medium">Nyugta</span>
              </div>
            </div>
            <div className="px-5 py-4">
              <div className="grid grid-cols-2 gap-2">
                {(['Készpénz', 'Bankkártya'] as const).map((m) => {
                  const isSelected = paymentMethod === m;
                  return (
                    <button key={m} onClick={() => setPaymentMethod(m)}
                      className={`flex items-center gap-1.5 px-3 py-3 rounded text-left text-sm transition-colors border ${isSelected ? 'border-primary bg-primary/10 text-foreground shadow-[0_0_8px_rgba(225,29,72,0.15)] dark:shadow-none' : 'border-border bg-card text-muted-foreground hover:border-primary/50 hover:shadow-[0_2px_8px_rgba(225,29,72,0.05)] dark:hover:shadow-none'}`}
                      style={{ fontWeight: isSelected ? 600 : 400 }}>
                      {isSelected && <CheckCircle className="w-3.5 h-3.5 shrink-0 text-primary" />}
                      {m}
                    </button>
                  );
                })}
              </div>
              <div className="grid grid-cols-2 gap-3 mt-4">
                <div>
                  <label className="text-xs text-muted-foreground block mb-1">Kedvezmény %</label>
                  <div className="flex items-center border border-border bg-card rounded h-9 focus-within:border-primary focus-within:ring-1 focus-within:ring-primary/20 transition-all">
                    <input
                      type="number"
                      min={0}
                      max={100}
                      value={discountPct || ''}
                      onChange={(e) => { setDiscountPct(Number(e.target.value)); clearCoupon(); }}
                      disabled={!!appliedCoupon}
                      className="flex-1 min-w-0 px-2 text-sm bg-transparent outline-none text-foreground placeholder-muted-foreground"
                    />
                    {discountPct > 0 && !appliedCoupon && (
                      <button onClick={() => setDiscountPct(0)} className="px-1.5 text-muted-foreground hover:text-foreground"><X className="w-3 h-3" /></button>
                    )}
                    <span className="border-l border-border px-1.5 text-muted-foreground text-xs">%</span>
                  </div>
                </div>
                <div>
                  <label className="text-xs text-muted-foreground block mb-1">Kedvezmény összessége</label>
                  <div className="flex items-center border border-border bg-card rounded h-9 focus-within:border-primary focus-within:ring-1 focus-within:ring-primary/20 transition-all">
                    <input
                      readOnly
                      value={discountAmount.toLocaleString()}
                      className="flex-1 min-w-0 px-2 text-sm bg-transparent outline-none text-foreground"
                    />
                    <span className="px-2 text-muted-foreground text-xs border-l border-border">Ft</span>
                  </div>
                </div>
              </div>
              <div className="mt-3">
                <label className="text-xs text-muted-foreground block mb-1">Kuponkód</label>
                <div className="flex gap-2">
                  <div className="flex-1 border border-border bg-card rounded h-9 flex items-center px-2 focus-within:border-primary focus-within:ring-1 focus-within:ring-primary/20 transition-all">
                    <input
                      value={couponCode}
                      onChange={(e) => setCouponCode(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && applyCoupon()}
                      disabled={!!appliedCoupon}
                      className="flex-1 min-w-0 text-sm bg-transparent outline-none text-foreground placeholder-muted-foreground"
                    />
                    {couponCode && !appliedCoupon && (
                      <button onClick={() => setCouponCode('')} className="px-1.5 text-muted-foreground hover:text-foreground"><X className="w-3 h-3" /></button>
                    )}
                  </div>
                  {!appliedCoupon ? (
                    <button
                      onClick={applyCoupon}
                      disabled={couponLoading || !couponCode.trim()}
                      className="flex items-center gap-1.5 px-4 py-2 bg-card text-foreground border border-border rounded text-sm font-medium hover:border-primary/50 hover:bg-muted/30 transition-colors shrink-0 disabled:opacity-50 hover:shadow-[0_2px_8px_rgba(225,29,72,0.05)] dark:hover:shadow-none"
                    >
                      {couponLoading ? '...' : 'Kupon alkalmazása'} <span className="text-xs">▾</span>
                    </button>
                  ) : (
                    <button
                      onClick={clearCoupon}
                      className="flex items-center gap-1.5 px-4 py-2 bg-destructive/10 text-destructive border border-destructive/20 rounded text-sm font-medium hover:bg-destructive/20 transition-colors shrink-0 shadow-[0_0_8px_rgba(239,68,68,0.15)] dark:shadow-none"
                    >
                      <X className="w-3 h-3" /> Törlés
                    </button>
                  )}
                </div>
                {appliedCoupon && (
                  <p className="text-xs text-primary mt-1">{appliedCoupon.name} (-{appliedCoupon.discount_pct}%)</p>
                )}
              </div>
            </div>
          </div>

          {/* Vásárló szekció */}
          <div className="bg-muted/50 rounded shadow-sm overflow-hidden border border-border">
            <div className="px-5 py-3 border-b border-border">
              <h3 className="text-foreground font-semibold text-base">Vásárló</h3>
            </div>
            <div className="px-5 py-4 grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="text-xs text-muted-foreground block mb-1">Telefonos</label>
                <div className="flex items-center border border-border bg-card rounded h-9 px-2 text-sm text-muted-foreground focus-within:border-primary focus-within:ring-1 focus-within:ring-primary/20 transition-all">
                  <span className="truncate flex-1">{phone || 'Minimum 5 karakter...'}</span>
                  {phone && <button onClick={() => setPhone('')} className="ml-1 shrink-0 hover:text-foreground"><X className="w-3 h-3" /></button>}
                </div>
              </div>
              {deliveryType === 'szállítás' && (
                <>
                  <div>
                    <label className="text-xs text-muted-foreground block mb-1">Vezetéknév</label>
                    <div className="flex items-center border border-border bg-card rounded h-9 px-2 focus-within:border-primary focus-within:ring-1 focus-within:ring-primary/20 transition-all">
                      <span className="text-sm text-foreground truncate flex-1">{guestName.split(' ')[0] ?? ''}</span>
                      {guestName && <button onClick={() => setGuestName('')} className="shrink-0"><X className="w-3 h-3 text-muted-foreground hover:text-foreground" /></button>}
                    </div>
                  </div>
                  <div>
                    <label className="text-xs text-muted-foreground block mb-1">Keresztnév</label>
                    <div className="flex items-center border border-border bg-card rounded h-9 px-2 focus-within:border-primary focus-within:ring-1 focus-within:ring-primary/20 transition-all">
                      <span className="text-sm text-foreground truncate flex-1">{guestName.split(' ').slice(1).join(' ')}</span>
                      {guestName && <button onClick={() => setGuestName('')} className="shrink-0"><X className="w-3 h-3 text-muted-foreground" /></button>}
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>

          {/* Cím szekció - CSAK SZÁLLÍTÁS ESETÉN */}
          {deliveryType === 'szállítás' && (
            <div className="bg-muted/50 rounded shadow-sm overflow-hidden border border-border">
              <div className="px-5 py-3 border-b border-border">
                <h3 className="text-foreground font-semibold text-base">Cím</h3>
              </div>
              <div className="px-5 py-4 space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <div className="flex items-center gap-1 mb-1">
                      <Info className="w-3 h-3 text-primary" />
                      <label className="text-xs text-muted-foreground">Város *</label>
                    </div>
                    <div className="flex items-center border border-border bg-card rounded h-9 px-2 focus-within:border-primary focus-within:ring-1 focus-within:ring-primary/20 transition-all">
                      <span className="text-sm text-foreground truncate flex-1">{city || '—'}</span>
                      <span className="text-xs text-muted-foreground border-l border-border pl-1.5 shrink-0">
                        {selectedCity ? `+${selectedCity.delivery_fee.toLocaleString()} Ft` : '—'}
                      </span>
                    </div>
                  </div>
                  <div>
                    <label className="text-xs text-muted-foreground block mb-1">Utca *</label>
                    <div className="flex items-center border border-border bg-card rounded h-9 px-2 focus-within:border-primary focus-within:ring-1 focus-within:ring-primary/20 transition-all">
                      <span className="text-sm text-foreground truncate flex-1">{street || '—'}</span>
                    </div>
                  </div>
                </div>
                <div className="grid grid-cols-4 gap-3">
                  {[
                    { label: 'Házszám *', val: houseNumber },
                    { label: 'Emelet', val: floor },
                    { label: 'Ajtó', val: door },
                    { label: 'Csengő', val: bell },
                  ].map((f) => (
                    <div key={f.label}>
                      <label className="text-xs text-muted-foreground block mb-1">{f.label}</label>
                      <div className="flex items-center border border-border bg-card rounded h-9 px-2 focus-within:border-primary focus-within:ring-1 focus-within:ring-primary/20 transition-all">
                        <span className="text-sm text-foreground truncate flex-1">{f.val || '—'}</span>
                      </div>
                    </div>
                  ))}
                </div>
                <div>
                  <label className="text-xs text-muted-foreground block mb-1">Cím megjegyzés</label>
                  <div className="flex items-start border border-border bg-card rounded focus-within:border-primary focus-within:ring-1 focus-within:ring-primary/20 transition-all">
                    <span className="flex-1 min-w-0 px-2 py-1.5 text-sm text-foreground">{notes || '—'}</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Általános rendelés megjegyzés (csak beülős vagy elvitel esetén, mivel szállításnál ott a cím megjegyzés) */}
          {deliveryType !== 'szállítás' && (
            <div className="bg-muted/50 rounded shadow-sm overflow-hidden border border-border">
              <div className="px-5 py-3 border-b border-border">
                <h3 className="text-foreground font-semibold text-base">Rendelés megjegyzés</h3>
              </div>
              <div className="px-5 py-4 space-y-3">
                <div>
                  <div className="flex items-start border border-border bg-card rounded focus-within:border-primary focus-within:ring-1 focus-within:ring-primary/20 transition-all">
                    <span className="flex-1 min-w-0 px-2 py-1.5 text-sm text-foreground">{notes || '—'}</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Figyelmeztetés ha a szállítási cím nincs megerősítve */}
          {deliveryType === 'szállítás' && !addressOk && (
            <div className="flex items-center gap-2 text-sm bg-red-500/10 border border-red-500/30 text-red-600 dark:bg-red-950/30 dark:border-red-900/50 dark:text-red-400 rounded p-3 shadow-[0_0_8px_rgba(239,68,68,0.15)] dark:shadow-none">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>A rendelés leadásához erősítsd meg a címet a <b>VÁSÁRLÓ</b> lépésben (cím megadása + „Kiszámol” gomb).</span>
            </div>
          )}
        </div>

        {/* Jobb: Összesítő */}
        <div className="w-72 shrink-0 hidden md:flex flex-col bg-card border-l border-border shadow-[0_0_24px_rgba(0,0,0,0.05)] dark:shadow-none relative z-10">
          <div className="flex-1 overflow-y-auto px-4 py-4 text-muted-foreground text-sm">
            {cart.length === 0 ? (
              <p className="text-center">Nincsenek megjelenítendő elemek</p>
            ) : (
              <div className="space-y-2">
                {cart.map((item) => (
                  <div key={item.product_id + (item.extrasKey ?? '')} className="flex justify-between text-sm flex-col border-b border-border pb-2 mb-2 last:border-0">
                    <div className="flex justify-between w-full">
                      <span className="text-foreground truncate mr-2">{item.quantity}× {item.name}</span>
                      <span className="text-foreground shrink-0">{(item.price * item.quantity).toLocaleString()} Ft</span>
                    </div>
                    {item.note && <span className="text-primary text-xs italic truncate">Megj: {item.note}</span>}
                  </div>
                ))}
              </div>
            )}
          </div>
          <div className="border-t border-border px-4 py-4 space-y-2">
            <div className="flex justify-between text-sm text-foreground">
              <span>Kedvezmény</span>
              <span>{discountAmount > 0 ? `-${discountAmount.toLocaleString()} Ft` : '0 Ft'}</span>
            </div>
            <div className="flex justify-between text-sm text-foreground"><span>Szervízdíj</span><span>0 Ft</span></div>
            <div className="flex justify-between text-sm text-foreground">
              <span>Szállítási díj</span>
              <span className={deliveryType !== 'szállítás' || deliveryFee === 0 ? 'text-primary' : ''}>{deliveryType !== 'szállítás' ? 'N/A' : (deliveryFee === 0 ? (cityThreshold > 0 ? 'Ingyenes' : '0 Ft') : `${deliveryFee.toLocaleString()} Ft`)}</span>
            </div>
            {packagingTotal > 0 && (
              <div className="flex justify-between text-sm text-foreground">
                <span>Csomagolás</span>
                <span>{packagingTotal.toLocaleString()} Ft</span>
              </div>
            )}
            {drsTotal > 0 && (
              <div className="flex justify-between text-sm text-foreground">
                <span>DRS</span>
                <span>{drsTotal.toLocaleString()} Ft</span>
              </div>
            )}
            <div className="flex justify-between items-baseline pt-2 border-t border-border">
              <div className="flex items-center gap-1">
                <Info className="w-3.5 h-3.5 text-primary" />
                <span className="text-foreground font-bold">Végösszeg</span>
              </div>
              <span className="text-primary font-black text-2xl">{total.toLocaleString()} Ft</span>
            </div>
          </div>
        </div>
      </div>
    </div>

    {/* Öntet konfiguráló modal */}
    {configProduct && (
      <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/60" onClick={() => { setConfigProduct(null); setSelectedExtras({}); }}>
        <div className="bg-card rounded-lg p-5 max-w-sm w-full shadow-2xl max-h-[90dvh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
          <div className="flex items-start justify-between mb-3">
            <h3 className="font-bold text-lg text-foreground">{configProduct.name}</h3>
            <button onClick={() => { setConfigProduct(null); setSelectedExtras({}); }} className="text-muted-foreground hover:text-foreground">
              <X className="w-5 h-5" />
            </button>
          </div>
          {configProduct.image && (
            <div className="w-full h-40 mb-3 rounded overflow-hidden bg-card border border-border">
              <img src={configProduct.image} alt={configProduct.name} className="w-full h-full object-cover" />
            </div>
          )}
          <p className="text-primary font-bold text-xl mb-4">{configProduct.price.toLocaleString()} Ft</p>
          <div className="space-y-4 mb-5">
            {(configProduct.topping_groups || []).map((tgRef) => {
              const grp = typeof tgRef.group_id === 'object' ? tgRef.group_id as ToppingGroup : toppingGroups.find((g) => g._id === (tgRef.group_id as string));
              if (!grp) return null;
              const sel = selectedExtras[grp._id] || [];
              const maxSel = tgRef.max_select ?? grp.max_select ?? 1;
              const isRequired = tgRef.required ?? grp.required ?? false;
              const isSingle = maxSel === 1;
              return (
                <div key={grp._id} className="space-y-2">
                  <div className="flex items-center gap-2">
                    <h4 className="text-foreground font-semibold text-sm">{grp.name}</h4>
                    {isRequired ? <span className="text-xs px-1.5 py-0.5 rounded bg-red-500/10 text-red-600 border border-red-500/30 dark:bg-red-950/40 dark:text-red-400 dark:border-red-900/50">Kötelező</span> : <span className="text-xs px-1.5 py-0.5 rounded bg-muted text-muted-foreground">Opcionális</span>}
                    {!isSingle && <span className="text-xs text-muted-foreground">max {maxSel} db</span>}
                  </div>
                  {!isSingle && <p className={`text-xs mb-1 ${sel.length >= maxSel ? 'text-primary font-medium' : 'text-muted-foreground'}`}>{sel.length}/{maxSel} kiválasztva{sel.length >= maxSel ? ' — maximum elérve' : ''}</p>}
                  <div className="space-y-1.5">
                    {grp.options.map((opt, optIdx) => {
                      const isSelected = sel.includes(opt._id ?? '');
                      const maxReached = !isSingle && sel.length >= maxSel && !isSelected;
                      return (
                        <button key={opt._id ?? optIdx} disabled={maxReached}
                          className={`w-full flex items-center justify-between px-3 py-2.5 rounded border transition-colors text-left ${isSelected ? 'border-primary bg-primary/10 shadow-[0_0_8px_rgba(225,29,72,0.15)] dark:shadow-none' : maxReached ? 'border-border opacity-40 cursor-not-allowed' : 'border-border hover:border-primary/40 hover:shadow-[0_2px_8px_rgba(225,29,72,0.05)] dark:hover:shadow-none'}`}
                          onClick={() => {
                            if (maxReached) return;
                            setSelectedExtras((prev) => {
                              const current = prev[grp._id] || [];
                              if (isSingle) return { ...prev, [grp._id]: isSelected ? [] : [opt._id ?? ''] };
                              if (isSelected) return { ...prev, [grp._id]: current.filter((id) => id !== (opt._id ?? '')) };
                              if (current.length < maxSel) return { ...prev, [grp._id]: [...current, opt._id ?? ''] };
                              return prev;
                            });
                          }}>
                          <div className="flex items-center gap-2.5">
                            <div className={`w-4 h-4 rounded-${isSingle ? 'full' : 'sm'} border-2 flex items-center justify-center shrink-0 ${isSelected ? 'border-primary bg-primary' : 'border-border'}`}>
                              {isSelected && <Check className="w-2.5 h-2.5 text-primary-foreground" />}
                            </div>
                            <span className="text-sm text-foreground">{opt.name}</span>
                          </div>
                          <span className={`text-sm shrink-0 ${opt.price > 0 ? 'text-primary' : 'text-muted-foreground'}`}>{opt.price > 0 ? `+${opt.price.toLocaleString('hu-HU')} Ft` : 'Ingyenes'}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
          <div className="mb-4">
            <p className="text-sm font-bold text-foreground mb-2">Tételszintű megjegyzés <span className="text-muted-foreground font-normal text-xs">(opcionális)</span></p>
            <textarea
              className="w-full h-20 p-3 rounded-lg border border-border bg-card text-sm focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 transition-all resize-none text-foreground"
              placeholder="Pl.: Hagyma nélkül, kevésbé csípősen..."
              value={configNote}
              onChange={(e) => setConfigNote(e.target.value)}
            />
          </div>
          <div className="flex gap-3">
            <Button variant="outline" className="flex-1 border-border" onClick={() => { setConfigProduct(null); setSelectedExtras({}); setConfigNote(''); }}>
              <ArrowLeft className="w-4 h-4 mr-1.5" /> Mégse
            </Button>
            <Button className="flex-1 btn-primary-gradient text-primary-foreground font-bold" disabled={!canConfirmConfig()}
              onClick={() => { const extras = buildExtras(); addToCartDirect(configProduct, extras, 1, configNote); setConfigProduct(null); setSelectedExtras({}); setConfigNote(''); }}>
              <ShoppingCart className="w-4 h-4 mr-1.5" /> Kosárba
              {buildExtras().reduce((s, e) => s + e.price, 0) > 0 && (
                <span className="ml-1 text-primary-foreground/80 text-sm font-normal">(+{buildExtras().reduce((s, e) => s + e.price, 0).toLocaleString()} Ft)</span>
              )}
            </Button>
          </div>
        </div>
      </div>
    )}

    </>
  );
}
