import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { toast } from 'sonner';
import { orderApi } from '@/services/api';
import type { Order, OrderItem, Product } from '@/types';
import {
  Phone, MapPin, Clock, CreditCard, Banknote, StickyNote,
  Pencil, Plus, Minus, Trash2, Check, X, Navigation, User,
  Package, ChevronDown, ChevronUp, ExternalLink, Ban,
  ShoppingCart, ArrowLeft, ChevronRight, Printer,
} from 'lucide-react';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel,
  AlertDialogContent, AlertDialogDescription, AlertDialogFooter,
  AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from '@/components/ui/alert-dialog';

interface Props {
  order: Order | null;
  open: boolean;
  onClose: () => void;
  onUpdated: (order: Order) => void;
  onPrint?: (order: Order) => void;
  onEdit?: (order: Order) => void;
  products?: Product[];
  categories?: string[];
}

const STATUS_LABELS: Record<string, { label: string; color: string; classes: string }> = {
  pending:    { label: 'Beérkezett',     color: 'bg-yellow-500/10 text-yellow-600', classes: 'status-pending' },
  accepted:   { label: 'Elfogadva',      color: 'bg-blue-500/10 text-blue-600', classes: 'status-accepted' },
  preparing:  { label: 'Készítés alatt', color: 'bg-orange-500/10 text-orange-600', classes: 'status-preparing' },
  ready:      { label: 'Kész',           color: 'bg-purple-500/10 text-purple-600', classes: 'status-ready' },
  delivering: { label: 'Úton',           color: 'bg-cyan-500/10 text-cyan-600', classes: 'status-delivering' },
  delivered:  { label: 'Kiszállítva',    color: 'bg-green-500/10 text-green-600', classes: 'status-delivered' },
  cancelled:  { label: 'Sztornózva',     color: 'bg-red-500/10 text-red-600', classes: 'status-cancelled' },
};

function getUserName(userId: Order['user_id']): string {
  if (!userId || typeof userId !== 'object') return 'Vendég';
  return (userId as any).name || 'Vendég';
}
function getUserPhone(userId: Order['user_id']): string {
  if (!userId || typeof userId !== 'object') return '';
  return (userId as any).phone || '';
}

// ── Termék kártya a böngészőben ───────────────────────────────────────────────
function ProductCard({ product, onAdd }: { product: Product; onAdd: (p: Product) => void }) {
  return (
    <div className="bg-secondary border border-primary/30 rounded-xl overflow-hidden hover:border-primary/30 transition-all group">
      {product.image ? (
        <div className="aspect-[4/3] w-full overflow-hidden">
          <img src={product.image} alt={product.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
        </div>
      ) : (
        <div className="aspect-[4/3] w-full bg-card flex items-center justify-center">
          <Package className="w-8 h-8 text-muted-foreground/40" />
        </div>
      )}
      <div className="p-2.5">
        <p className="text-white text-xs font-semibold leading-tight line-clamp-2 mb-1 text-pretty">{product.name}</p>
        <div className="flex items-center justify-between gap-1">
          <span className="text-primary font-bold text-sm shrink-0">{product.price.toLocaleString()} Ft</span>
          <button
            onClick={() => onAdd(product)}
            className="w-7 h-7 rounded-lg bg-primary hover:bg-primary/80 flex items-center justify-center shrink-0 transition-colors"
          >
            <Plus className="w-3.5 h-3.5 text-white" />
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Fő modal ──────────────────────────────────────────────────────────────────
export default function OrderDetailModal({ order, open, onClose, onUpdated, onPrint, onEdit, products = [], categories = [] }: Props) {
  const [editMode, setEditMode] = useState(false);
  const [addProductMode, setAddProductMode] = useState(false);  // POS böngésző mód
  const [editItems, setEditItems] = useState<OrderItem[]>([]);
  const [editNotes, setEditNotes] = useState('');
  const [editPayment, setEditPayment] = useState<string>('');
  const [editPhone, setEditPhone] = useState('');
  const [saving, setSaving] = useState(false);

  const [cancelling, setCancelling] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  useEffect(() => {
    if (order && open) {
      setEditItems(order.items.map(i => ({ ...i })));
      setEditNotes(order.notes || '');
      setEditPayment(order.payment_method);
      setEditPhone((order as any).phone || getUserPhone(order.user_id) || '');
      setEditMode(false);
      setAddProductMode(false);
      setSelectedCategory(null);
      
      // Auto-fogadás ha új (pending) rendelést nyitunk meg
      if (order.status === 'pending') {
        orderApi.updateStatus(order._id, 'accepted').then(res => {
          onUpdated(res.data as Order);
          toast.success('Rendelés automatikusan elfogadva!');
          if (onPrint) {
            setTimeout(() => onPrint(res.data as Order), 300);
          }
        }).catch(() => {});
      }
    }
  }, [order, open]);

  if (!order) return null;

  const isPickup = order.delivery_type === 'elvitel';
  const isDineIn = order.delivery_type === 'beülős';

  const phone = (isPickup || isDineIn) ? '' : ((order as any).phone || getUserPhone(order.user_id) || '');
  const name = isPickup ? 'Elvitel' : (isDineIn ? 'Beülős' : (order.guest_name || getUserName(order.user_id) || 'Vendég'));
  
  const canEdit = !['cancelled', 'delivered'].includes(order.status) && (
    (order.delivery_type === 'szállítás' && order.status !== 'delivering') ||
    (order.delivery_type !== 'szállítás')
  );
  
  const canCancel = !['cancelled', 'delivered'].includes(order.status);
  const orderNum = (order as any).order_number ?? order._id.slice(-4);

  // Összeg újraszámolás
  const calcTotals = (items: OrderItem[]) => {
    const subtotal = items.reduce((s, i) => s + i.price * i.quantity, 0);
    const packaging = isDineIn ? 0 : items.reduce((s, i) => s + (i.packaging_fee || 0) * i.quantity, 0);
    const drs = items.reduce((s, i) => s + (i.drs_applies ? 50 * i.quantity : 0), 0);
    const delivery = order.delivery_fee || 0;
    const discount = order.discount_pct ? Math.round((subtotal * order.discount_pct) / 100) : 0;
    return { subtotal, packaging, drs, discount, total: subtotal + packaging + drs + delivery - discount };
  };

  const totals = editMode ? calcTotals(editItems) : {
    subtotal: order.subtotal,
    packaging: order.packaging_total,
    drs: order.drs_total,
    discount: order.discount_amount || 0,
    total: order.total,
  };

  // Kategóriák a termékböngészőhöz
  const availableCategories = categories.length > 0
    ? categories.filter(cat => products.some(p => p.category === cat && p.is_available !== false))
    : [...new Set(products.map(p => p.category))].filter(Boolean);

  const catProducts = selectedCategory
    ? products.filter(p => p.category === selectedCategory && p.is_available !== false)
    : [];

  const handleQtyChange = (idx: number, delta: number) => {
    setEditItems(prev => {
      const next = [...prev];
      const newQty = (next[idx].quantity || 1) + delta;
      if (newQty <= 0) { next.splice(idx, 1); } else { next[idx] = { ...next[idx], quantity: newQty }; }
      return next;
    });
  };

  const handleRemoveItem = (idx: number) => {
    setEditItems(prev => prev.filter((_, i) => i !== idx));
  };

  const addProductToCart = (product: Product) => {
    setEditItems(prev => {
      const existing = prev.find(i => i.product_id === product._id);
      if (existing) {
        return prev.map(i => i.product_id === product._id ? { ...i, quantity: i.quantity + 1 } : i);
      }
      return [...prev, {
        product_id: product._id,
        name: product.name,
        quantity: 1,
        price: product.price,
        packaging_fee: isDineIn ? 0 : (product.packaging_fee || 0),
        drs_applies: product.drs_applies || false,
        extras: [],
      }];
    });
    toast.success(`${product.name} hozzáadva`, { duration: 1000 });
  };

  const handleSave = async () => {
    if (editItems.length === 0) { toast.error('Legalább 1 tétel szükséges!'); return; }
    setSaving(true);
    try {
      const res = await orderApi.updateItems(order._id, {
        items: editItems,
        notes: editNotes,
        payment_method: editPayment,
        phone: editPhone.trim() || undefined,
      });
      toast.success('Rendelés frissítve');
      setEditMode(false);
      setAddProductMode(false);
      onUpdated(res.data as Order);
    } catch {
      toast.error('Mentés sikertelen');
    } finally {
      setSaving(false);
    }
  };

  const handleCancelEdit = () => {
    setEditItems(order.items.map(i => ({ ...i })));
    setEditNotes(order.notes || '');
    setEditPayment(order.payment_method);
    setEditPhone((order as any).phone || getUserPhone(order.user_id) || '');
    setEditMode(false);
    setAddProductMode(false);
    setSelectedCategory(null);
  };

  const handleCancelOrder = async () => {
    setCancelling(true);
    try {
      const res = await orderApi.updateStatus(order._id, 'cancelled');
      toast.success('Rendelés sztornózva');
      onUpdated(res.data as Order);
      onClose();
    } catch {
      toast.error('Sztornózás sikertelen');
    } finally {
      setCancelling(false);
    }
  };

  const handleCompleteOrder = async () => {
    try {
      const res = await orderApi.updateStatus(order._id, 'delivered');
      toast.success('Rendelés teljesítve (Kiadva)');
      onUpdated(res.data as Order);
      onClose();
    } catch {
      toast.error('Hiba a státusz frissítésekor');
    }
  };

  const cartCount = editItems.reduce((s, i) => s + i.quantity, 0);

  // ─── POS termék böngésző mód ─────────────────────────────────────────────
  if (addProductMode) {
    const editTotals = calcTotals(editItems);
    return (
      <Dialog open={open} onOpenChange={(o) => { if (!o) onClose(); }}>
        <DialogContent className="bg-card border border-primary/30 max-w-[calc(100%-1rem)] md:max-w-4xl max-h-[90dvh] p-0 overflow-hidden" aria-describedby={undefined}>
        <DialogTitle className="sr-only">Termék módosítása / hozzáadása</DialogTitle>
          {/* Fejléc */}
          <div className="flex items-center gap-3 px-4 py-3 border-b border-primary/30 bg-muted">
            <button
              onClick={() => { setAddProductMode(false); setSelectedCategory(null); }}
              className="flex items-center gap-1.5 text-primary text-sm hover:text-foreground transition-colors shrink-0"
            >
              <ArrowLeft className="w-4 h-4" /> Vissza
            </button>
            <span className="text-white font-semibold flex-1 text-center text-sm">Termék hozzáadása</span>
            <Button
              className="btn-primary-gradient text-white text-xs h-8 shrink-0"
              disabled={saving}
              onClick={handleSave}
            >
              <Check className="w-3.5 h-3.5 mr-1" /> {saving ? 'Mentés...' : 'Mentés'}
            </Button>
          </div>

          <div className="flex overflow-hidden" style={{ height: 'calc(90dvh - 60px)' }}>
            {/* Bal: Kategória / Termék böngésző */}
            <div className="flex-1 min-w-0 overflow-y-auto p-3">
              {/* Kategória visszagomb */}
              {selectedCategory && (
                <button
                  onClick={() => setSelectedCategory(null)}
                  className="flex items-center gap-1.5 text-sm text-primary hover:text-foreground mb-3 transition-colors"
                >
                  <ArrowLeft className="w-4 h-4" /> Kategóriák
                </button>
              )}

              {!selectedCategory ? (
                /* Kategória rács */
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                  {availableCategories.map(cat => {
                    const count = products.filter(p => p.category === cat && p.is_available !== false).length;
                    return (
                      <button
                        key={cat}
                        onClick={() => setSelectedCategory(cat)}
                        className="flex items-center justify-between p-3 bg-secondary hover:bg-primary/15 border border-primary/30 hover:border-primary/30 rounded-xl transition-all text-left group"
                      >
                        <div>
                          <span className="text-white font-semibold text-sm group-hover:text-primary transition-colors">{cat}</span>
                          <p className="text-muted-foreground text-xs mt-0.5">{count} termék</p>
                        </div>
                        <ChevronRight className="w-4 h-4 text-muted-foreground group-hover:text-primary transition-colors shrink-0" />
                      </button>
                    );
                  })}
                  {availableCategories.length === 0 && (
                    <p className="text-muted-foreground text-sm col-span-full text-center py-8">Nincsenek termékek</p>
                  )}
                </div>
              ) : (
                /* Termékek */
                <div>
                  <h3 className="text-white font-bold text-sm mb-3">{selectedCategory}</h3>
                  {catProducts.length === 0 ? (
                    <p className="text-muted-foreground text-sm text-center py-8">Nincs elérhető termék</p>
                  ) : (
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                      {catProducts.map(p => (
                        <ProductCard key={p._id} product={p} onAdd={addProductToCart} />
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Jobb: Kosár */}
            <div className="w-56 shrink-0 flex flex-col bg-muted border-l border-primary/30 hidden md:flex">
              <div className="px-3 pt-3 pb-2 border-b border-primary/30">
                <div className="flex items-center gap-2">
                  <ShoppingCart className="w-3.5 h-3.5 text-primary" />
                  <span className="text-white text-xs font-semibold">Kosár ({cartCount})</span>
                </div>
              </div>
              <div className="flex-1 overflow-y-auto px-3 py-2 min-h-0 space-y-1.5">
                {editItems.length === 0 ? (
                  <p className="text-muted-foreground text-xs text-center py-4">Üres</p>
                ) : (
                  editItems.map((item, i) => (
                    <div key={i} className="group">
                      <div className="flex items-start gap-1.5">
                        <p className="text-white text-xs flex-1 min-w-0 leading-tight truncate">{item.name}</p>
                        <button
                          onClick={() => handleRemoveItem(i)}
                          className="text-muted-foreground hover:text-red-400 shrink-0 mt-0.5"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                      <div className="flex items-center justify-between mt-0.5">
                        <div className="flex items-center gap-1">
                          <button onClick={() => handleQtyChange(i, -1)} className="w-4 h-4 rounded bg-secondary hover:bg-primary/15 text-white flex items-center justify-center">
                            <Minus className="w-2 h-2" />
                          </button>
                          <span className="text-white text-xs w-3 text-center font-bold">{item.quantity}</span>
                          <button onClick={() => handleQtyChange(i, 1)} className="w-4 h-4 rounded bg-secondary hover:bg-primary/15 text-white flex items-center justify-center">
                            <Plus className="w-2 h-2" />
                          </button>
                        </div>
                        <span className="text-primary text-xs font-semibold">{(item.price * item.quantity).toLocaleString()} Ft</span>
                      </div>
                    </div>
                  ))
                )}
              </div>
              <div className="border-t border-primary/30 px-3 py-2">
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground text-xs">Összesen</span>
                  <span className="text-white font-bold text-sm">{editTotals.total.toLocaleString()} Ft</span>
                </div>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  // ─── Normál / Szerkesztés nézet ──────────────────────────────────────────
  const isCancelled = order.status === 'cancelled';
  
  return (
    <Dialog open={open} onOpenChange={(o) => { if (!o) onClose(); }}>
      <DialogContent className={`border max-w-[calc(100%-1rem)] md:max-w-2xl max-h-[90dvh] overflow-y-auto p-0 shadow-2xl ${isCancelled ? 'bg-red-50/10 border-red-500/50' : 'bg-background border-border'}`} aria-describedby={undefined}>
        <DialogTitle className="sr-only">Rendelés részletei</DialogTitle>
        {isCancelled && (
          <div className="bg-red-500 text-white text-center py-2 font-black tracking-widest uppercase text-sm shadow-md">
            Sztornózott rendelés
          </div>
        )}
        {/* Fejléc */}
        <div className={`flex items-center justify-between px-6 py-4 border-b ${isCancelled ? 'bg-red-500/5 border-red-500/20' : 'bg-card border-border'}`}>
          <div>
            <div className="flex items-center gap-2 mb-1">
              <p className={`text-xs font-medium uppercase tracking-wide ${isCancelled ? 'text-red-500' : 'text-muted-foreground'}`}>Rendelés</p>
              {isCancelled && <Badge className="bg-red-500 hover:bg-red-600 text-white border-0 text-[10px] px-1.5 py-0 h-4">SZTORNÓ</Badge>}
            </div>
            <p className={`text-lg font-bold ${isCancelled ? 'text-red-500' : 'text-foreground'}`}>ID: {order._id.slice(-6).toUpperCase()}</p>
          </div>
          <div className="flex items-center gap-2">
            {canEdit && (
              <Button size="sm" variant="ghost" className="text-primary h-8 px-3 text-xs border border-primary/20 hover:bg-primary/5" onClick={() => onEdit?.(order)}>
                <Pencil className="w-3 h-3 mr-1" /> Szerkesztés (POS)
              </Button>
            )}
          </div>
        </div>

        <div className="p-6 space-y-4">
          {/* ── Akció gombok ── */}
          <div className="flex items-center gap-2 flex-wrap">
            {!editMode && canCancel && (
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <button className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold bg-[#b5255e] text-white hover:bg-[#9a1e4f] transition-colors shadow-sm">
                    <Ban className="w-3.5 h-3.5" /> Sztornó
                  </button>
                </AlertDialogTrigger>
                <AlertDialogContent className="bg-card border border-red-500/30 max-w-[calc(100%-2rem)] md:max-w-md">
                  <AlertDialogHeader>
                    <AlertDialogTitle className="text-white flex items-center gap-2">
                      <Ban className="w-5 h-5 text-red-400" /> Rendelés sztornózása
                    </AlertDialogTitle>
                    <AlertDialogDescription className="text-muted-foreground">
                      Biztosan sztornózod a <span className="text-white font-medium">#{order._id.slice(-6).toUpperCase()}</span> rendelést?
                      Ez a művelet nem vonható vissza.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel className="border-primary/30 text-muted-foreground hover:bg-secondary">Mégse</AlertDialogCancel>
                    <AlertDialogAction className="bg-red-600 hover:bg-red-700 text-white" onClick={handleCancelOrder}>
                      Sztornózás
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            )}
            {onPrint && (
              <button 
                onClick={() => onPrint(order)}
                className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold bg-card border border-border text-foreground hover:bg-muted/50 transition-colors shadow-sm"
              >
                <Printer className="w-3.5 h-3.5" /> Sima blokk nyomtatás
              </button>
            )}
            {!editMode && !['cancelled', 'delivered'].includes(order.status) && (isPickup || isDineIn) && (
              <button
                onClick={handleCompleteOrder}
                className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold bg-green-600 text-white hover:bg-green-700 transition-colors shadow-sm"
              >
                <Check className="w-3.5 h-3.5" /> Kiadva
              </button>
            )}
            <button
              onClick={onClose}
              className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold bg-[#b5255e] text-white hover:bg-[#9a1e4f] transition-colors shadow-sm ml-auto"
            >
              <ArrowLeft className="w-3.5 h-3.5" /> Vissza (Esc)
            </button>
          </div>

          {/* ── Forrás infó sor ── */}
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <span className="font-semibold text-foreground">{(order as any).source || 'Falatozz'}</span>
            <span>·</span>
            <span>{new Date(order.createdAt).toLocaleString('hu-HU', { dateStyle: 'short', timeStyle: 'short' })}</span>
            <span>·</span>
            <span>Eddigi rendelések: {(order as any).order_count ?? 1}</span>
            <span>·</span>
            <span>Létrejött: {new Date(order.createdAt).toLocaleString('hu-HU', { dateStyle: 'short', timeStyle: 'short' })}</span>
          </div>

          {/* ── Fő kártya ── */}
          <div className={`rounded-xl shadow-sm border overflow-hidden ${isCancelled ? 'bg-red-500/5 border-red-500/30' : 'bg-card border-border'}`}>
            {/* Vásárló adatok sor */}
            <div className={`flex items-start gap-4 px-5 py-4 border-b ${isCancelled ? 'border-red-500/20' : 'border-border'}`}>
              {/* Bal: sorszám + név */}
              <div className="flex items-center gap-3 min-w-0">
                <span className={`font-bold text-sm shrink-0 ${isCancelled ? 'text-red-500' : 'text-foreground'}`}>{orderNum}</span>
                <span className={`font-semibold text-sm ${isCancelled ? 'text-red-400' : 'text-foreground'}`}>{name}</span>
              </div>
              {/* Telefon */}
              <div className="shrink-0">
                {phone ? (
                  <a href={`tel:${phone}`} className={`text-sm hover:text-[#b5255e] transition-colors font-medium ${isCancelled ? 'text-red-400' : 'text-foreground'}`}>
                    {phone}
                  </a>
                ) : (
                  <span className="text-muted-foreground text-sm">—</span>
                )}
              </div>
              {/* Cím */}
              <div className="flex items-center gap-1 flex-1 min-w-0">
                <MapPin className={`w-3.5 h-3.5 shrink-0 ${isCancelled ? 'text-red-500' : 'text-[#b5255e]'}`} />
                <span className={`text-sm truncate ${isCancelled ? 'text-red-400' : 'text-[#b5255e]'}`}>{order.address || '—'}</span>
              </div>
              {/* Fizetési mód */}
              <div className={`shrink-0 text-sm font-bold ${isCancelled ? 'text-red-500' : 'text-foreground'}`}>
                {order.payment_method} | {order.total.toLocaleString()} Ft
              </div>
            </div>

            {/* ID + forrás sor */}
            <div className={`flex items-center justify-between px-5 py-2.5 border-b ${isCancelled ? 'bg-red-500/10 border-red-500/20' : 'bg-muted/50 border-border'}`}>
              <div className={`flex items-center gap-2 text-xs ${isCancelled ? 'text-red-400' : 'text-muted-foreground'}`}>
                <Package className="w-3.5 h-3.5" />
                <span>ID: {(order as any).order_number ?? order._id.slice(-4)}</span>
              </div>
              {((order as any).source === 'weboldal' || !(order as any).source) && (
                <div className="flex items-center gap-1.5 text-xs">
                  <span className={isCancelled ? 'text-red-400/70' : 'text-muted-foreground'}>Forrás:</span>
                  <span className={`font-bold ${isCancelled ? 'text-red-500' : 'text-primary'}`}>Weboldal</span>
                </div>
              )}
            </div>

            {/* Kosár fejléc */}
            {order.notes && (
              <div className={`px-5 py-3 border-b ${isCancelled ? 'bg-red-500/20 border-red-500/30' : 'bg-red-50 border-border'}`}>
                <div className={`flex items-start gap-2 ${isCancelled ? 'text-red-300' : 'text-red-600'}`}>
                  <StickyNote className="w-4 h-4 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-xs uppercase tracking-wider mb-1 block">A rendeléshez tartozó megjegyzés:</span>
                    <p className="text-sm font-semibold">{order.notes}</p>
                  </div>
                </div>
              </div>
            )}
            <div className={`flex items-center justify-between px-5 py-3 border-b ${isCancelled ? 'border-red-500/20' : 'border-border'}`}>
              <div className="flex items-center gap-2">
                <ShoppingCart className={`w-4 h-4 ${isCancelled ? 'text-red-500' : 'text-foreground'}`} />
                <span className={`font-bold text-sm ${isCancelled ? 'text-red-500' : 'text-foreground'}`}>Kosár</span>
              </div>
            </div>

            {/* Tételek lista */}
            <div className="p-2 space-y-2">
              {(editMode ? editItems : order.items).map((item, i) => (
                <div
                  key={i}
                  className={`flex flex-col border rounded-xl p-3 shadow-sm transition-colors ${isCancelled ? 'bg-red-500/5 border-red-500/20' : 'bg-muted/20 border-border/40 hover:border-primary/20'}`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-start gap-3 min-w-0 flex-1">
                      <span className={`font-black px-2 py-1 rounded-md text-sm shrink-0 min-w-[2.5rem] text-center shadow-sm ${isCancelled ? 'bg-red-500/20 text-red-500' : 'bg-primary/10 text-primary'}`}>
                        {item.quantity}×
                      </span>
                      <div className="flex flex-col min-w-0 pt-0.5">
                        <span className={`font-bold text-sm leading-tight uppercase ${isCancelled ? 'text-red-400' : 'text-foreground'}`}>
                          {item.name}
                        </span>
                        {(item.extras || []).length > 0 && (
                          <span className={`text-xs mt-1.5 leading-relaxed px-2 py-1 rounded border inline-block ${isCancelled ? 'bg-red-500/10 border-red-500/30 text-red-400' : 'bg-card/50 dark:bg-black/20 border-border/40 text-muted-foreground'}`}>
                            <span className="font-semibold">Extrák:</span> {(item.extras || []).map((e: any) => e.option_name).join(', ')}
                          </span>
                        )}
                        {item.note && (
                          <div className="mt-2 inline-flex items-start gap-1.5 bg-red-500/10 text-red-600 dark:bg-red-950/30 dark:text-red-400 px-2 py-1 rounded-md text-xs font-semibold border border-red-500/30 dark:border-red-900/50 shadow-sm max-w-full">
                            <StickyNote className="w-3.5 h-3.5 shrink-0 mt-0.5" />
                            <span className="truncate">{item.note}</span>
                          </div>
                        )}
                        {editMode && (
                          <div className="flex items-center gap-1.5 mt-3">
                            <button onClick={() => handleQtyChange(i, -1)} className="w-6 h-6 rounded bg-muted hover:bg-primary/10 flex items-center justify-center border border-border/40">
                              <Minus className="w-3 h-3" />
                            </button>
                            <span className="text-sm font-bold w-6 text-center">{item.quantity}</span>
                            <button onClick={() => handleQtyChange(i, 1)} className="w-6 h-6 rounded bg-muted hover:bg-primary/10 flex items-center justify-center border border-border/40">
                              <Plus className="w-3 h-3" />
                            </button>
                            <button onClick={() => handleRemoveItem(i)} className="w-6 h-6 rounded text-red-600 hover:bg-red-500/10 dark:hover:bg-red-950/30 flex items-center justify-center ml-2 border border-red-500/30 dark:border-red-900/50">
                              <Trash2 className="w-3 h-3" />
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                    <div className="shrink-0 text-right pt-0.5">
                      <span className={`font-bold text-sm whitespace-nowrap ${isCancelled ? 'text-red-500 line-through opacity-70' : 'text-foreground'}`}>
                        {(item.price * item.quantity).toLocaleString()} Ft
                      </span>
                    </div>
                  </div>
                </div>
              ))}
              {editMode && products.length > 0 && (
                <div className="px-3 py-3 border-t border-border/40">
                  <Button
                    size="sm"
                    className="bg-primary/10 hover:bg-primary/15 text-primary h-8 px-4 text-xs border border-primary/20"
                    variant="ghost"
                    onClick={() => { setAddProductMode(true); setSelectedCategory(null); }}
                  >
                    <Plus className="w-3 h-3 mr-1" /> Termék hozzáadása
                  </Button>
                </div>
              )}
              {editMode && editItems.length === 0 && (
                <p className="text-muted-foreground text-sm text-center py-4">Nincs tétel — adj hozzá terméket</p>
              )}
            </div>
          </div>

          {/* ── Összesítő + Vissza gomb ── */}
          <div className="flex items-center justify-between">
            <div className="text-xs text-muted-foreground">
              {order.coupon_code && (
                <span>Kupon: {order.coupon_name || order.coupon_code}</span>
              )}
            </div>
            <div className="text-right">
              <div className={`text-2xl font-bold ${isCancelled ? 'text-red-500 line-through opacity-80' : 'text-foreground'}`}>
                {totals.total.toLocaleString()} Ft
              </div>
              {editMode && totals.total !== order.total && (
                <span className="text-xs text-muted-foreground">(módosítva)</span>
              )}
            </div>
          </div>

          {/* ── Szerkesztés gombok ── */}
          {editMode && (
            <div className="flex gap-2">
              <Button className="flex-1 btn-primary-gradient" onClick={handleSave} disabled={saving}>
                <Check className="w-4 h-4 mr-1.5" /> {saving ? 'Mentés...' : 'Mentés'}
              </Button>
              <Button variant="outline" className="border-border text-muted-foreground hover:bg-muted/50" onClick={handleCancelEdit}>
                <X className="w-4 h-4 mr-1" /> Mégse
              </Button>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

interface Props {
  order: Order | null;
  open: boolean;
  onClose: () => void;
  onUpdated: (order: Order) => void;
}

