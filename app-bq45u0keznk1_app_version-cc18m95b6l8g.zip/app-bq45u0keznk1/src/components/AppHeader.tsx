import { useNavigate, useLocation } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { settingsApi } from '@/services/api';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { User, ClipboardList, LogOut, LogIn, UserPlus, Crown } from 'lucide-react';

const LOGO_URL = '/logo.png';
const BRAND = '#d4af37'; // Luxury Gold

interface AppHeaderProps {
  isOpen?: boolean;
  rightSlot?: React.ReactNode;
  darkMode?: boolean;
}

export default function AppHeader({ isOpen, rightSlot, darkMode }: AppHeaderProps) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const [loyaltySettings, setLoyaltySettings] = useState({
    bronze_threshold: 10,
    silver_threshold: 50,
    gold_threshold: 100,
    vip_enabled: true
  });

  useEffect(() => {
    if (user) {
      settingsApi.get('loyalty_settings').then(res => {
        const data = res.data?.value || res.data;
        if (data) setLoyaltySettings(data);
      }).catch(() => {});
    }
  }, [user]);

  const handleEtlapClick = () => {
    if (location.pathname !== '/menu' && location.pathname !== '/') {
      navigate('/menu');
      setTimeout(() => document.getElementById('etlap')?.scrollIntoView({ behavior: 'smooth' }), 300);
    } else {
      document.getElementById('etlap')?.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const getNextTierInfo = () => {
    if (!user) return null;
    const pts = (user as any)?.points || 0;
    if (pts < loyaltySettings.bronze_threshold) return { name: 'Bronz', needed: loyaltySettings.bronze_threshold - pts };
    if (pts < loyaltySettings.silver_threshold) return { name: 'Ezüst', needed: loyaltySettings.silver_threshold - pts };
    if (pts < loyaltySettings.gold_threshold) return { name: 'Arany', needed: loyaltySettings.gold_threshold - pts };
    return null;
  };

  const headerClassName = darkMode 
    ? "sticky top-0 z-50 bg-[#0c0a07]/60 backdrop-blur-md border-b border-white/5 shadow-sm"
    : "sticky top-0 z-50 site-header";

  const textColor = darkMode ? '#f5f0e8' : undefined;
  const mutedColor = darkMode ? '#a89070' : undefined;

  return (
    <header className={headerClassName}>
      <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between gap-3">

        {/* Brand */}
        <button
          onClick={() => navigate('/')}
          className="flex items-center gap-2.5 group shrink-0"
        >
          <img
            src={LOGO_URL}
            alt="Szesztestvérek Falatház logó"
            className={`h-10 w-10 object-contain group-hover:scale-105 transition-transform duration-200 ${darkMode ? 'drop-shadow-[0_0_8px_rgba(255,255,255,0.2)]' : ''}`}
          />
          <div className="hidden sm:block text-left">
            <p className="font-black text-sm leading-none tracking-wide" style={textColor ? { color: textColor } : {}}>
              Szesztestvérek
            </p>
            <p className="text-[10px] font-bold uppercase tracking-widest leading-none mt-0.5" style={{ color: BRAND }}>
              Falatház
            </p>
          </div>
        </button>

        {/* Középső menü eltávolítva kérésre */}

        {/* Right side */}
        <div className="flex items-center gap-3">
          {/* Nyitvatartás badge */}
          {rightSlot}

          {/* Auth nav */}
          {user ? (
            <div className="flex items-center gap-3">
              <div className="hidden md:flex flex-col items-end text-right">
                {user.role === 'admin' ? (
                  <span className="text-xs font-bold text-red-500 bg-red-500/10 px-2 py-0.5 rounded">Admin</span>
                ) : (
                  <>
                    <div className="flex items-center gap-1.5">
                      <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                        (user as any).points >= loyaltySettings.gold_threshold ? 'text-yellow-500 bg-yellow-500/10 border border-yellow-500/20' :
                        (user as any).points >= loyaltySettings.silver_threshold ? 'text-gray-300 bg-gray-300/10 border border-gray-300/20' :
                        (user as any).points >= loyaltySettings.bronze_threshold ? 'text-orange-400 bg-orange-400/10 border border-orange-400/20' :
                        'text-primary bg-primary/10'
                      }`}>
                        {(user as any).points >= loyaltySettings.gold_threshold ? 'Arany Tag' :
                         (user as any).points >= loyaltySettings.silver_threshold ? 'Ezüst Tag' :
                         (user as any).points >= loyaltySettings.bronze_threshold ? 'Bronz Tag' : 'Alap Tag'}
                      </span>
                    </div>
                    <span className={`text-xs font-semibold ${darkMode ? 'text-white/70' : 'text-gray-600'} mt-0.5`}>
                      {(user as any).points || 0} pont
                    </span>
                  </>
                )}
              </div>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button
                    className="w-10 h-10 rounded-full flex items-center justify-center text-black font-bold text-sm transition-all hover:scale-105 shadow-md border border-[#d4af37]/30"
                    style={{ background: '#d4af37' }}
                  >
                    {user.name?.charAt(0).toUpperCase()}
                  </button>
                </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className={`bg-background border-border text-foreground min-w-[200px] shadow-lg ${darkMode ? 'theme-restaurant' : ''}`}>
                <div className="px-3 py-3 bg-secondary/20 rounded-t-md">
                  <p className="text-sm font-semibold text-foreground truncate">{user.name}</p>
                  <p className="text-xs text-muted-foreground">{user.phone}</p>
                  {user.role !== 'admin' && user.role !== 'courier' && (
                    <div className="mt-2 pt-2 border-t border-border/50">
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-xs text-muted-foreground">Jelenlegi pontok:</span>
                        <span className="text-xs font-bold text-primary">{(user as any).points || 0}</span>
                      </div>
                      {getNextTierInfo() ? (
                        <div className="text-[10px] text-muted-foreground bg-background/50 p-1.5 rounded border border-border/50 mt-1">
                          Még <span className="font-bold text-foreground">{getNextTierInfo()?.needed}</span> pont a <span className="font-bold text-primary">{getNextTierInfo()?.name}</span> szinthez.
                        </div>
                      ) : (
                        <div className="text-[10px] font-bold text-yellow-500 bg-yellow-500/10 p-1.5 rounded mt-1 border border-yellow-500/20">
                          Maximális Arany szint!
                        </div>
                      )}
                    </div>
                  )}
                </div>
                <DropdownMenuSeparator />
                <DropdownMenuItem className="cursor-pointer hover:bg-muted focus:bg-muted" onClick={() => navigate('/profile')}>
                  <User className="w-4 h-4 mr-2" style={{ color: BRAND }} />
                  Profilom
                </DropdownMenuItem>
                {user.role === 'customer' && (
                  <DropdownMenuItem className="cursor-pointer hover:bg-muted focus:bg-muted" onClick={() => navigate('/orders')}>
                    <ClipboardList className="w-4 h-4 mr-2" style={{ color: BRAND }} />
                    Rendeléseim
                  </DropdownMenuItem>
                )}
                {user.role === 'admin' && (
                  <DropdownMenuItem className="cursor-pointer hover:bg-muted focus:bg-muted" onClick={() => navigate('/admin')}>
                    <ClipboardList className="w-4 h-4 mr-2" style={{ color: BRAND }} />
                    Admin panel
                  </DropdownMenuItem>
                )}

                <DropdownMenuSeparator />
                <DropdownMenuItem
                  className="cursor-pointer text-destructive hover:bg-destructive/10 focus:bg-destructive/10 focus:text-destructive"
                  onClick={() => { logout(); navigate('/login'); }}
                >
                  <LogOut className="w-4 h-4 mr-2" />
                  Kijelentkezés
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <button
                onClick={() => navigate('/login')}
                className="w-10 h-10 flex items-center justify-center rounded-full transition-all hover:scale-105 shadow-md border border-[#d4af37]/30 text-black"
                style={{ background: '#d4af37' }}
              >
                <User className="w-5 h-5" />
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
