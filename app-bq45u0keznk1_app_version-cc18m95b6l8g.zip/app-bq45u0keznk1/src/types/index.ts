export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: 'customer' | 'admin' | 'courier' | 'superadmin' | 'guest';
  default_address: string;
  // Keresés forrása: 'registered' = regisztrált user, 'order_history' = korábbi rendelésből
  source?: 'registered' | 'order_history';
  order_count?: number | null;
  points?: number;
}

// ── Öntet-csoportok ───────────────────────────────────────────────────────────
export interface ToppingOption {
  _id?: string;
  name: string;
  price: number;
}

export interface ToppingGroup {
  _id: string;
  name: string;
  required: boolean;
  min_select: number;
  max_select: number;
  options: ToppingOption[];
}

// Termékhez csatolt öntet-csoport referencia (populate után group_id = ToppingGroup)
export interface ProductToppingRef {
  group_id: ToppingGroup | string;
  required: boolean;
  max_select: number;
}

export interface Product {
  _id: string;
  name: string;
  description: string;
  price: number;
  original_price?: number;
  category: string;
  packaging_fee: number;
  drs_applies: boolean;
  image: string;
  is_available: boolean;
  topping_groups: ProductToppingRef[];
}

// ── Rendelési extras ──────────────────────────────────────────────────────────
export interface OrderItemExtra {
  group_id: string;
  group_name: string;
  option_id: string;
  option_name: string;
  price: number;
}

export interface OrderItem {
  product_id: string;
  name: string;
  quantity: number;
  price: number;
  packaging_fee: number;
  drs_applies: boolean;
  extras: OrderItemExtra[];
  note?: string; // Tételszintű megjegyzés
}

export interface City {
  _id: string;
  name: string;
  delivery_fee: number;
  free_delivery_threshold?: number;
  active: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Order {
  _id: string;
  order_number?: string | number;
  user_id: User | string;
  guest_name?: string;
  items: OrderItem[];
  subtotal: number;
  packaging_total: number;
  drs_total: number;
  delivery_fee: number;
  discount_pct: number;
  discount_amount: number;
  total: number;
  payment_method: 'Készpénz' | 'Bankkártya';
  delivery_type?: 'szállítás' | 'elvitel' | 'beülős';
  status: 'pending' | 'accepted' | 'preparing' | 'ready' | 'delivering' | 'delivered' | 'cancelled';
  address: string;
  city_id: string | null;
  city_name: string;
  street: string;
  house_number: string;
  floor: string;
  door: string;
  bell: string;
  phone?: string;
  notes: string;
  coupon_code: string;
  coupon_name: string;
  courier_id: User | string | null;
  courier_status?: 'assigned' | 'accepted' | 'at_kitchen' | 'on_the_way' | 'delivered' | null;
  courier_started_at?: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface Coupon {
  _id: string;
  name: string;
  code: string;
  discount_pct: number;
  active: boolean;
  max_uses: number | null;
  usage_count: number;
  createdAt: string;
  updatedAt: string;
}

export interface CartItem extends OrderItem {
  product: Product;
}

export interface OpeningHours {
  monday: { open: string; close: string };
  tuesday: { open: string; close: string };
  wednesday: { open: string; close: string };
  thursday: { open: string; close: string };
  friday: { open: string; close: string };
  saturday: { open: string; close: string };
  sunday: { open: string; close: string };
}

export interface Review {
  _id: string;
  order_id: string | Order;
  user_id: string | User;
  rating: number;
  food_rating: number | null;
  delivery_rating: number | null;
  comment: string;
  items: string[];
  createdAt: string;
  updatedAt: string;
}

export interface ReviewStats {
  total: number;
  avgRating: number;
  avgFood: number;
  avgDelivery: number;
  distribution: number[]; // [1star, 2star, 3star, 4star, 5star]
}

export interface Stats {
  totalOrders: number;
  totalRevenue: number;
  foodRevenue: number;
  packagingRevenue: number;
  drsRevenue: number;
  cashRevenue: number;
  cardRevenue: number;
  courierCashRevenue: number;
  courierCardRevenue: number;
  deliveryCount: number;
  pickupCount: number;
  deliveryRevenue: number;
  pickupRevenue: number;
  topProducts: Array<{ name: string; quantity: number; revenue: number }>;
  hourlyData: Array<{ hour: number; orders: number; revenue: number }>;
}
