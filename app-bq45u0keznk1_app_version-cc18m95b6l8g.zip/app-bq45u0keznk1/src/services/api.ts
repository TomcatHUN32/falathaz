import axios from 'axios';

const API_URL = '/api';

const api = axios.create({
  baseURL: API_URL,
  headers: { 'Content-Type': 'application/json' },
  timeout: 15000,
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }

  // Extract restaurant ID from URL if present
  const pathParts = window.location.pathname.split('/');
  if (pathParts.length >= 2) {
    const firstSegment = pathParts[1];
    const reservedPaths = ['login', 'register', 'profile', 'super-admin', 'api'];
    if (firstSegment && !reservedPaths.includes(firstSegment)) {
      config.headers['X-Restaurant-ID'] = firstSegment;
    }
  }

  // A platform gateway express.json() megeszi a POST/PUT/PATCH body-ját mielőtt
  // Vite-ra proxyzná — ezért a body-t X-Body-Data headerben is elküldjük base64-ban.
  // A Vite configureServer plugin ezt kicsomagolja és friss kérést küld a backendnek.
  if (
    import.meta.env.DEV &&
    config.data !== undefined &&
    ['post', 'put', 'patch'].includes((config.method ?? '').toLowerCase())
  ) {
    try {
      const bodyStr =
        typeof config.data === 'string'
          ? config.data
          : JSON.stringify(config.data);
      const bytes = new TextEncoder().encode(bodyStr);
      const binary = Array.from(bytes)
        .map((b) => String.fromCharCode(b))
        .join('');
      config.headers['X-Body-Data'] = btoa(binary);
    } catch {
      // ha nem sikerül kódolni, az eredeti body megmarad
    }
  }

  return config;
});

export default api;

export const authApi = {
  register: (data: any) => api.post('/auth/register', data),
  login: (email: string, password: string) => api.post('/auth/login', { email, password }),
  me: () => api.get('/auth/me'),
  getMe: () => api.get('/auth/me'),
  searchUser: (phone: string) => api.get('/auth/search', { params: { phone } }),
  searchSuggestions: (phone: string) => api.get('/auth/search-suggestions', { params: { phone } }),
  updateProfile: (data: { name?: string; email?: string; phone?: string; default_address?: string; lat?: number | null; lng?: number | null; current_password?: string; new_password?: string }) =>
    api.put('/auth/profile', data),
};

export const restaurantApi = {
  getById: (id: string) => api.get(`/restaurants/${id}`),
};

export const productApi = {
  getAll: (adminMode = false) => api.get('/products', { params: adminMode ? { admin: '1' } : {} }),
  toggleAvailability: (id: string, is_available: boolean) => api.patch(`/products/${id}/availability`, { is_available }),
  create: (data: any) => api.post('/products', data),
  update: (id: string, data: any) => api.put(`/products/${id}`, data),
  delete: (id: string) => api.delete(`/products/${id}`),
  // Képfeltöltés: base64 kódolt kép küldése JSON-ban
  uploadImage: (base64Data: string) => api.post('/products/upload-image', { data: base64Data }),
};

export const orderApi = {
  create: (data: any) => api.post('/orders', data),
  getMyOrders: () => api.get('/orders/my'),
  getTodayOrders: () => api.get('/orders/today'),
  getAllOrders: (from?: string, to?: string) => api.get('/orders/all', { params: { from, to } }),
  getById: (id: string) => api.get(`/orders/${id}`),
  updateStatus: (id: string, status?: string, courier_id?: string | null, courier_status?: string | null) =>
    api.put(`/orders/${id}/status`, { status, courier_id, courier_status }),
  getCourierOrders: (courierId: string) => api.get(`/orders/courier/${courierId}`),
  updateItems: (id: string, data: any) =>
    api.patch(`/orders/${id}/items`, data),
};

export const adminApi = {
  getStats: (from?: string, to?: string) => api.get('/admin/stats', { params: { from, to } }),
  getCourierDaily: () => api.get('/admin/courier-daily'),
  getCouriers: () => api.get('/admin/couriers'),
  createCourier: (data: { name: string; email: string; phone?: string; password: string }) =>
    api.post('/admin/couriers', data),
  updateCourier: (id: string, data: { name?: string; email?: string; phone?: string; password?: string }) =>
    api.put(`/admin/couriers/${id}`, data),
  deleteCourier: (id: string) => api.delete(`/admin/couriers/${id}`),
};

export const settingsApi = {
  getAll: () => api.get('/settings').catch(e => {
    if (e.response?.status === 404) return { data: {} };
    throw e;
  }),
  get: (key: string) => api.get(`/settings/${key}`).catch(e => {
    if (e.response?.status === 404) return { data: null };
    throw e;
  }),
  update: (key: string, value: any) => api.put(`/settings/${key}`, value),
  getCategories: () => api.get('/settings/categories').catch(e => {
    if (e.response?.status === 404) return { data: [] };
    throw e;
  }),
  updateCategories: (categories: string[]) => api.put('/settings/categories', categories),
};

export const toppingApi = {
  getAll: () => api.get('/toppings'),
  create: (data: any) => api.post('/toppings', data),
  update: (id: string, data: any) => api.put(`/toppings/${id}`, data),
  delete: (id: string) => api.delete(`/toppings/${id}`),
};

export const cityApi = {
  getAll: () => api.get('/cities'),
  getAllAdmin: () => api.get('/cities/all'),
  create: (data: { name: string; delivery_fee: number; free_delivery_threshold?: number; active?: boolean }) =>
    api.post('/cities', data),
  update: (id: string, data: { name?: string; delivery_fee?: number; free_delivery_threshold?: number; active?: boolean }) =>
    api.put(`/cities/${id}`, data),
  delete: (id: string) => api.delete(`/cities/${id}`),
};

export const couponApi = {
  getAll: () => api.get('/coupons'),
  create: (data: { name: string; code: string; discount_pct: number; max_uses?: number }) =>
    api.post('/coupons', data),
  update: (id: string, data: { name?: string; code?: string; discount_pct?: number; active?: boolean; max_uses?: number }) =>
    api.put(`/coupons/${id}`, data),
  delete: (id: string) => api.delete(`/coupons/${id}`),
  validate: (code: string) => api.get(`/coupons/validate/${code}`),
};

export const reviewApi = {
  create: (data: { order_id: string; rating: number; food_rating?: number; delivery_rating?: number; comment?: string }) =>
    api.post('/reviews', data),
  getByOrder: (orderId: string) => api.get(`/reviews/order/${orderId}`),
  getAll: () => api.get('/reviews'),
  getStats: () => api.get('/reviews/stats'),
};

export const favoriteApi = {
  getFavorites: () => api.get('/favorites'),
  addFavorite: (productId: string) => api.post('/favorites', { productId }),
  removeFavorite: (productId: string) => api.delete(`/favorites/${productId}`),
};
