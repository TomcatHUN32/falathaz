import api from './api';

export const superadminApi = {
  getRestaurants: () => api.get('/restaurants'),
  createRestaurant: (data: any) => api.post('/restaurants', data),
  updateRestaurant: (id: string, data: any) => api.put(`/restaurants/${id}`, data),
  deleteRestaurant: (id: string) => api.delete(`/restaurants/${id}`),
};
