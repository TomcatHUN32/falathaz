import Login from './pages/Login';
import Register from './pages/Register';
import OnlineOrdering from './pages/OnlineOrdering';
import OrderTracking from './pages/OrderTracking';
import MyOrders from './pages/MyOrders';
import AdminDashboard from './pages/AdminDashboard';
import CourierApp from './pages/CourierApp';
import Profile from './pages/Profile';
import SuperAdmin from './pages/SuperAdmin';
import MainPortal from './pages/MainPortal';
import NotFound from './pages/NotFound';
import type { ReactNode } from 'react';

export interface RouteConfig {
  name: string;
  path: string;
  element: ReactNode;
  visible?: boolean;
  public?: boolean;
}

import { Navigate } from 'react-router-dom';

export const routes: RouteConfig[] = [
  { name: 'Főoldal', path: '/', element: <MainPortal />, public: true },
  { name: 'Login', path: '/login', element: <Login />, public: true },
  { name: 'Register', path: '/register', element: <Register />, public: true },
  { name: 'Profile', path: '/profile', element: <Profile /> },
  { name: 'Super Admin', path: '/super-admin', element: <SuperAdmin /> },
  
  { name: 'Online Rendelés', path: '/:restaurantId/menu', element: <OnlineOrdering />, public: true },
  { name: 'Checkout', path: '/:restaurantId/checkout', element: <OnlineOrdering />, public: true },
  { name: 'Order Tracking', path: '/:restaurantId/order-status/:orderId', element: <OrderTracking />, public: true },
  
  { name: 'Admin Dashboard', path: '/:restaurantId/admin', element: <AdminDashboard /> },
  { name: 'POS', path: '/:restaurantId/pos', element: <AdminDashboard /> },
  { name: 'Courier App', path: '/:restaurantId/courier', element: <CourierApp /> },
  
  { name: 'My Orders', path: '/orders', element: <MyOrders /> },
  { name: 'Old Menu Redirect', path: '/menu', element: <Navigate to="/" replace />, public: true },
  { name: 'Admin Fallback Redirect', path: '/admin', element: <Navigate to="/super-admin" replace />, public: true },
  { name: 'Old Track Redirect', path: '/track/:orderId', element: <Navigate to="/" replace />, public: true },
  { name: 'Not Found', path: '*', element: <NotFound />, public: true },
];
