import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import { authApi } from '@/services/api';
import type { User } from '@/types';
import { toast } from 'sonner';

interface AuthContextType {
  user: User | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  register: (data: RegisterData) => Promise<boolean>;
  logout: () => void;
  setUser: (user: User | null) => void;
  updateUser: () => Promise<void>;
}

interface RegisterData {
  name: string;
  email: string;
  password: string;
  phone?: string;
  default_address: string;
  lat: number | null;
  lng: number | null;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (!token) {
      setLoading(false);
      return;
    }

    // 30 másodperces időkorlát — csak a töltő képernyőt zárja be, a tokent NEM törli.
    // Pl. Vite újrainduláskor a kérés lassú lehet, de a token még érvényes marad.
    let settled = false;
    const timeout = setTimeout(() => {
      if (!settled) {
        settled = true;
        setLoading(false);
      }
    }, 30000);

    authApi.getMe()
      .then((res) => {
        settled = true;
        clearTimeout(timeout);
        setUser(res.data);
      })
      .catch(() => {
        settled = true;
        clearTimeout(timeout);
        // Csak akkor töröljük a tokent, ha a szerver expliciten visszautasította
        localStorage.removeItem('token');
        setUser(null);
      })
      .finally(() => {
        setLoading(false);
      });
  }, []);

  const login = async (email: string, password: string) => {
    try {
      const res = await authApi.login(email, password);
      localStorage.setItem('token', res.data.token);
      setUser(res.data.user);
      toast.success('Sikeres bejelentkezés! Üdv, ' + res.data.user.name + '!');
      return true;
    } catch (err: any) {
      const msg = err?.response?.data?.error || err?.message || 'Bejelentkezés sikertelen';
      toast.error(msg);
      throw new Error(msg);
    }
  };

  const register = async (data: RegisterData) => {
    try {
      const res = await authApi.register(data);
      localStorage.setItem('token', res.data.token);
      setUser(res.data.user);
      toast.success('Sikeres regisztráció! Üdv, ' + res.data.user.name + '!');
      return true;
    } catch (err: any) {
      const msg = err?.response?.data?.error || err?.message || 'Regisztráció sikertelen';
      toast.error(msg);
      throw new Error(msg);
    }
  };

  const logout = () => {
    localStorage.removeItem('token');
    setUser(null);
    toast.info('Kijelentkezve');
  };

  const updateUser = async () => {
    try {
      const res = await authApi.getMe();
      if (res.data) {
        setUser(res.data);
      }
    } catch (err) {
      console.error('Failed to update user', err);
    }
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout, setUser, updateUser }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    // Vite HMR során a modul újratöltésekor a context két példányra szakadhat.
    // Fejlesztői módban biztonságos alapértéket adunk vissza, ne dobjunk hibát.
    if (import.meta.env.DEV) {
      return {
        user: null,
        loading: false,
        login: () => Promise.resolve(false) as Promise<boolean>,
        register: () => Promise.resolve(false) as Promise<boolean>,
        logout: () => {},
        setUser: () => {},
        updateUser: () => Promise.resolve(),
      };
    }
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
