// module v6
import { createContext, useContext, useEffect, useRef, useState, type ReactNode } from 'react';
import { io, Socket } from 'socket.io-client';

interface SocketContextType {
  socket: Socket | null;
  joinRooms: (role: string, userId: string) => void;
}

const SocketContext = createContext<SocketContextType>({ socket: null, joinRooms: () => {} });

export function SocketProvider({ children }: { children: ReactNode }) {
  const [socket, setSocket] = useState<Socket | null>(null);
  const socketRef = useRef<Socket | null>(null);

  useEffect(() => {
    const s = io('/', { path: '/socket.io' });
    socketRef.current = s;
    setSocket(s);
    s.on('connect', () => console.log('Socket csatlakozott'));
    return () => { s.disconnect(); };
  }, []);

  // Szoba-csatlakoztatás: hívják a page komponensek bejelentkezés után
  const joinRooms = (role: string, userId: string) => {
    const s = socketRef.current;
    if (!s) return;
    if (role === 'admin') s.emit('join_admin');
    else if (role === 'courier') s.emit('join_courier', userId);
  };

  return (
    <SocketContext.Provider value={{ socket, joinRooms }}>
      {children}
    </SocketContext.Provider>
  );
}

export function useSocket() {
  return useContext(SocketContext);
}
