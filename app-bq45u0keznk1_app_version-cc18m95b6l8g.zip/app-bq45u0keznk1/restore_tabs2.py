import sys

# 1. Read old AdminDashboard
with open('/tmp/old_AdminDashboard.tsx', 'r') as f:
    old_lines = f.read().split('\n')

# lines 972 to 1253 are index 971 to 1253
tabs_code = '\n'.join(old_lines[971:1253])

# lines 1300 to END are index 1299 to end
helpers_code = '\n'.join(old_lines[1299:])

# 2. Read new AdminDashboard
path = '/workspace/app-bq45u0keznk1/src/pages/AdminDashboard.tsx'
with open(path, 'r') as f:
    new_content = f.read()

# Replace the placeholder
placeholder = """{['products', 'stats', 'couriers', 'courier-management', 'coupons', 'settings', 'napi-zaras', 'futar-zaras'].includes(activeTab) && (
          <div className="p-6 h-full overflow-y-auto bg-white">
            <h2 className="text-xl font-bold mb-4 uppercase text-gray-800">{activeTab.replace('-', ' ')}</h2>
            <p className="text-gray-500">Kérlek használd a korábbi felületet ezen funkciók eléréséhez, vagy nyisd meg az újításokat.</p>
          </div>
        )}"""

if placeholder in new_content:
    new_content = new_content.replace(placeholder, tabs_code)
else:
    print("Placeholder not found!")

# Append helper functions if they are missing
if "function ProductManagement" not in new_content:
    new_content += "\n" + helpers_code
else:
    print("Helper functions already exist!")

with open(path, 'w') as f:
    f.write(new_content)
    
print("Restored tabs and helper functions cleanly!")
