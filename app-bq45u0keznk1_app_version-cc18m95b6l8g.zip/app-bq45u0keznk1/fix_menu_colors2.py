import re

path = '/workspace/app-bq45u0keznk1/src/pages/OnlineOrdering.tsx'
with open(path, 'r') as f:
    content = f.read()

replacements = [
    (r"style=\{\{\s*color:\s*'#ea5a0c',\s*fontStyle:\s*'italic'\s*\}\}", 'className="text-primary italic"'),
    (r"style=\{\{\s*color:\s*'#a89070'\s*\}\}", 'className="text-muted-foreground"'),
    (r"style=\{\{\s*height:\s*1,\s*background:\s*'#2e2616'\s*\}\}", 'className="h-px bg-border"'),
    (r"style=\{\{\s*color:\s*subtotal >= MIN_ORDER \? '#4ade80' : '#ea5a0c'\s*\}\}", 'className={subtotal >= MIN_ORDER ? "text-green-500" : "text-primary"}'),
    (r"style=\{\{\s*width:\s*`\$\{minProgress\}%`,\s*background:\s*subtotal >= MIN_ORDER \? '#4ade80' : '#ea5a0c'\s*\}\}", 'className={subtotal >= MIN_ORDER ? "bg-green-500" : "bg-primary"} style={{ width: `${minProgress}%` }}'),
    (r"style=\{\{\s*color:\s*'#4ade80'\s*\}\}", 'className="text-green-500"'),
    (r"style=\{\{\s*borderTop:\s*'1px solid #3a3020',\s*color:\s*'#f5f0e8'\s*\}\}", 'className="border-t border-border text-foreground"'),
    (r"style=\{\{\s*color:\s*'#f5c842',\s*background:\s*'rgba\(245,200,66,0.08\)',\s*border:\s*'1px solid rgba\(245,200,66,0.2\)'\s*\}\}", 'className="text-yellow-600 bg-yellow-500/10 border border-yellow-500/20"'),
    (r"style=\{\{\s*background:\s*'#2a1a1a',\s*color:\s*'#f87171',\s*borderBottom:\s*'1px solid #3a2222'\s*\}\}", 'className="bg-destructive/10 text-destructive border-b border-destructive/20"'),
    (r"style=\{\{\s*background:\s*'#2a2010',\s*color:\s*'#a89070',\s*border:\s*'1px solid #3a3020'\s*\}\}", 'className="bg-muted text-muted-foreground border border-border"'),
    (r"style=\{\{\s*background:\s*'#2a2410',\s*color:\s*'#5a5040'\s*\}\}", 'className="bg-muted text-muted-foreground/50"'),
    (r"\?\s*\{\s*background:\s*'#ea5a0c',\s*color:\s*'#fff',\s*border:\s*'1px solid #ea5a0c'\s*\}\s*:\s*\{\s*background:\s*'transparent',\s*color:\s*'#a89070',\s*border:\s*'1px solid #3a3020'\s*\}", '? { className: "bg-primary text-primary-foreground border-primary" } : { className: "bg-transparent text-muted-foreground border-border" }'),
]

for old, new in replacements:
    content = re.sub(old, new, content)

with open(path, 'w') as f:
    f.write(content)
