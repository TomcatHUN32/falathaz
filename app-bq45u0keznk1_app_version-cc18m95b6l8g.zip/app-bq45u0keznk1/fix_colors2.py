import re
import os

path = '/workspace/app-bq45u0keznk1/src/pages/AdminDashboard.tsx'
with open(path, 'r') as f:
    content = f.read()

# Fixes
content = re.sub(
    r"style=\{\{\s*color:\s*isActive\s*\?\s*'#b5255e'\s*:\s*'#333'\s*\}\}",
    "className={isActive ? 'text-primary' : 'text-foreground'}",
    content
)

content = re.sub(
    r"style=\{\{\s*background:\s*'#fff',\s*borderBottom:\s*'1px solid #c5cacf'\s*\}\}",
    'className="bg-card border-b border-border shadow-[0_4px_12px_rgba(225,29,72,0.05)]"',
    content
)

content = re.sub(
    r"style=\{\{\s*color:\s*orderTypeFilter === t\.key\s*\?\s*'#b5255e'\s*:\s*'#666',\s*borderBottom:\s*orderTypeFilter === t\.key\s*\?\s*'2px solid #b5255e'\s*:\s*'2px solid transparent'\s*\}\}",
    "className={orderTypeFilter === t.key ? 'text-primary border-b-2 border-primary' : 'text-muted-foreground border-b-2 border-transparent'}",
    content
)

content = re.sub(
    r"style=\{\{\s*background:\s*'#dde1e6',\s*color:\s*'#555'\s*\}\}",
    'className="bg-muted text-muted-foreground"',
    content
)

content = re.sub(
    r"style=\{\{\s*color:\s*isActive\s*\?\s*'#b5255e'\s*:\s*'#777',\s*borderTop:\s*isActive\s*\?\s*'2px solid #b5255e'\s*:\s*'2px solid transparent'\s*\}\}",
    "className={isActive ? 'text-primary border-t-2 border-primary' : 'text-muted-foreground border-t-2 border-transparent'}",
    content
)

content = re.sub(r"style=\{\{\s*background:\s*'#b5255e'\s*\}\}", 'className="bg-primary"', content)
content = re.sub(r"className=\"w-px h-4 bg-\[#e2e6ea\] mx-2\"", 'className="w-px h-4 bg-border mx-2"', content)

with open(path, 'w') as f:
    f.write(content)
