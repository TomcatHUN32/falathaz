import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import User from './models/User.js';

const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/szesztestverek';

async function seed() {
  try {
    await mongoose.connect(MONGODB_URI);
    console.log('MongoDB connected');

    const passwordHash = await bcrypt.hash('123456', 10);

    // Admin user
    await User.findOneAndUpdate(
      { email: 'admin@test.com' },
      {
        name: 'Admin Teszt',
        password: passwordHash,
        phone: '+36301234567',
        role: 'admin',
        default_address: 'Budapest, Fő utca 1.',
        points: 150
      },
      { upsert: true, new: true }
    );

    // Customer user
    await User.findOneAndUpdate(
      { email: 'user@test.com' },
      {
        name: 'Vásárló Teszt',
        password: passwordHash,
        phone: '+36309876543',
        role: 'customer',
        default_address: 'Szuhogy, Fő út 12.',
        points: 20
      },
      { upsert: true, new: true }
    );

    console.log('Users created successfully! (admin@test.com / 123456, user@test.com / 123456)');
    process.exit(0);
  } catch (error) {
    console.error('Error seeding users:', error);
    process.exit(1);
  }
}

seed();