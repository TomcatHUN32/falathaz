import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
const __dirname = path.dirname(fileURLToPath(import.meta.url));
dotenv.config({ path: path.resolve(__dirname, '.env') });
import mongoose from 'mongoose';
import Coupon from './models/Coupon.js';
import Order from './models/Order.js';

async function run() {
  await mongoose.connect(process.env.MONGODB_URI);
  const c = await Coupon.findOne({ code: 'TESZT' });
  console.log('Coupon:', c);
  
  const orders = await Order.find({ coupon_code: 'TESZT' }).select('_id createdAt status');
  console.log('Orders with this coupon:', orders);
  
  process.exit(0);
}
run();
