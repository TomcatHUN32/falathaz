#!/usr/bin/env node
// Diagnosztikai script: ellenőrzi a MongoDB kapcsolatot és a usereket
import mongoose from 'mongoose';

const DB_URI = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/szesztestverek';

async function main() {
  try {
    await mongoose.connect(DB_URI);
    console.log('✅ MongoDB elérhető:', DB_URI);

    const db = mongoose.connection.db;
    const collections = await db.listCollections().toArray();
    console.log('\n📁 Collections:', collections.map(c => c.name).join(', ') || '(nincs egy sem)');

    const users = db.collection('users');
    const userCount = await users.countDocuments();
    console.log('\n👤 User count:', userCount);

    if (userCount > 0) {
      const allUsers = await users.find({}, { projection: { name: 1, email: 1, role: 1 } }).toArray();
      console.log('\n📋 Felhasználók:');
      for (const u of allUsers) {
        console.log(`  - ${u.name} <${u.email}> [${u.role}]`);
      }
    } else {
      console.log('\n⚠️  Az adatbázis üres! A seed adatokat be kell tölteni.');
    }
  } catch (err) {
    console.error('❌ MongoDB kapcsolat sikertelen:', err.message);
    console.log('\n💡 Tipp: ellenőrizd, hogy fut-e a MongoDB szerver a VPS-en:');
    console.log('   sudo systemctl status mongodb');
  } finally {
    await mongoose.disconnect();
  }
}
main();
