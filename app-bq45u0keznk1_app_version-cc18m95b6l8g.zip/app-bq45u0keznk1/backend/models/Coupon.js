import mongoose from 'mongoose';

import { als } from '../als.js';

const couponSchema = new mongoose.Schema({
  name: { type: String, required: true },
  code: { type: String, required: true, unique: true, uppercase: true },
  discount_pct: { type: Number, required: true, min: 0, max: 100 },
  active: { type: Boolean, default: true },
  max_uses: { type: Number, default: null },
  usage_count: { type: Number, default: 0 },
  used_by: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  restaurant_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Restaurant' }
}, { timestamps: true });

export default mongoose.model('Coupon', couponSchema);
