import mongoose from 'mongoose';

import { als } from '../als.js';

const orderItemSchema = new mongoose.Schema({
  product_id: { type: mongoose.Schema.Types.ObjectId, required: true },
  name: { type: String, required: true },
  quantity: { type: Number, required: true, min: 1 },
  price: { type: Number, required: true },
  packaging_fee: { type: Number, default: 0 },
  drs_applies: { type: Boolean, default: false },
  // Kiválasztott öntet-opciók (pl. [{group_id, group_name, option_id, option_name, price}])
  extras: [{
    group_id: { type: String, default: '' },
    group_name: { type: String, default: '' },
    option_id: { type: String, default: '' },
    option_name: { type: String, required: true },
    price: { type: Number, default: 0 },
  }],
  note: { type: String, default: '' }, // Tételszintű megjegyzés
});


const orderSchema = new mongoose.Schema({
  user_id: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  guest_name: { type: String, default: '' },
  items: [orderItemSchema],
  subtotal: { type: Number, required: true },
  packaging_total: { type: Number, default: 0 },
  drs_total: { type: Number, default: 0 },
  delivery_fee: { type: Number, default: 0 },
  total: { type: Number, required: true },
  used_points: { type: Number, default: 0 },
  earned_points: { type: Number, default: 0 },
  source: { type: String, default: 'weboldal' },
  payment_method: { type: String, enum: ['Készpénz', 'Bankkártya'], required: true },
  delivery_type: { type: String, enum: ['szállítás', 'elvitel', 'beülős'], default: 'szállítás' },
  status: {
    type: String,
    enum: ['pending', 'accepted', 'preparing', 'ready', 'delivering', 'delivered', 'cancelled'],
    default: 'pending',
  },
  address: { type: String, required: true },
  city_id: { type: mongoose.Schema.Types.ObjectId, ref: 'City', default: null },
  city_name: { type: String, default: '' },
  street: { type: String, default: '' },
  house_number: { type: String, default: '' },
  floor: { type: String, default: '' },
  door: { type: String, default: '' },
  bell: { type: String, default: '' },
  phone: { type: String, default: '' },
  notes: { type: String, default: '' },
  discount_pct: { type: Number, default: 0 },
  discount_amount: { type: Number, default: 0 },
  coupon_code: { type: String, default: '' },
  coupon_name: { type: String, default: '' },
  courier_id: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
  courier_status: {
    type: String,
    enum: ['assigned', 'accepted', 'at_kitchen', 'on_the_way', 'delivered'],
    default: null,
  },
  courier_started_at: { type: Date, default: null },
  restaurant_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Restaurant' }
}, { timestamps: true });

export default mongoose.model('Order', orderSchema);
