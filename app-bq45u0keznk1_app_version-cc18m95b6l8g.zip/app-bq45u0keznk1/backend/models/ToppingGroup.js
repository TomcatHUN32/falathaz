import mongoose from 'mongoose';

// Egy "öntet-csoport" pl.: "Öntet", "Mártás", "Extra feltét"
// Az options tömbben vannak a választható opciók nevükkel és árukkal.
import { als } from '../als.js';

const toppingOptionSchema = new mongoose.Schema({
  name: { type: String, required: true },   // pl. "Fokhagymás"
  price: { type: Number, default: 0 },      // 0 = ingyenes
}, { _id: true });


const toppingGroupSchema = new mongoose.Schema({
  name: { type: String, required: true },         // pl. "Öntet"
  required: { type: Boolean, default: false },    // kötelező-e választani
  min_select: { type: Number, default: 0 },       // minimum választható (0 = opcionális)
  max_select: { type: Number, default: 1 },       // max választható (1 = egyszeres)
  options: [toppingOptionSchema],
  restaurant_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Restaurant' }
}, { timestamps: true });

export default mongoose.model('ToppingGroup', toppingGroupSchema);
