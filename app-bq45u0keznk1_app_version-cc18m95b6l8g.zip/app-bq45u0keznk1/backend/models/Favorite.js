import mongoose from 'mongoose';

import { als } from '../als.js';

const favoriteSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  product: { type: mongoose.Schema.Types.ObjectId, ref: 'Product', required: true },
  restaurant_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Restaurant' }
}, { timestamps: true });

favoriteSchema.index({ user: 1, product: 1 }, { unique: true });

export default mongoose.model('Favorite', favoriteSchema);
