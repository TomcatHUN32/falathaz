import mongoose from 'mongoose';

import { als } from '../als.js';

const userSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  password: { type: String, required: true },
  phone: { type: String, default: '' },
  role: { type: String, enum: ['customer', 'admin', 'courier', 'superadmin'], default: 'customer' },
  default_address: { type: String, default: '' },
  points: { type: Number, default: 0 },
  restaurant_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Restaurant' }
}, { timestamps: true });

export default mongoose.model('User', userSchema);
