import mongoose from 'mongoose';

import { als } from '../als.js';

const citySchema = new mongoose.Schema({
  name: { type: String, required: true, unique: true },
  delivery_fee: { type: Number, required: true, default: 0, min: 0 },
  free_delivery_threshold: { type: Number, default: 0, min: 0 },
  active: { type: Boolean, default: true },
  restaurant_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Restaurant' }
}, { timestamps: true });

export default mongoose.model('City', citySchema);
