import mongoose from 'mongoose';

import { als } from '../als.js';

const reviewSchema = new mongoose.Schema({
  order_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Order', required: true, unique: true },
  user_id: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  rating: { type: Number, required: true, min: 1, max: 5 },
  // részletes értékelések
  food_rating: { type: Number, min: 1, max: 5, default: null },
  delivery_rating: { type: Number, min: 1, max: 5, default: null },
  comment: { type: String, default: '' },
  items: [{ type: String }], // rendelt ételek nevei
  restaurant_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Restaurant' }
}, { timestamps: true });

export default mongoose.model('Review', reviewSchema);
