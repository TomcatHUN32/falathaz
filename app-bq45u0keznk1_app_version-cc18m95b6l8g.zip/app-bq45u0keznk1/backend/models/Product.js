import mongoose from 'mongoose';

import { als } from '../als.js';

const productSchema = new mongoose.Schema({
  name: { type: String, required: true },
  description: { type: String, default: '' },
  price: { type: Number, required: true, min: 0 },
  original_price: { type: Number, default: null },
  category: { type: String, required: true },
  packaging_fee: { type: Number, default: 0, min: 0 },
  drs_applies: { type: Boolean, default: false },
  image: { type: String, default: '' },
  is_available: { type: Boolean, default: true },
  // Csatolt öntet-csoportok (pl. [{group_id, required, max_select}])
  topping_groups: {
    type: [Object],
    default: []
  },
  restaurant_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Restaurant' }
}, { timestamps: true });

export default mongoose.model('Product', productSchema);
