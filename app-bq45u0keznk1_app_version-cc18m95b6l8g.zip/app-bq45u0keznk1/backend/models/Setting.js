import mongoose from 'mongoose';

import { als } from '../als.js';

const settingSchema = new mongoose.Schema({
  key: { type: String, required: true, unique: true },
  value: { type: mongoose.Schema.Types.Mixed, required: true },
  restaurant_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Restaurant' }
}, { timestamps: true });

export default mongoose.model('Setting', settingSchema);
