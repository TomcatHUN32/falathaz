import mongoose from 'mongoose';

const restaurantSchema = new mongoose.Schema({
  name: { type: String, required: true },
  description: { type: String },
  county: { type: String, required: true },
  city: { type: String, required: true },
  address: { type: String, required: true },
  phone: { type: String },
  email: { type: String },
  active: { type: Boolean, default: true },
  license_type: { 
    type: String, 
    enum: ['monthly', 'quarterly', 'yearly', 'perpetual'], 
    default: 'monthly' 
  },
  license_expiry: { type: Date },
  opening_hours: {
    monday: { open: { type: String, default: '10:00' }, close: { type: String, default: '22:00' }, closed: { type: Boolean, default: false } },
    tuesday: { open: { type: String, default: '10:00' }, close: { type: String, default: '22:00' }, closed: { type: Boolean, default: false } },
    wednesday: { open: { type: String, default: '10:00' }, close: { type: String, default: '22:00' }, closed: { type: Boolean, default: false } },
    thursday: { open: { type: String, default: '10:00' }, close: { type: String, default: '22:00' }, closed: { type: Boolean, default: false } },
    friday: { open: { type: String, default: '10:00' }, close: { type: String, default: '23:00' }, closed: { type: Boolean, default: false } },
    saturday: { open: { type: String, default: '10:00' }, close: { type: String, default: '23:00' }, closed: { type: Boolean, default: false } },
    sunday: { open: { type: String, default: '10:00' }, close: { type: String, default: '22:00' }, closed: { type: Boolean, default: false } }
  }
}, { timestamps: true });

export default mongoose.model('Restaurant', restaurantSchema);
