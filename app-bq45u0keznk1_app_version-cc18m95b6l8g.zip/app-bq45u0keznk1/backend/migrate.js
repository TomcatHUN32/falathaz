import dotenv from 'dotenv';
dotenv.config();
import mongoose from 'mongoose';
import fs from 'fs';
import path from 'path';

// Import all models
import Restaurant from './models/Restaurant.js';
import City from './models/City.js';
import Coupon from './models/Coupon.js';
import Favorite from './models/Favorite.js';
import Order from './models/Order.js';
import Product from './models/Product.js';
import Setting from './models/Setting.js';
import ToppingGroup from './models/ToppingGroup.js';
import User from './models/User.js';
import Review from './models/Review.js';

async function run() {
  await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/szesztestverek');
  
  // 1. Create a default restaurant
  let defaultRest = await Restaurant.findOne({ name: 'Szesztestvérek Falatház' });
  if (!defaultRest) {
    defaultRest = await Restaurant.create({
      name: 'Szesztestvérek Falatház',
      county: 'Borsod-Abaúj-Zemplén',
      city: 'Szuhogy',
      address: 'Fő utca 1.',
      phone: '+36301234567',
      email: 'info@falathaz.hu',
      active: true,
      license_type: 'perpetual'
    });
    console.log('Created default restaurant:', defaultRest._id);
  } else {
    console.log('Default restaurant already exists:', defaultRest._id);
  }

  // 2. Assign this restaurant to all existing records that have no restaurant_id
  const models = [City, Coupon, Favorite, Order, Product, Setting, ToppingGroup, User, Review];
  
  for (const model of models) {
    const res = await model.updateMany(
      { restaurant_id: { $exists: false } },
      { $set: { restaurant_id: defaultRest._id } }
    );
    console.log(`Updated ${model.modelName}: ${res.modifiedCount} records`);
  }
  
  console.log('Migration completed.');
  process.exit(0);
}
run();
