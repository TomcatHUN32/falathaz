import jwt from 'jsonwebtoken';

const JWT_SECRET = process.env.JWT_SECRET || 'szesztestverek-secret-key-2024';

export function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Hozzáférés megtagadva. Kérjük, jelentkezzen be.' });
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ error: 'Érvénytelen vagy lejárt token.' });
    }
    req.user = user;
    next();
  });
}

export function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.user || (!roles.includes(req.user.role) && req.user.role !== 'superadmin')) {
      return res.status(403).json({ error: 'Nincs jogosultsága ehhez a művelethez.' });
    }
    next();
  };
}
