import { als } from '../als.js';

export const alsMiddleware = (req, res, next) => {
  const store = {
    restaurantId: req.headers['x-restaurant-id'] || null
  };
  als.run(store, () => {
    next();
  });
};
