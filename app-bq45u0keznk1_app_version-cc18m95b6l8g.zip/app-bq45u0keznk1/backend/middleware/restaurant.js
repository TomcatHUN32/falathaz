export const requireRestaurant = (req, res, next) => {
  const restaurantId = req.headers['x-restaurant-id'];
  if (!restaurantId) {
    return res.status(400).json({ error: 'Restaurant ID is required in headers.' });
  }
  req.restaurantId = restaurantId;
  next();
};

export const optionalRestaurant = (req, res, next) => {
  req.restaurantId = req.headers['x-restaurant-id'];
  next();
};
