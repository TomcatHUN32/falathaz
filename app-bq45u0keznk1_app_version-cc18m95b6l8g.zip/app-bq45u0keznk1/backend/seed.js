import bcrypt from 'bcryptjs';
import mongoose from 'mongoose';
import User from './models/User.js';
import Restaurant from './models/Restaurant.js';
import Product from './models/Product.js';
import City from './models/City.js';

export async function seedDatabase() {
  try {
    console.log('[Seed] Ellenőrzés...');
    const superAdminExists = await User.findOne({ email: 'superadmin@falathaz.hu' });
    if (superAdminExists) {
      console.log('[Seed] A teszt adatok már léteznek.');
      return;
    }

    console.log('[Seed] Teszt adatok generálása...');

    // 1. Super Admin
    const hashedSuperAdminPw = await bcrypt.hash('superadmin', 10);
    const superadmin = new User({
      name: 'Super Admin',
      email: 'superadmin@falathaz.hu',
      password: hashedSuperAdminPw,
      phone: '+36300000000',
      role: 'superadmin'
    });
    await superadmin.save();

    // 2. Restaurants
    const now = new Date();
    const nextYear = new Date();
    nextYear.setFullYear(now.getFullYear() + 1);

    const r1 = new Restaurant({
      name: 'Teszt Étterem 1',
      county: 'Budapest',
      city: 'Budapest',
      address: 'Teszt utca 1.',
      license_type: 'yearly',
      license_expiry: nextYear,
      active: true,
      description: 'Kiváló minőségű ételek Budapest szívében.'
    });
    await r1.save();

    const r2 = new Restaurant({
      name: 'Teszt Étterem 2',
      county: 'Pest',
      city: 'Érd',
      address: 'Teszt tér 2.',
      license_type: 'monthly',
      license_expiry: nextYear,
      active: true,
      description: 'Külvárosi ízek mesterfokon.'
    });
    await r2.save();

    // 3. Admin users
    const hashedAdminPw = await bcrypt.hash('admin123', 10);
    const admin1 = new User({
      name: 'Étterem 1 Admin',
      email: 'admin@teszt1.hu',
      password: hashedAdminPw,
      phone: '+36301111111',
      role: 'admin',
      restaurant_id: r1._id
    });
    await admin1.save();

    const admin2 = new User({
      name: 'Étterem 2 Admin',
      email: 'admin@teszt2.hu',
      password: hashedAdminPw,
      phone: '+36302222222',
      role: 'admin',
      restaurant_id: r2._id
    });
    await admin2.save();

    // 4. Courier & Customer
    const hashedOtherPw = await bcrypt.hash('futar123', 10);
    const futar = new User({
      name: 'Teszt Futár',
      email: 'futar@teszt.hu',
      password: hashedOtherPw,
      phone: '+36303333333',
      role: 'courier',
      restaurant_id: r1._id
    });
    await futar.save();

    const hashedVevoPw = await bcrypt.hash('vevo123', 10);
    const vevo = new User({
      name: 'Teszt Vásárló',
      email: 'vevo@teszt.hu',
      password: hashedVevoPw,
      phone: '+36304444444',
      role: 'customer'
    });
    await vevo.save();

    // 5. Some basic data for Restaurant 1
    const { als } = await import('./als.js');
    await new Promise(resolve => {
      als.run({ restaurantId: r1._id.toString() }, async () => {
        const p1 = new Product({
          name: 'Sajtburger',
          description: 'Marhahúspogácsa, sajt, uborka',
          price: 2500,
          category: 'Burgerek',
          image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=800&q=80',
          is_available: true
        });
        await p1.save();

        const c1 = new City({
          name: 'Budapest',
          zip_code: '1011',
          delivery_fee: 500,
          min_order_value: 2000,
          active: true
        });
        await c1.save();
        resolve(true);
      });
    });

    console.log('[Seed] Teszt adatok sikeresen létrehozva!');
  } catch (err) {
    console.error('[Seed] Hiba:', err);
  }
}
