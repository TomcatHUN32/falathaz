import express from 'express';
import Setting from '../models/Setting.js';
import { authenticateToken, requireRole } from '../middleware/auth.js';
import { computeAutoOpen } from '../server.js';

const router = express.Router();

router.get('/', async (req, res) => {
  try {
    const settings = await Setting.find();
    const result = {};
    for (const s of settings) {
      result[s.key] = s.value;
    }
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get('/:key', async (req, res) => {
  try {
    const setting = await Setting.findOne({ key: req.params.key });
    if (!setting) {
      if (req.params.key === 'loyalty_settings') {
        return res.json({
          vip_enabled: true,
          vip_price: 5000,
          points_multiplier: 1,
          bronze_threshold: 100,
          silver_threshold: 500,
          gold_threshold: 1000
        });
      }
      if (req.params.key === 'tables') {
        return res.json([]);
      }
      if (req.params.key === 'opening_hours') {
        return res.json({
          monday: { open: "08:00", close: "20:00" },
          tuesday: { open: "08:00", close: "20:00" },
          wednesday: { open: "08:00", close: "20:00" },
          thursday: { open: "08:00", close: "20:00" },
          friday: { open: "08:00", close: "22:00" },
          saturday: { open: "10:00", close: "22:00" },
          sunday: { open: "10:00", close: "20:00" }
        });
      }
      return res.status(404).json({ error: 'Beállítás nem található.' });
    }
    res.json(setting.value);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.put('/:key', authenticateToken, requireRole('admin'), async (req, res) => {
  try {
    let newValue = req.body;
    
    // Preserve last_auto_state when manual_override is updated
    if (req.params.key === 'manual_override') {
      const existing = await Setting.findOne({ key: 'manual_override' });
      if (existing && existing.value && existing.value.last_auto_state !== undefined) {
        newValue = { ...newValue, last_auto_state: existing.value.last_auto_state };
      }
    }

    const setting = await Setting.findOneAndUpdate(
      { key: req.params.key },
      { key: req.params.key, value: newValue },
      { new: true, upsert: true }
    );
    res.json(setting.value);
    // Nyitvatartás vagy override változásakor azonnal frissítjük az automatát
    if (req.params.key === 'opening_hours' || req.params.key === 'manual_override') {
      setImmediate(() => computeAutoOpen().catch(() => {}));
    }
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
