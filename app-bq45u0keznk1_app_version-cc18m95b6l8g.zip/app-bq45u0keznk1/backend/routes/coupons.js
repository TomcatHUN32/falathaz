import express from 'express';
import Coupon from '../models/Coupon.js';
import { authenticateToken, requireRole } from '../middleware/auth.js';

const router = express.Router();

// ── Összes kupon lekérése (admin) ─────────────────────────────────────────────
router.get('/', authenticateToken, requireRole('admin'), async (req, res) => {
  try {
    const coupons = await Coupon.find().sort({ createdAt: -1 });
    res.json(coupons);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Kupon létrehozása (admin) ─────────────────────────────────────────────────
router.post('/', authenticateToken, requireRole('admin'), async (req, res) => {
  try {
    const { name, code, discount_pct, max_uses } = req.body;
    if (!name || !code || discount_pct == null) {
      return res.status(400).json({ error: 'Név, kód és kedvezmény % kötelező.' });
    }
    const exists = await Coupon.findOne({ code: code.toUpperCase() });
    if (exists) {
      return res.status(400).json({ error: 'Ez a kuponkód már létezik.' });
    }
    const coupon = await Coupon.create({
      name,
      code: code.toUpperCase(),
      discount_pct,
      max_uses: max_uses || null,
    });
    res.status(201).json(coupon);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Kupon frissítése (admin) ──────────────────────────────────────────────────
router.put('/:id', authenticateToken, requireRole('admin'), async (req, res) => {
  try {
    const { name, code, discount_pct, active, max_uses } = req.body;
    const update = {};
    if (name !== undefined) update.name = name;
    if (code !== undefined) update.code = code.toUpperCase();
    if (discount_pct !== undefined) update.discount_pct = discount_pct;
    if (active !== undefined) update.active = active;
    if (max_uses !== undefined) update.max_uses = max_uses || null;

    const coupon = await Coupon.findByIdAndUpdate(req.params.id, { $set: update }, { new: true });
    if (!coupon) return res.status(404).json({ error: 'Kupon nem található.' });
    res.json(coupon);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Kupon törlése (admin) ─────────────────────────────────────────────────────
router.delete('/:id', authenticateToken, requireRole('admin'), async (req, res) => {
  try {
    await Coupon.findByIdAndDelete(req.params.id);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Kupon érvényesítése (bárki) ───────────────────────────────────────────────
router.get('/validate/:code', async (req, res) => {
  try {
    const coupon = await Coupon.findOne({ code: req.params.code.toUpperCase(), active: true });
    if (!coupon) {
      return res.status(404).json({ error: 'Érvénytelen kuponkód.' });
    }
    if (coupon.max_uses != null && coupon.usage_count >= coupon.max_uses) {
      return res.status(400).json({ error: 'A kupon felhasználási limitje elérve.' });
    }
    
    // Check if user has already used it (if authenticated)
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    if (token) {
      import('jsonwebtoken').then(({ default: jwt }) => {
        const JWT_SECRET = process.env.JWT_SECRET || 'szesztestverek-secret-key-2024';
        try {
          const decoded = jwt.verify(token, JWT_SECRET);
          const hasUsed = coupon.used_by && coupon.used_by.some(id => id.toString() === decoded.userId);
          if (hasUsed) {
            return res.status(400).json({ error: 'Ezt a kupont már felhasználtad.' });
          }
          res.json({
            name: coupon.name,
            code: coupon.code,
            discount_pct: coupon.discount_pct,
          });
        } catch(e) {
          // invalid token, just return
          res.json({
            name: coupon.name,
            code: coupon.code,
            discount_pct: coupon.discount_pct,
          });
        }
      });
      return;
    }

    res.json({
      name: coupon.name,
      code: coupon.code,
      discount_pct: coupon.discount_pct,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
