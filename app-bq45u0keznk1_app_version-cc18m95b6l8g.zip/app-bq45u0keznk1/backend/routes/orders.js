import express from 'express';
import Order from '../models/Order.js';
import User from '../models/User.js';
import City from '../models/City.js';
import Setting from '../models/Setting.js';
import Coupon from '../models/Coupon.js';
import { authenticateToken, requireRole } from '../middleware/auth.js';

const router = express.Router();

// ── Statikus GET route-ok (/:id elé!) ────────────────────────────────────────
router.get('/my', authenticateToken, async (req, res) => {
  try {
    const orders = await Order.find({ user_id: req.user.userId })
      .sort({ createdAt: -1 })
      .populate('user_id', 'name phone');
    res.json(orders);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get('/today', authenticateToken, requireRole('admin'), async (req, res) => {
  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    const orders = await Order.find({
      createdAt: { $gte: today, $lt: tomorrow },
    })
      .sort({ createdAt: -1 })
      .populate('user_id', 'name phone')
      .populate('courier_id', 'name phone');
    res.json(orders);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get('/all', authenticateToken, requireRole('admin'), async (req, res) => {
  try {
    const { from, to } = req.query;
    const filter = {};
    if (from || to) {
      filter.createdAt = {};
      if (from) filter.createdAt.$gte = new Date(from + 'T00:00:00.000Z');
      if (to) filter.createdAt.$lte = new Date(to + 'T23:59:59.999Z');
    }
    const orders = await Order.find(filter)
      .sort({ createdAt: -1 })
      .populate('user_id', 'name phone')
      .populate('courier_id', 'name phone');
    res.json(orders);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get('/courier/:courierId', authenticateToken, requireRole('courier', 'admin'), async (req, res) => {
  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    const orders = await Order.find({
      courier_id: req.params.courierId,
      createdAt: { $gte: today, $lt: tomorrow },
      status: { $in: ['ready', 'delivering', 'delivered'] },
    })
      .sort({ createdAt: -1 })
      .populate('user_id', 'name phone default_address lat lng');
    // address mező biztosítása minden rendelnél
    res.json(orders);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Rendelés létrehozása ──────────────────────────────────────────────────────
router.post('/', authenticateToken, requireRole('customer', 'admin'), async (req, res) => {
  try {
    const {
      items, payment_method, address, notes, user_id_override, guest_name,
      delivery_type, phone, city_id, city_name, street, house_number,
      floor, door, bell, discount_pct, coupon_code, coupon_name, source, used_points
    } = req.body;

    let subtotal = 0;
    let packaging_total = 0;
    let drs_total = 0;

    const isDineIn = delivery_type === 'beülős';

    for (const item of items) {
      subtotal += item.price * item.quantity;
      if (!isDineIn) {
        packaging_total += (item.packaging_fee || 0) * item.quantity;
      }
      if (item.drs_applies) {
        drs_total += 50 * item.quantity;
      }
    }

    // Minimum rendelési összeg csak online (customer) rendelésnél
    if (req.user.role === 'customer' && subtotal < 2500) {
      return res.status(400).json({ error: 'A minimum rendelési összeg 2500 Ft.' });
    }

    const isPickup = delivery_type === 'elvitel';

    // Szállítási díj: kizárólag város alapján (manuálisan beállított díjak)
    // Ingyenes szállítás ha a részösszeg eléri a beállított küszöböt
    let delivery_fee = 0;
    if (!isPickup && !isDineIn && city_id) {
      const city = await City.findById(city_id);
      if (city) delivery_fee = city.delivery_fee;
    }
    // Ingyenes szállítás ellenőrzése
    const freeDeliverySetting = await Setting.findOne({ key: 'free_delivery_threshold' });
    const freeThreshold = freeDeliverySetting?.value ?? 0;
    if (freeThreshold > 0 && subtotal >= freeThreshold) {
      delivery_fee = 0;
    }

    // Pontfelhasználás ellenőrzése (csak saját vásárló, nem pos vendég)
    let applied_points = 0;
    const isCustomer = req.user.role === 'customer' || (req.user.role === 'admin' && !guest_name && !user_id_override);
    const userIdToUse = user_id_override || req.user.userId;
    let customerUser = null;
    
    if (isCustomer && used_points > 0) {
      customerUser = await User.findById(userIdToUse);
      if (customerUser && customerUser.points >= used_points) {
        // Ellenőrizzük a maximum beállítást
        const ls = await Setting.findOne({ key: 'loyalty_settings' });
        const maxUsable = ls?.value?.points_usable_per_order || 1000;
        applied_points = Math.min(used_points, maxUsable, customerUser.points);
      }
    }

    // Kedvezmény számítása
    const discPct = Math.min(Math.max(Number(discount_pct) || 0, 0), 100);
    const discount_amount = Math.round((subtotal * discPct) / 100);

    let total = subtotal + packaging_total + drs_total + delivery_fee - discount_amount - applied_points;
    if (total < 0) total = 0;

    // Keresünk pontszorzót
    const ls = await Setting.findOne({ key: 'loyalty_settings' });
    const amountPerPoint = ls?.value?.amount_per_point || 100;
    const earned_points = isCustomer ? Math.floor(total / amountPerPoint) : 0;

    let couponDoc = null;
    if (coupon_code) {
      couponDoc = await Coupon.findOne({ code: coupon_code.toUpperCase(), active: true });
      if (couponDoc) {
        if (couponDoc.max_uses != null && couponDoc.usage_count >= couponDoc.max_uses) {
          return res.status(400).json({ error: 'A kupon felhasználási limitje elérve.' });
        }
        if (userIdToUse && couponDoc.used_by && couponDoc.used_by.some(id => id.toString() === userIdToUse.toString())) {
          return res.status(400).json({ error: 'Ezt a kupont már felhasználtad.' });
        }
      }
    }

    const orderData = {
      user_id: userIdToUse,
      items,
      subtotal,
      packaging_total,
      drs_total,
      delivery_fee,
      discount_pct: discPct,
      discount_amount,
      used_points: applied_points,
      earned_points,
      total,
      payment_method,
      delivery_type: delivery_type || 'szállítás',
      status: 'pending',
      address,
      notes: notes || '',
      source: source || 'weboldal',
    };

    if (guest_name) orderData.guest_name = guest_name;
    if (req.body.source) orderData.source = req.body.source;
    if (phone) orderData.phone = phone.trim();
    if (city_id) orderData.city_id = city_id;
    if (city_name) orderData.city_name = city_name;
    if (street) orderData.street = street;
    if (house_number) orderData.house_number = house_number;
    if (floor) orderData.floor = floor;
    if (door) orderData.door = door;
    if (bell) orderData.bell = bell;
    if (coupon_code) orderData.coupon_code = coupon_code;
    if (coupon_name) orderData.coupon_name = coupon_name;

    const order = await Order.create(orderData);
    
    // Kupon felhasználás adminisztrálása
    if (couponDoc) {
      couponDoc.usage_count += 1;
      if (userIdToUse) {
        couponDoc.used_by.push(userIdToUse);
      }
      await couponDoc.save();
    }

    // Vonjuk le a felhasznált pontokat a felhasználótól
    if (customerUser && applied_points > 0) {
      customerUser.points -= applied_points;
      await customerUser.save();
    }
    // (A megszerzett pontokat majd akkor kapja meg, ha a rendelés státusza 'delivered' lesz - bár a legegyszerűbb, ha most vagy delivery-kor adjuk.
    // Általában 'delivered' státuszkor adják, ezért a status update-ben kell megoldani, de egyelőre hagyjuk meg a modellt, majd a status update-ben beállítjuk.)

    const populated = await Order.findById(order._id).populate('user_id', 'name phone');
    res.status(201).json(populated);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Status update ─────────────────────────────────────────────────────────────
router.put('/:id/status', authenticateToken, requireRole('admin', 'courier'), async (req, res) => {
  try {
    const { status, courier_id, courier_status } = req.body;
    const update = {};
    if (status) update.status = status;
    if (courier_id === null) {
      update.courier_id = null;
      update.courier_status = null;
      update.$unset = { courier_started_at: 1 };
    } else if (courier_id !== undefined) {
      update.courier_id = courier_id;
    }
    
    if (courier_status !== undefined && courier_status !== null) {
      update.courier_status = courier_status;
      // Ha a futár elindult, rögzítjük az időpontot
      if (courier_status === 'on_the_way') {
        update.courier_started_at = new Date();
      }
    }

    const existingOrder = await Order.findById(req.params.id);
    if (!existingOrder) {
      return res.status(404).json({ error: 'Rendelés nem található.' });
    }

    const order = await Order.findByIdAndUpdate(req.params.id, update, { new: true })
      .populate('user_id', 'name phone default_address')
      .populate('courier_id', 'name phone');
    if (!order) {
      return res.status(404).json({ error: 'Rendelés nem található.' });
    }

    // Valós idejű értesítés a nyomkövetési oldalnak, az adminnak és a futárnak
    const io = req.io;
    if (io) {
      if (status) {
        const payload = { orderId: req.params.id, status };
        io.to(`order_${req.params.id}`).emit('order_status_update', payload);
        io.to('admins').emit('order_status_update', payload);
      }
      
      // Pontjóváírás teljesített rendelés esetén
      if (status === 'delivered' && order.earned_points > 0 && existingOrder.status !== 'delivered') {
        const u = await User.findById(order.user_id._id);
        if (u) {
          u.points = (u.points || 0) + order.earned_points;
          await u.save();
        }
      }

      // Ha futár lett hozzárendelve → küldjük el neki a teljes rendelést valós időben
      const assignedCourierId = courier_id || (order.courier_id ? order.courier_id._id?.toString() || order.courier_id.toString() : null);
      if (courier_id && assignedCourierId) {
        io.to(`courier_${assignedCourierId}`).emit('courier_order_assigned', order);
      }
    }

    res.json(order);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Egyedi rendelés lekérése — MINDIG az utolsó GET! ─────────────────────────
router.get('/:id', authenticateToken, async (req, res) => {
  try {
    const order = await Order.findById(req.params.id)
      .populate('user_id', 'name phone')
      .populate('courier_id', 'name phone');
    if (!order) {
      return res.status(404).json({ error: 'Rendelés nem található.' });
    }
    if (req.user.role === 'customer' && order.user_id._id.toString() !== req.user.userId) {
      return res.status(403).json({ error: 'Nincs jogosultsága.' });
    }
    res.json(order);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;

// ── Rendelés tételeinek szerkesztése (admin) ──────────────────────────────────
router.patch('/:id/items', authenticateToken, requireRole('admin'), async (req, res) => {
  try {
    const { items, notes, payment_method } = req.body;

    const existing = await Order.findById(req.params.id);
    if (!existing) return res.status(404).json({ error: 'Rendelés nem található.' });

    const isDineIn = existing.delivery_type === 'beülős';

    // Újraszámolás
    let subtotal = 0;
    let packaging_total = 0;
    let drs_total = 0;
    for (const item of items) {
      subtotal += item.price * item.quantity;
      if (!isDineIn) packaging_total += (item.packaging_fee || 0) * item.quantity;
      if (item.drs_applies) drs_total += 50 * item.quantity;
    }

    const delivery_fee = existing.delivery_fee || 0;
    const discount_pct = req.body.discount_pct !== undefined ? req.body.discount_pct : (existing.discount_pct || 0);
    const discount_amount = Math.round((subtotal * discount_pct) / 100);
    const total = subtotal + packaging_total + drs_total + delivery_fee - discount_amount;

    const update = { items, subtotal, packaging_total, drs_total, discount_amount, total };
    if (notes !== undefined) update.notes = notes;
    if (payment_method) update.payment_method = payment_method;
    if (req.body.phone !== undefined) update.phone = req.body.phone;
    if (req.body.guest_name !== undefined) update.guest_name = req.body.guest_name;
    if (req.body.delivery_type !== undefined) update.delivery_type = req.body.delivery_type;
    if (req.body.address !== undefined) update.address = req.body.address;
    if (req.body.city_id !== undefined) update.city_id = req.body.city_id;
    if (req.body.city_name !== undefined) update.city_name = req.body.city_name;
    if (req.body.street !== undefined) update.street = req.body.street;
    if (req.body.house_number !== undefined) update.house_number = req.body.house_number;
    if (req.body.floor !== undefined) update.floor = req.body.floor;
    if (req.body.door !== undefined) update.door = req.body.door;
    if (req.body.bell !== undefined) update.bell = req.body.bell;
    if (req.body.coupon_code !== undefined) update.coupon_code = req.body.coupon_code;
    if (req.body.coupon_name !== undefined) update.coupon_name = req.body.coupon_name;
    if (req.body.discount_pct !== undefined) update.discount_pct = req.body.discount_pct;

    const order = await Order.findByIdAndUpdate(req.params.id, update, { new: true })
      .populate('user_id', 'name phone')
      .populate('courier_id', 'name phone');

    // Socket értesítés adminnak
    const io = req.io;
    if (io) io.to('admins').emit('order_updated', { orderId: req.params.id, order });

    res.json(order);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
