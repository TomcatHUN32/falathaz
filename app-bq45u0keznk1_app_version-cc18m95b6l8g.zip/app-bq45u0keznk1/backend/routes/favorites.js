import express from 'express';
import { authenticateToken } from '../middleware/auth.js';
import Favorite from '../models/Favorite.js';
import Product from '../models/Product.js';

const router = express.Router();

// GET all favorites for the logged in user
router.get('/', authenticateToken, async (req, res) => {
  try {
    const favorites = await Favorite.find({ user: req.user.userId }).populate('product');
    res.json(favorites);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// ADD a favorite
router.post('/', authenticateToken, async (req, res) => {
  try {
    const { productId } = req.body;
    const exists = await Favorite.findOne({ user: req.user.userId, product: productId });
    if (exists) {
      return res.status(400).json({ message: 'Already in favorites' });
    }
    const favorite = await Favorite.create({ user: req.user.userId, product: productId });
    const populated = await favorite.populate('product');
    res.status(201).json(populated);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// REMOVE a favorite
router.delete('/:productId', authenticateToken, async (req, res) => {
  try {
    await Favorite.findOneAndDelete({ user: req.user.userId, product: req.params.productId });
    res.json({ message: 'Favorite removed' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

export default router;
