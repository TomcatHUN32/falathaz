import express from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import User from '../models/User.js';
import { authenticateToken } from '../middleware/auth.js';

const router = express.Router();
const JWT_SECRET = process.env.JWT_SECRET || 'szesztestverek-secret-key-2024';

router.post('/register', async (req, res) => {
  try {
    const { name, email, password, phone, default_address, lat, lng } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({ error: 'Név, e-mail cím és jelszó kötelező.' });
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({ error: 'Érvénytelen e-mail cím formátum.' });
    }

    const existing = await User.findOne({ email: email.toLowerCase() });
    if (existing) {
      return res.status(400).json({ error: 'Ez az e-mail cím már regisztrálva van.' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const user = await User.create({
      name,
      email: email.toLowerCase(),
      password: hashedPassword,
      phone: phone || '',
      role: 'customer',
      default_address: default_address || '',
      lat: lat || null,
      lng: lng || null,
    });

    const token = jwt.sign(
      { userId: user._id, role: user.role, name: user.name, email: user.email },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    res.status(201).json({
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        phone: user.phone,
        role: user.role,
        default_address: user.default_address,
        lat: user.lat,
        lng: user.lng,
        points: user.points,
        restaurant_id: user.restaurant_id
      },
    });
  } catch (err) {
    res.status(500).json({ error: 'Regisztráció sikertelen: ' + err.message });
  }
});

router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: 'E-mail cím és jelszó kötelező.' });
    }

    const user = await User.findOne({ email: email.toLowerCase() });
    if (!user) {
      return res.status(400).json({ error: 'Hibás e-mail cím vagy jelszó.' });
    }

    const valid = await bcrypt.compare(password, user.password);
    if (!valid) {
      return res.status(400).json({ error: 'Hibás e-mail cím vagy jelszó.' });
    }

    const token = jwt.sign(
      { userId: user._id, role: user.role, name: user.name, email: user.email },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    res.json({
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        phone: user.phone,
        role: user.role,
        default_address: user.default_address,
        lat: user.lat,
        lng: user.lng,
        points: user.points,
        restaurant_id: user.restaurant_id
      },
    });
  } catch (err) {
    res.status(500).json({ error: 'Bejelentkezés sikertelen: ' + err.message });
  }
});

router.get('/me', authenticateToken, async (req, res) => {
  try {
    const user = await User.findById(req.user.userId).select('-password');
    if (!user) {
      return res.status(404).json({ error: 'Felhasználó nem található.' });
    }
    res.json({
      id: user._id,
      name: user.name,
      email: user.email,
      phone: user.phone,
      role: user.role,
      default_address: user.default_address,
      lat: user.lat,
      lng: user.lng,
      points: user.points
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get('/search', authenticateToken, async (req, res) => {
  try {
    const { phone } = req.query;
    if (!phone) {
      return res.status(400).json({ error: 'Telefonszám szükséges.' });
    }

    // 1. Regisztrált felhasználó keresése
    const user = await User.findOne({ phone: { $regex: phone, $options: 'i' } }).select('-password');
    if (user) {
      return res.json({
        source: 'registered',
        id: user._id,
        name: user.name,
        phone: user.phone,
        role: user.role,
        default_address: user.default_address,
        lat: user.lat,
        lng: user.lng,
        order_count: null,
      });
    }

    // 2. Korábbi rendelés keresése telefonszám alapján
    const Order = (await import('../models/Order.js')).default;
    const lastOrder = await Order.findOne({
      phone: { $regex: phone, $options: 'i' },
      address: { $ne: 'Elvitel' },
    })
      .sort({ createdAt: -1 })
      .select('guest_name address phone city_name street house_number floor door bell')
      .lean();

    if (lastOrder) {
      const orderCount = await Order.countDocuments({ phone: { $regex: phone, $options: 'i' } });
      return res.json({
        source: 'order_history',
        id: null,
        name: lastOrder.guest_name || '',
        phone,
        role: 'guest',
        default_address: lastOrder.address || '',
        city_name: lastOrder.city_name || '',
        street: lastOrder.street || '',
        house_number: lastOrder.house_number || '',
        floor: lastOrder.floor || '',
        door: lastOrder.door || '',
        bell: lastOrder.bell || '',
        order_count: orderCount,
      });
    }

    // 3. Nincs találat
    res.json(null);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// PUT /api/auth/profile — saját profil frissítése (cím, koordináták, név, jelszó)
router.put('/profile', authenticateToken, async (req, res) => {
  try {
    const { name, default_address, lat, lng, current_password, new_password } = req.body;
    const updates = {};
    if (name !== undefined) updates.name = name;
    if (default_address !== undefined) updates.default_address = default_address;
    if (lat !== undefined) updates.lat = lat || null;
    if (lng !== undefined) updates.lng = lng || null;

    // Jelszócsere: ellenőrizzük a jelenlegi jelszót
    if (new_password) {
      if (!current_password) {
        return res.status(400).json({ error: 'A jelenlegi jelszó megadása kötelező.' });
      }
      const user = await User.findById(req.user.userId);
      if (!user) return res.status(404).json({ error: 'Felhasználó nem található.' });
      const valid = await bcrypt.compare(current_password, user.password);
      if (!valid) return res.status(400).json({ error: 'Hibás jelenlegi jelszó.' });
      updates.password = await bcrypt.hash(new_password, 10);
    }

    const user = await User.findByIdAndUpdate(
      req.user.userId,
      { $set: updates },
      { new: true }
    ).select('-password');

    if (!user) return res.status(404).json({ error: 'Felhasználó nem található.' });

    res.json({
      id: user._id,
      name: user.name,
      email: user.email,
      phone: user.phone,
      role: user.role,
      default_address: user.default_address,
      lat: user.lat,
      lng: user.lng,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Autocomplete: több találat (regisztrált + korábbi rendelés) ──
router.get('/search-suggestions', authenticateToken, async (req, res) => {
  try {
    const { phone } = req.query;
    if (!phone || String(phone).trim().length < 3) {
      return res.json([]);
    }
    const q = String(phone).trim();
    const regex = { $regex: q, $options: 'i' };

    const results = [];

    // Regisztrált felhasználók
    const users = await User.find({ phone: regex }).select('-password').limit(5);
    for (const u of users) {
      results.push({
        source: 'registered',
        id: u._id,
        name: u.name,
        phone: u.phone,
        address: u.default_address || '',
        city_name: '',
        street: '',
        house_number: '',
        floor: '',
        door: '',
        bell: '',
      });
    }

    // Korábbi rendelések — csoportosítva telefonszám szerint
    const Order = (await import('../models/Order.js')).default;
    const orderPhones = await Order.distinct('phone', { phone: regex });
    for (const p of orderPhones.slice(0, 10)) {
      if (results.some((r) => r.phone === p)) continue;
      const last = await Order.findOne({ phone: p })
        .sort({ createdAt: -1 })
        .select('guest_name address phone city_name street house_number floor door bell')
        .lean();
      if (last) {
        results.push({
          source: 'order_history',
          id: null,
          name: last.guest_name || '',
          phone: last.phone,
          address: last.address || '',
          city_name: last.city_name || '',
          street: last.street || '',
          house_number: last.house_number || '',
          floor: last.floor || '',
          door: last.door || '',
          bell: last.bell || '',
        });
      }
    }

    res.json(results.slice(0, 10));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
