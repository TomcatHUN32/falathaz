import express from 'express';
import Order from '../models/Order.js';
import Product from '../models/Product.js';
import Setting from '../models/Setting.js';
import { authenticateToken, requireRole } from '../middleware/auth.js';

const router = express.Router();

router.get('/stats', authenticateToken, requireRole('admin'), async (req, res) => {
  try {
    const { from, to } = req.query;
    const filter = {};
    if (from || to) {
      filter.createdAt = {};
      if (from) filter.createdAt.$gte = new Date(from + 'T00:00:00.000Z');
      if (to) filter.createdAt.$lte = new Date(to + 'T23:59:59.999Z');
    }

    const orders = await Order.find(filter);

    const topProducts = {};
    let foodRevenue = 0;
    let packagingRevenue = 0;
    let drsRevenue = 0;
    let cashRevenue = 0;
    let cardRevenue = 0;
    // Futár bevétel bontás
    let courierCashRevenue = 0;
    let courierCardRevenue = 0;
    // Rendelés típus bontás
    let deliveryCount = 0;
    let pickupCount = 0;
    let deliveryRevenue = 0;
    let pickupRevenue = 0;
    const hourlyData = {};

    for (const order of orders) {
      if (order.status === 'cancelled') continue; // sztornózott rendelések kihagyása
      foodRevenue += order.subtotal;
      packagingRevenue += order.packaging_total;
      drsRevenue += order.drs_total;
      if (order.payment_method === 'Készpénz') {
        cashRevenue += order.total;
      } else {
        cardRevenue += order.total;
      }

      // Futár bevétel: csak a futárhoz rendelt rendeléseknél
      if (order.courier_id) {
        if (order.payment_method === 'Készpénz') {
          courierCashRevenue += order.total;
        } else {
          courierCardRevenue += order.total;
        }
      }

      // Rendelés típus bontás
      if (order.delivery_type === 'elvitel') {
        pickupCount += 1;
        pickupRevenue += order.total;
      } else if (order.delivery_type === 'beülős') {
        deliveryCount += 1; // beülős a szállításhoz hasonlóan kezelve a statban
      } else {
        deliveryCount += 1;
        deliveryRevenue += order.total;
      }

      for (const item of order.items) {
        if (!topProducts[item.name]) {
          topProducts[item.name] = { name: item.name, quantity: 0, revenue: 0 };
        }
        topProducts[item.name].quantity += item.quantity;
        topProducts[item.name].revenue += item.price * item.quantity;
      }

      const hour = new Date(order.createdAt).getHours();
      if (!hourlyData[hour]) {
        hourlyData[hour] = { hour, orders: 0, revenue: 0 };
      }
      hourlyData[hour].orders += 1;
      hourlyData[hour].revenue += order.total;
    }

    const topProductsList = Object.values(topProducts)
      .sort((a, b) => b.quantity - a.quantity)
      .slice(0, 10);

    const hourlyList = Object.values(hourlyData).sort((a, b) => a.hour - b.hour);

    res.json({
      totalOrders: orders.filter((o) => o.status !== 'cancelled').length,
      totalRevenue: foodRevenue + packagingRevenue + drsRevenue,
      foodRevenue,
      packagingRevenue,
      drsRevenue,
      cashRevenue,
      cardRevenue,
      courierCashRevenue,
      courierCardRevenue,
      deliveryCount,
      pickupCount,
      deliveryRevenue,
      pickupRevenue,
      topProducts: topProductsList,
      hourlyData: hourlyList,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get('/couriers', authenticateToken, requireRole('admin'), async (req, res) => {
  try {
    const User = (await import('../models/User.js')).default;
    const couriers = await User.find({ role: 'courier' }).select('-password');
    const result = couriers.map((c) => ({
      id: c._id.toString(),
      _id: c._id.toString(),
      name: c.name,
      email: c.email,
      phone: c.phone,
      role: c.role,
      default_address: c.default_address,
      lat: c.lat,
      lng: c.lng,
    }));
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Futár létrehozása
router.post('/couriers', authenticateToken, requireRole('admin'), async (req, res) => {
  try {
    const { name, email, phone, password } = req.body;
    if (!name || !email || !password) {
      return res.status(400).json({ error: 'Név, e-mail és jelszó kötelező.' });
    }
    const bcrypt = (await import('bcryptjs')).default;
    const User = (await import('../models/User.js')).default;

    const existing = await User.findOne({ email: email.toLowerCase() });
    if (existing) {
      return res.status(400).json({ error: 'Ez az e-mail cím már regisztrálva van.' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const courier = await User.create({
      name,
      email: email.toLowerCase(),
      password: hashedPassword,
      phone: phone || '',
      role: 'courier',
      default_address: '',
    });

    res.status(201).json({
      id: courier._id.toString(),
      _id: courier._id.toString(),
      name: courier.name,
      email: courier.email,
      phone: courier.phone,
      role: courier.role,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Futár szerkesztése
router.put('/couriers/:id', authenticateToken, requireRole('admin'), async (req, res) => {
  try {
    const { name, email, phone, password } = req.body;
    const User = (await import('../models/User.js')).default;
    const update = {};
    if (name) update.name = name;
    if (email) update.email = email.toLowerCase();
    if (phone !== undefined) update.phone = phone;
    if (password) {
      const bcrypt = (await import('bcryptjs')).default;
      update.password = await bcrypt.hash(password, 10);
    }

    const courier = await User.findOneAndUpdate(
      { _id: req.params.id, role: 'courier' },
      update,
      { new: true }
    ).select('-password');

    if (!courier) return res.status(404).json({ error: 'Futár nem található.' });
    res.json({
      id: courier._id.toString(),
      _id: courier._id.toString(),
      name: courier.name,
      email: courier.email,
      phone: courier.phone,
      role: courier.role,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Futár törlése
router.delete('/couriers/:id', authenticateToken, requireRole('admin'), async (req, res) => {
  try {
    const User = (await import('../models/User.js')).default;
    const courier = await User.findOneAndDelete({ _id: req.params.id, role: 'courier' });
    if (!courier) return res.status(404).json({ error: 'Futár nem található.' });
    res.json({ message: 'Futár törölve.' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /admin/courier-daily — futár saját napi statisztika
router.get('/courier-daily', authenticateToken, requireRole('courier'), async (req, res) => {
  try {
    const Order = (await import('../models/Order.js')).default;
    const mongoose = (await import('mongoose')).default;

    const rawId = req.user.id;
    const courierId = mongoose.Types.ObjectId.isValid(rawId)
      ? new mongoose.Types.ObjectId(rawId)
      : null;

    const todayStart = new Date();
    todayStart.setHours(0, 0, 0, 0);
    const todayEnd = new Date();
    todayEnd.setHours(23, 59, 59, 999);

    // Szűrés: courier_id ObjectId vagy string, mai nap (updatedAt vagy createdAt)
    const idFilters = [{ courier_id: rawId.toString() }];
    if (courierId) idFilters.push({ courier_id: courierId });

    const orders = await Order.find({
      $and: [
        { $or: idFilters },
        { status: 'delivered' },
        { $or: [
          { updatedAt: { $gte: todayStart, $lte: todayEnd } },
          { createdAt: { $gte: todayStart, $lte: todayEnd } },
        ]},
      ],
    }).lean();

    let cashTotal = 0;
    let cardTotal = 0;

    for (const o of orders) {
      const pm = (o.payment_method || '').trim();
      if (pm === 'Készpénz') cashTotal += (o.total || 0);
      else cardTotal += (o.total || 0);
    }

    res.json({
      deliveredCount: orders.length,
      cashTotal,
      cardTotal,
      total: cashTotal + cardTotal,
      totalOrders: orders.length,
    });
  } catch (err) {
    console.error('[courier-daily] hiba:', err.message);
    res.status(500).json({ error: err.message });
  }
});

export default router;
