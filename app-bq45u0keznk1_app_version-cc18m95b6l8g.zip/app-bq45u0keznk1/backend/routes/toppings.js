import express from 'express';
import ToppingGroup from '../models/ToppingGroup.js';
import { authenticateToken, requireRole } from '../middleware/auth.js';

const router = express.Router();

// ── Összes öntet-csoport lekérése (publikus — rendelési oldalnak kell) ────────
router.get('/', async (req, res) => {
  try {
    const groups = await ToppingGroup.find().sort({ createdAt: 1 });
    res.json(groups);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Új öntet-csoport létrehozása ──────────────────────────────────────────────
router.post('/', authenticateToken, requireRole('admin'), async (req, res) => {
  try {
    const group = await ToppingGroup.create(req.body);
    res.status(201).json(group);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Öntet-csoport módosítása ──────────────────────────────────────────────────
router.put('/:id', authenticateToken, requireRole('admin'), async (req, res) => {
  try {
    const group = await ToppingGroup.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!group) return res.status(404).json({ error: 'Öntet-csoport nem található.' });
    res.json(group);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Öntet-csoport törlése ─────────────────────────────────────────────────────
router.delete('/:id', authenticateToken, requireRole('admin'), async (req, res) => {
  try {
    const group = await ToppingGroup.findByIdAndDelete(req.params.id);
    if (!group) return res.status(404).json({ error: 'Öntet-csoport nem található.' });
    res.json({ message: 'Törölve.' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
