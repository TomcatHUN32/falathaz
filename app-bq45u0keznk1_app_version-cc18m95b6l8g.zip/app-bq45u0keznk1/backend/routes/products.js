import express from 'express';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import crypto from 'crypto';
import Product from '../models/Product.js';
import { authenticateToken, requireRole } from '../middleware/auth.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const UPLOADS_DIR = path.join(__dirname, '..', 'uploads');

const router = express.Router();

router.get('/', async (req, res) => {
  try {
    // Minden termék visszaküldése — a frontend kezeli a nem elérhető megjelenítést
    const filter = {};
    const products = await Product.find(filter)
      .sort({ category: 1, name: 1 })
      .populate('topping_groups.group_id');
    res.json(products);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/', authenticateToken, requireRole('admin'), async (req, res) => {
  try {
    const product = await Product.create(req.body);
    res.status(201).json(product);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.put('/:id', authenticateToken, requireRole('admin'), async (req, res) => {
  try {
    const product = await Product.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!product) {
      return res.status(404).json({ error: 'Termék nem található.' });
    }
    res.json(product);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// PATCH /:id/availability — gyors elérhetőség kapcsoló
router.patch('/:id/availability', authenticateToken, requireRole('admin'), async (req, res) => {
  try {
    const { is_available } = req.body;
    if (typeof is_available !== 'boolean') {
      return res.status(400).json({ error: 'is_available mező kötelező (boolean).' });
    }
    const product = await Product.findByIdAndUpdate(
      req.params.id,
      { is_available },
      { new: true }
    );
    if (!product) return res.status(404).json({ error: 'Termék nem található.' });
    res.json(product);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.delete('/:id', authenticateToken, requireRole('admin'), async (req, res) => {
  try {
    const product = await Product.findByIdAndDelete(req.params.id);
    if (!product) {
      return res.status(404).json({ error: 'Termék nem található.' });
    }
    res.json({ message: 'Termék törölve.' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Képfeltöltés (base64 JSON) ────────────────────────────────────────────────
// POST /api/products/upload-image  { data: "data:image/jpeg;base64,..." }
router.post('/upload-image', authenticateToken, requireRole('admin'), async (req, res) => {
  try {
    const { data } = req.body;
    if (!data || typeof data !== 'string') {
      return res.status(400).json({ error: 'Hiányzó képadat.' });
    }

    // Formátum: "data:<mime>;base64,<adatok>"
    const match = data.match(/^data:(image\/(jpeg|jpg|png|webp|gif));base64,(.+)$/);
    if (!match) {
      return res.status(400).json({ error: 'Csak JPEG, PNG, WebP vagy GIF formátum engedélyezett.' });
    }

    const ext = match[2] === 'jpeg' ? 'jpg' : match[2];
    const base64Data = match[3];
    const buffer = Buffer.from(base64Data, 'base64');

    // Max 5 MB
    if (buffer.length > 5 * 1024 * 1024) {
      return res.status(400).json({ error: 'A kép mérete maximum 5 MB lehet.' });
    }

    const filename = `${crypto.randomUUID()}.${ext}`;
    const filepath = path.join(UPLOADS_DIR, filename);
    fs.writeFileSync(filepath, buffer);

    res.json({ url: `/uploads/${filename}` });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
