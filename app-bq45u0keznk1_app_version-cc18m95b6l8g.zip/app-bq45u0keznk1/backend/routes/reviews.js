import express from 'express';
import Review from '../models/Review.js';
import Order from '../models/Order.js';
import { authenticateToken, requireRole } from '../middleware/auth.js';

const router = express.Router();

// POST /api/reviews — rendelés értékelése (csak vevő, csak lezárt rendelés)
router.post('/', authenticateToken, requireRole('customer', 'admin'), async (req, res) => {
  try {
    const { order_id, rating, food_rating, delivery_rating, comment } = req.body;

    if (!order_id || !rating || rating < 1 || rating > 5) {
      return res.status(400).json({ error: 'Érvénytelen adatok. A csillag értékelés 1–5 között kell legyen.' });
    }

    // ellenőrzés: a rendelés létezik és lezárt
    const order = await Order.findById(order_id);
    if (!order) return res.status(404).json({ error: 'Rendelés nem található.' });
    if (order.status !== 'delivered') {
      return res.status(400).json({ error: 'Csak lezárt rendelés értékelhető.' });
    }
    // tulajdonos ellenőrzés
    if (order.user_id.toString() !== req.user.userId) {
      return res.status(403).json({ error: 'Nincs jogosultságod ezt a rendelést értékelni.' });
    }

    // duplikált értékelés tiltás
    const existing = await Review.findOne({ order_id });
    if (existing) {
      return res.status(409).json({ error: 'Ezt a rendelést már értékelted.' });
    }

    const items = order.items.map((i) => i.name);
    const review = await Review.create({
      order_id,
      user_id: req.user.userId,
      rating,
      food_rating: food_rating || null,
      delivery_rating: delivery_rating || null,
      comment: comment || '',
      items,
    });

    res.status(201).json(review);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/reviews/order/:orderId — egy rendelés értékelése
router.get('/order/:orderId', authenticateToken, async (req, res) => {
  try {
    const review = await Review.findOne({ order_id: req.params.orderId })
      .populate('user_id', 'name');
    res.json(review);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/reviews — összes értékelés (admin)
router.get('/', authenticateToken, requireRole('admin'), async (req, res) => {
  try {
    const reviews = await Review.find()
      .populate('user_id', 'name phone')
      .populate('order_id', 'total createdAt')
      .sort({ createdAt: -1 })
      .limit(100);
    res.json(reviews);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/reviews/stats — összesített statisztikák (admin)
router.get('/stats', authenticateToken, requireRole('admin'), async (req, res) => {
  try {
    const total = await Review.countDocuments();
    if (total === 0) return res.json({ total: 0, avgRating: 0, avgFood: 0, avgDelivery: 0, distribution: [0,0,0,0,0] });

    const agg = await Review.aggregate([
      {
        $group: {
          _id: null,
          avgRating: { $avg: '$rating' },
          avgFood: { $avg: '$food_rating' },
          avgDelivery: { $avg: '$delivery_rating' },
        }
      }
    ]);

    const dist = await Review.aggregate([
      { $group: { _id: '$rating', count: { $sum: 1 } } },
    ]);
    const distribution = [1,2,3,4,5].map((star) => {
      const found = dist.find((d) => d._id === star);
      return found ? found.count : 0;
    });

    res.json({
      total,
      avgRating: agg[0]?.avgRating ? Math.round(agg[0].avgRating * 10) / 10 : 0,
      avgFood: agg[0]?.avgFood ? Math.round(agg[0].avgFood * 10) / 10 : 0,
      avgDelivery: agg[0]?.avgDelivery ? Math.round(agg[0].avgDelivery * 10) / 10 : 0,
      distribution,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
