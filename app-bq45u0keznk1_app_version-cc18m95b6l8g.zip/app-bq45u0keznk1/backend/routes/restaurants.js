import express from 'express';
import Restaurant from '../models/Restaurant.js';
import { authenticateToken, requireRole } from '../middleware/auth.js';

const router = express.Router();

// Get active restaurants (public - for Step 2)
router.get('/public', async (req, res) => {
  try {
    const { county, city } = req.query;
    const filter = { active: true };
    if (county) filter.county = county;
    if (city) filter.city = city;
    
    const now = new Date();
    // Only return restaurants with active licenses
    filter.$or = [
      { license_type: 'perpetual' },
      { license_expiry: { $gte: now } }
    ];

    const restaurants = await Restaurant.find(filter).sort({ name: 1 }).lean();
    
    // Evaluate open status for each
    const Setting = (await import('../models/Setting.js')).default;
    const resWithStatus = [];
    for (const r of restaurants) {
      const overrideSetting = await Setting.findOne({ restaurant_id: r._id, key: 'manual_override' });
      r.is_open = overrideSetting?.value?.is_open ?? false;
      resWithStatus.push(r);
    }
    
    res.json(resWithStatus);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get all restaurants (superadmin only)
router.get('/', authenticateToken, requireRole('superadmin'), async (req, res) => {
  try {
    const restaurants = await Restaurant.find().sort({ createdAt: -1 });
    res.json(restaurants);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get single restaurant (public)
router.get('/:id', async (req, res) => {
  try {
    const restaurant = await Restaurant.findById(req.params.id);
    if (!restaurant) return res.status(404).json({ error: 'Étterem nem található.' });
    res.json(restaurant);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Create restaurant (superadmin only)
router.post('/', authenticateToken, requireRole('superadmin'), async (req, res) => {
  try {
    const restaurant = await Restaurant.create(req.body);
    res.status(201).json(restaurant);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Update restaurant (superadmin only)
router.put('/:id', authenticateToken, requireRole('superadmin'), async (req, res) => {
  try {
    const restaurant = await Restaurant.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!restaurant) return res.status(404).json({ error: 'Étterem nem található.' });
    res.json(restaurant);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Delete restaurant (superadmin only)
router.delete('/:id', authenticateToken, requireRole('superadmin'), async (req, res) => {
  try {
    await Restaurant.findByIdAndDelete(req.params.id);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
