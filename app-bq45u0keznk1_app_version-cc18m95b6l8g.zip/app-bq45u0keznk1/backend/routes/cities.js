import express from 'express';
import City from '../models/City.js';
import { authenticateToken, requireRole } from '../middleware/auth.js';

const router = express.Router();

// Publikus: összes aktív város (frontend rendeléshez)
router.get('/', async (req, res) => {
  try {
    const cities = await City.find({ active: true }).sort({ name: 1 });
    res.json(cities);
  } catch (err) {
    res.status(500).json({ error: 'Városok lekérdezése sikertelen' });
  }
});

// Admin: összes város (aktív és inaktív is)
router.get('/all', authenticateToken, requireRole("admin"), async (req, res) => {
  try {
    const cities = await City.find().sort({ name: 1 });
    res.json(cities);
  } catch (err) {
    res.status(500).json({ error: 'Városok lekérdezése sikertelen' });
  }
});

// Admin: új város létrehozása
router.post('/', authenticateToken, requireRole("admin"), async (req, res) => {
  try {
    const { name, delivery_fee, free_delivery_threshold, active } = req.body;
    if (!name || name.trim().length < 2) {
      return res.status(400).json({ error: 'A város neve legalább 2 karakter legyen' });
    }
    const fee = Number(delivery_fee ?? 0);
    if (isNaN(fee) || fee < 0) {
      return res.status(400).json({ error: 'A szállítási díj nem lehet negatív' });
    }
    const threshold = Number(free_delivery_threshold ?? 0);
    if (isNaN(threshold) || threshold < 0) {
      return res.status(400).json({ error: 'Az ingyenes szállítási küszöb nem lehet negatív' });
    }
    const city = new City({ 
      name: name.trim(), 
      delivery_fee: fee, 
      free_delivery_threshold: threshold,
      active: active ?? true 
    });
    await city.save();
    res.status(201).json(city);
  } catch (err) {
    if (err.code === 11000) {
      return res.status(409).json({ error: 'Ez a városnév már létezik' });
    }
    res.status(500).json({ error: 'Város létrehozása sikertelen' });
  }
});

// Admin: város szerkesztése
router.put('/:id', authenticateToken, requireRole("admin"), async (req, res) => {
  try {
    const { name, delivery_fee, free_delivery_threshold, active } = req.body;
    const update = {};
    if (name !== undefined) {
      if (name.trim().length < 2) {
        return res.status(400).json({ error: 'A város neve legalább 2 karakter legyen' });
      }
      update.name = name.trim();
    }
    if (delivery_fee !== undefined) {
      const fee = Number(delivery_fee);
      if (isNaN(fee) || fee < 0) {
        return res.status(400).json({ error: 'A szállítási díj nem lehet negatív' });
      }
      update.delivery_fee = fee;
    }
    if (free_delivery_threshold !== undefined) {
      const threshold = Number(free_delivery_threshold);
      if (isNaN(threshold) || threshold < 0) {
        return res.status(400).json({ error: 'Az ingyenes szállítási küszöb nem lehet negatív' });
      }
      update.free_delivery_threshold = threshold;
    }
    if (active !== undefined) update.active = active;

    const city = await City.findByIdAndUpdate(req.params.id, update, { new: true, runValidators: true });
    if (!city) return res.status(404).json({ error: 'Város nem található' });
    res.json(city);
  } catch (err) {
    if (err.code === 11000) {
      return res.status(409).json({ error: 'Ez a városnév már létezik' });
    }
    res.status(500).json({ error: 'Város szerkesztése sikertelen' });
  }
});

// Admin: város törlése
router.delete('/:id', authenticateToken, requireRole("admin"), async (req, res) => {
  try {
    const city = await City.findByIdAndDelete(req.params.id);
    if (!city) return res.status(404).json({ error: 'Város nem található' });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'Város törlése sikertelen' });
  }
});

export default router;
