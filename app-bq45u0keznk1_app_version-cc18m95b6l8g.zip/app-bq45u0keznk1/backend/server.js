import express from 'express';
import cors from 'cors';
import { createServer } from 'http';
import { Server } from 'socket.io';
import mongoose from 'mongoose';
import { als } from './als.js';
import { seedDatabase } from './seed.js';

// Mongoose global plugin for multi-tenant filtering
mongoose.plugin((schema) => {
  const addRestaurantFilter = function(next) {
    const store = als.getStore();
    // Do not filter Restaurant model itself or models that shouldn't be filtered globally
    if (this.model && this.model.modelName === 'Restaurant') {
      return next();
    }
    if (store && store.restaurantId) {
      if (this.getQuery) {
        // Only override if restaurant_id is not already provided
        const query = this.getQuery();
        if (query.restaurant_id === undefined) {
          this.where({ restaurant_id: store.restaurantId });
        }
      }
    }
    next();
  };

  schema.pre('find', addRestaurantFilter);
  schema.pre('findOne', addRestaurantFilter);
  schema.pre('countDocuments', addRestaurantFilter);
  schema.pre('findOneAndUpdate', addRestaurantFilter);
  schema.pre('updateMany', addRestaurantFilter);
  schema.pre('updateOne', addRestaurantFilter);

  schema.pre('save', function(next) {
    const store = als.getStore();
    if (this.constructor.modelName !== 'Restaurant' && store && store.restaurantId && !this.restaurant_id) {
      this.restaurant_id = store.restaurantId;
    }
    next();
  });
});

import path from 'path';
import { fileURLToPath } from 'url';

import authRoutes from './routes/auth.js';
import productRoutes from './routes/products.js';
import orderRoutes from './routes/orders.js';
import adminRoutes from './routes/admin.js';
import settingRoutes from './routes/settings.js';
import reviewRoutes from './routes/reviews.js';
import toppingRoutes from './routes/toppings.js';
import cityRoutes from './routes/cities.js';
import couponRoutes from './routes/coupons.js';
import favoriteRoutes from './routes/favorites.js';
import userRoutes from './routes/user.js';
import restaurantsRouter from './routes/restaurants.js';
import { alsMiddleware } from './middleware/als.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const app = express();
const httpServer = createServer(app);
const io = new Server(httpServer, {
  cors: { origin: '*', methods: ['GET', 'POST'] },
});

app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(alsMiddleware);

// Feltöltött képek statikus kiszolgálása
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// MongoDB kapcsolat

async function startDB() {
  let mongoUri = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/szesztestverek';
  try {
    await mongoose.connect(mongoUri, { serverSelectionTimeoutMS: 2000 });
    console.log('Valódi MongoDB csatlakozva:', mongoUri);
  } catch (err) {
    console.warn('Helyi MongoDB nem elérhető, beépített memóriás adatbázis indul (FIGYELEM: Újraindításkor minden adat elvész!)');
    const { MongoMemoryServer } = await import('mongodb-memory-server');
    const mongoServer = await MongoMemoryServer.create();
    mongoUri = mongoServer.getUri();
    await mongoose.connect(mongoUri);
    console.log('MongoDB Memory Server csatlakozva:', mongoUri);
  }
  
  try {
    await seedDatabase();

    startAutoSchedule();
  } catch (err) {
    console.error('MongoDB hiba:', err);
  }
}

startDB();

// ──────────────────────────────────────────────────────────────
// Automatikus nyitás/zárás — backend-en fut, admin nélkül is
// Budapest időzóna (Europe/Budapest) alapján számol
// ──────────────────────────────────────────────────────────────

const TIMEZONE = 'Europe/Budapest';

/** Visszaadja a jelenlegi Budapest időt { hours, minutes, dayIndex } */
function getBudapestNow() {
  const now = new Date();
  const parts = new Intl.DateTimeFormat('en-GB', {
    timeZone: TIMEZONE,
    hour: 'numeric', minute: 'numeric',
    weekday: 'short',
    hour12: false,
  }).formatToParts(now);
  const get = (type) => parts.find(p => p.type === type)?.value ?? '0';
  const WEEKDAY_MAP = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 };
  const h = parseInt(get('hour'), 10);
  const m = parseInt(get('minute'), 10);
  const wday = get('weekday');
  return { hours: h, minutes: m, dayIndex: WEEKDAY_MAP[wday] ?? now.getDay() };
}

/** Meghatározza, hogy NYITVA kellene lennie-e most az ütemezés alapján */
function computeShouldBeOpen(hours) {
  if (!hours) return false;
  const DAY_KEYS = ['sunday','monday','tuesday','wednesday','thursday','friday','saturday'];
  const { hours: h, minutes: m, dayIndex } = getBudapestNow();
  const dayKey = DAY_KEYS[dayIndex];
  const dayHours = hours[dayKey];
  if (!dayHours?.open || !dayHours?.close) return false;

  const nowMins = h * 60 + m;
  const [openH, openM] = dayHours.open.split(':').map(Number);
  const [closeH, closeM] = dayHours.close.split(':').map(Number);
  const openMins = openH * 60 + openM;
  const closeMins = closeH * 60 + closeM;

  // Éjfél átnyúló nyitvatartás támogatása (pl. 22:00 – 02:00)
  if (closeMins <= openMins) {
    return nowMins >= openMins || nowMins < closeMins;
  }
  return nowMins >= openMins && nowMins < closeMins;
}

export async function computeAutoOpen() {
  try {
    const Restaurant = (await import('./models/Restaurant.js')).default;
    const Setting = (await import('./models/Setting.js')).default;

    const restaurants = await Restaurant.find({ active: true });
    
    for (const rest of restaurants) {
      // Setup ALS context for this restaurant
      await new Promise((resolve) => {
        import('./als.js').then(({ als }) => {
          als.run({ restaurantId: rest._id.toString() }, async () => {
            const [hoursSetting, overrideSetting] = await Promise.all([
              Setting.findOne({ key: 'opening_hours' }),
              Setting.findOne({ key: 'manual_override' }),
            ]);
            if (!hoursSetting) return resolve(true);

            const shouldBeOpen = computeShouldBeOpen(hoursSetting.value);
            const override = overrideSetting?.value || {};
            const currentIsOpen = override.is_open ?? false;
            const forceManual = override.force_manual ?? false;
            const lastAutoState = override.last_auto_state ?? shouldBeOpen;

            if (forceManual && shouldBeOpen !== lastAutoState) {
              await Setting.findOneAndUpdate(
                { key: 'manual_override' },
                { key: 'manual_override', value: { is_open: shouldBeOpen, force_manual: false, last_auto_state: shouldBeOpen } },
                { upsert: true, new: true }
              );
              io.emit('auto_open_changed', { restaurantId: rest._id.toString(), is_open: shouldBeOpen, auto: true, reason: 'auto_schedule' });
            } else if (!forceManual) {
              if (shouldBeOpen !== currentIsOpen || shouldBeOpen !== lastAutoState) {
                await Setting.findOneAndUpdate(
                  { key: 'manual_override' },
                  { key: 'manual_override', value: { is_open: shouldBeOpen, force_manual: false, last_auto_state: shouldBeOpen } },
                  { upsert: true, new: true }
                );
                io.emit('auto_open_changed', { restaurantId: rest._id.toString(), is_open: shouldBeOpen, auto: true, reason: 'auto_schedule' });
              }
            }
            resolve(true);
          });
        });
      });
    }
  } catch (err) {
    console.error('[AutoSchedule] Hiba:', err.message);
  }
}

function startAutoSchedule() {
  computeAutoOpen();
  setInterval(computeAutoOpen, 15_000);
  const { hours: h, minutes: m } = getBudapestNow();
  console.log(`[AutoSchedule] Elindítva — Budapest idő: ${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}, 15 mp-enkénti ellenőrzés`);
}

// API routes
app.use('/api/restaurants', restaurantsRouter);
app.use('/api/auth', authRoutes);
app.use('/api/products', productRoutes);
app.use('/api/orders', (req, _res, next) => { req.io = io; next(); }, orderRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/settings', settingRoutes);
app.use('/api/reviews', reviewRoutes);
app.use('/api/toppings', toppingRoutes);
app.use('/api/cities', cityRoutes);
app.use('/api/coupons', couponRoutes);
app.use('/api/favorites', favoriteRoutes);
app.use('/api/users', userRoutes);

// Socket.io
io.on('connection', (socket) => {
  console.log('Socket csatlakozott:', socket.id);

  socket.on('join_admin', () => {
    socket.join('admins');
    console.log('Admin csatlakozott:', socket.id);
  });

  socket.on('join_customer', (orderId) => {
    socket.join(`order_${orderId}`);
    console.log('Vendég csatlakozott rendeléshez:', orderId);
  });

  socket.on('join_courier', (courierId) => {
    socket.join(`courier_${courierId}`);
    socket.data.courierId = courierId;
    console.log('Futár csatlakozott:', courierId);
  });

  socket.on('new_order', (order) => {
    io.to('admins').emit('new_order', order);
  });

  socket.on('order_status_update', (data) => {
    io.to(`order_${data.orderId}`).emit('order_status_update', data);
    io.to('admins').emit('order_status_update', data);
  });

  socket.on('courier_location', async (data) => {
    if (data.orderId) {
      io.to(`order_${data.orderId}`).emit('courier_location', data);
    }
    io.to('admins').emit('courier_location', data);
    if (data.orderId) {
      try {
        const Order = (await import('./models/Order.js')).default;
        await Order.findByIdAndUpdate(data.orderId, {
          courier_location: { lat: data.lat, lng: data.lng, updated_at: new Date() }
        });
      } catch (e) {
        // silent fail
      }
    }
  });

  socket.on('courier_finished_work', (data) => {
    io.to('admins').emit('courier_finished_work', {
      courierId: data.courierId,
      courierName: data.courierName,
      timestamp: new Date().toISOString(),
    });
  });

  socket.on('chat_to_courier', (data) => {
    io.to(`courier_${data.courierId}`).emit('chat_message', {
      from: 'admin',
      senderName: data.senderName || 'Admin',
      message: data.message,
      timestamp: data.timestamp || new Date().toISOString(),
    });
    io.to('admins').emit('chat_message_echo', {
      courierId: data.courierId,
      from: 'admin',
      senderName: data.senderName || 'Admin',
      message: data.message,
      timestamp: data.timestamp || new Date().toISOString(),
    });
  });

  socket.on('chat_to_admin', (data) => {
    io.to('admins').emit('chat_message_from_courier', {
      courierId: data.courierId,
      from: 'courier',
      senderName: data.courierName || 'Futár',
      message: data.message,
      timestamp: data.timestamp || new Date().toISOString(),
    });
  });

  socket.on('gps_started', (data) => {
    io.to('admins').emit('courier_gps_started', data);
  });

  socket.on('disconnect', () => {
    console.log('Socket lecsatlakozott:', socket.id);
  });
});

// Globális io elérhetővé tétele az API route-ok számára
app.set('io', io);

const PORT = process.env.PORT || 3001;
httpServer.listen(PORT, () => {
  console.log(`Szerver fut a ${PORT} porton`);
});
