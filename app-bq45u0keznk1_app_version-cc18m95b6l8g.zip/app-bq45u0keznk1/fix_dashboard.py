import sys

path = '/workspace/app-bq45u0keznk1/src/pages/AdminDashboard.tsx'
with open(path, 'r') as f:
    content = f.read()

# Fix CrmPosPanel
old_crm = '''<CrmPosPanel
            products={products}
            toppingGroups={toppingGroups}
            onOrderCreated={handleCrmOrderCreated}
            manualOverride={manualOverride}
            isOpen={true} // Admin can always order
            coupons={coupons}
            refreshKey={crmKey}
            cities={[]} // If needed, pass cities
          />'''

new_crm = '''<CrmPosPanel
            products={products}
            categories={[]}
            toppingGroups={toppingGroups}
            onOrderCreated={handleCrmOrderCreated}
          />'''

content = content.replace(old_crm, new_crm)

# Fix OrderDetailModal
old_modal = '''<OrderDetailModal
          order={selectedOrder}
          onClose={() => setSelectedOrder(null)}
          onStatusChange={updateStatus}
          couriers={couriers}
          onPrint={() => handlePrint(selectedOrder)}
        />'''

new_modal = '''<OrderDetailModal
          order={selectedOrder}
          open={!!selectedOrder}
          onClose={() => setSelectedOrder(null)}
          onUpdated={(o) => setSelectedOrder(null)}
          onPrint={() => handlePrint(selectedOrder)}
          products={products}
          categories={[]}
        />'''

content = content.replace(old_modal, new_modal)

with open(path, 'w') as f:
    f.write(content)
print("Fixed!")
