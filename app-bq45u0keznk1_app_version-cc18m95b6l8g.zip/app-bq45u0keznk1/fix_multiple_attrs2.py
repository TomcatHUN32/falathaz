import re

def fix_file(path):
    with open(path, 'r') as f:
        content = f.read()

    # Merge className="..." className="..."
    for _ in range(5):
        content = re.sub(r'className="([^"]+)"\s*className="([^"]+)"', r'className="\1 \2"', content)
        content = re.sub(r'className=\{([^}]+)\}\s*className="([^"]+)"', r'className={\1 + " \2"}', content)
        content = re.sub(r'className="([^"]+)"\s*className=\{([^}]+)\}', r'className={"\1 " + \2}', content)

    with open(path, 'w') as f:
        f.write(content)

fix_file('/workspace/app-bq45u0keznk1/src/pages/AdminDashboard.tsx')
fix_file('/workspace/app-bq45u0keznk1/src/pages/OnlineOrdering.tsx')
