import sys

path = '/workspace/app-bq45u0keznk1/src/pages/AdminDashboard.tsx'
with open(path, 'r') as f:
    content = f.read()

# Replace Top Header
old_header = '''      {/* ── Top Header (Minimal) ── */}
      <header className="shrink-0 flex items-center justify-end px-4 py-2 z-10 bg-white border-b border-border shadow-sm h-12">
        <div className="flex items-center gap-4">
          {pendingOrders.length > 0 && (
            <span className="flex items-center gap-1 text-xs font-bold px-3 py-1.5 rounded-full animate-pulse bg-[#e73423] text-white shadow-sm">
              <Bell className="w-3.5 h-3.5" />{pendingOrders.length} új
            </span>
          )}
          <button
            onClick={() => setSoundEnabled(!soundEnabled)}
            className="w-8 h-8 flex items-center justify-center rounded-md transition-colors hover:bg-gray-100 text-gray-600"
            title="Hangjelzés kikapcsolása"
          >
            {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>
          <button
            className="w-8 h-8 flex items-center justify-center rounded-md transition-colors hover:bg-gray-100 text-gray-600"
            onClick={() => window.location.reload()}
            title="Frissítés"
          >
            <Loader2 className="w-4 h-4" />
          </button>
        </div>
      </header>'''

new_header = '''      {/* ── Top Header (Minimal) ── */}
      <header className="shrink-0 flex items-center justify-between px-4 py-2 z-10 bg-white border-b border-border shadow-sm h-14">
        <div className="flex items-center gap-2">
          <button onClick={() => window.location.href = '/menu'} className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm hover:bg-gray-100 text-gray-700 font-medium">
            <Home className="w-4 h-4" />
            <span className="hidden sm:inline">Étterem</span>
          </button>
        </div>
        <div className="flex items-center gap-4">
          {pendingOrders.length > 0 && (
            <span className="flex items-center gap-1 text-xs font-bold px-3 py-1.5 rounded-full animate-pulse bg-[#e73423] text-white shadow-sm">
              <Bell className="w-3.5 h-3.5" />{pendingOrders.length} új
            </span>
          )}
          <button
            onClick={() => setSoundEnabled(!soundEnabled)}
            className="w-9 h-9 flex items-center justify-center rounded-md transition-colors hover:bg-gray-100 text-gray-600"
            title="Hangjelzés kikapcsolása"
          >
            {soundEnabled ? <Volume2 className="w-4.5 h-4.5" /> : <VolumeX className="w-4.5 h-4.5" />}
          </button>
          <button
            className="w-9 h-9 flex items-center justify-center rounded-md transition-colors hover:bg-gray-100 text-gray-600"
            onClick={() => window.location.reload()}
            title="Frissítés"
          >
            <Loader2 className="w-4.5 h-4.5" />
          </button>
          <button onClick={() => { localStorage.removeItem('token'); window.location.href = '/'; }} className="w-9 h-9 flex items-center justify-center rounded-md hover:bg-red-50 text-red-600 ml-2" title="Kijelentkezés">
            <LogOut className="w-4.5 h-4.5" />
          </button>
        </div>
      </header>'''

content = content.replace(old_header, new_header)

# Replace Bottom Tabs
old_tabs_start = '''      {/* ── Bottom Tabs (POS Layout) ── */}
      <div className="shrink-0 h-[60px] bg-[#1a1208] flex items-stretch text-[#9a9fa5] text-[11px] sm:text-xs font-bold uppercase tracking-wider relative z-50">'''

# Let's use regex or string split to replace from old_tabs_start to before {/* ── Order Detail Modal ── */}
import re
pattern = r"\{\/\* ── Bottom Tabs \(POS Layout\) ── \*\/\}.*?(?=\{\/\* ── Order Detail Modal ── \*\/\})"
new_tabs = '''{/* ── Bottom Tabs (POS Layout) ── */}
      <div className="shrink-0 h-[60px] bg-white border-t border-gray-200 flex items-stretch text-gray-600 text-[11px] sm:text-sm font-bold uppercase tracking-wider relative z-50 justify-center">
        <div className="flex w-full max-w-4xl mx-auto px-4 md:px-12">
          <button 
            className={`flex-1 flex items-center justify-center transition-colors border-t-[3px] mt-[-1px] ${activeTab === 'asztalok' ? 'border-[#b5255e] text-[#b5255e]' : 'border-transparent hover:text-gray-900'}`}
            onClick={() => setActiveTab('asztalok')}
          >
            ASZTALOK
          </button>
          <button 
            className={`flex-1 flex items-center justify-center transition-colors border-t-[3px] mt-[-1px] ${activeTab === 'orders' ? 'border-[#b5255e] text-[#b5255e]' : 'border-transparent hover:text-gray-900'}`}
            onClick={() => setActiveTab('orders')}
          >
            RENDELÉSEK
          </button>
          <button 
            className={`flex-1 flex items-center justify-center transition-colors border-t-[3px] mt-[-1px] ${activeTab === 'crm' ? 'border-[#b5255e] text-[#b5255e]' : 'border-transparent hover:text-gray-900'}`}
            onClick={() => setActiveTab('crm')}
          >
            TELEFONOS
          </button>
          <button 
            className={`flex-1 flex items-center justify-center transition-colors border-t-[3px] mt-[-1px] ${activeTab === 'dispatch' ? 'border-[#b5255e] text-[#b5255e]' : 'border-transparent hover:text-gray-900'}`}
            onClick={() => setActiveTab('dispatch')}
          >
            FUTÁROK
          </button>
        </div>
      </div>
      
      '''

content = re.sub(pattern, new_tabs, content, flags=re.DOTALL)

with open(path, 'w') as f:
    f.write(content)
print("Done")
