import re
import os

path = '/workspace/app-bq45u0keznk1/src/pages/AdminDashboard.tsx'
with open(path, 'r') as f:
    content = f.read()

# Replace <Card className="bg-card shadow-sm border-border"> with card-glow
content = re.sub(r'<Card className="bg-card shadow-sm border-border">', '<Card className="bg-card card-glow border-border">', content)
content = re.sub(r'bg-card shadow-sm', 'bg-card card-glow', content)

with open(path, 'w') as f:
    f.write(content)
