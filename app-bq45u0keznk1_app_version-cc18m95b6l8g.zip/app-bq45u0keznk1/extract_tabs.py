import re

with open('/tmp/old_AdminDashboard.tsx', 'r') as f:
    content = f.read()

# We need everything inside <div className="flex-1 overflow-hidden relative"> 
# that is NOT 'orders', 'crm', 'dispatch' (we already have new ones for these).
# The old file has:
# {activeTab === 'orders' && (...)}
# {activeTab === 'crm' && (...)}
# {activeTab === 'dispatch' && (...)}
# {activeTab === 'extra-menu' && (...)}
# {activeTab === 'products' && (...)}
# ... up to the end of the div.

# Let's find the start of 'extra-menu'
start_idx = content.find("{activeTab === 'extra-menu' && (")
if start_idx == -1:
    start_idx = content.find("{activeTab === 'products' && (")

# Find the end of the <div className="flex-1 overflow-hidden relative">
# We can look for {/* ── Alsó Menü Sáv (Mobil) ── */} or {/* ── Order Detail Modal ── */}
end_idx = content.find("{/* ── Alsó Menü Sáv (Mobil) ── */}")
if end_idx == -1:
    end_idx = content.find("{/* ── Order Detail Modal ── */}")

tabs_code = content[start_idx:end_idx].strip()
if tabs_code.endswith('</div>'):
    tabs_code = tabs_code[:-6].strip() # remove the closing div of flex-1 if included

with open('/tmp/missing_tabs.tsx', 'w') as f:
    f.write(tabs_code)
print("Extracted to /tmp/missing_tabs.tsx")
