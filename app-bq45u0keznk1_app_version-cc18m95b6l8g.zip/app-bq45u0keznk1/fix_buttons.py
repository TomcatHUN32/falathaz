import re

path = '/workspace/app-bq45u0keznk1/src/pages/OnlineOrdering.tsx'
with open(path, 'r') as f:
    content = f.read()

# Replace all bg-primary and text-primary and text-primary-foreground and shadow
content = content.replace('bg-primary text-primary-foreground shadow-[0_4px_24px_rgba(225,29,72,0.35)]', '')
content = content.replace('bg-primary text-primary-foreground', '')
content = content.replace('border-primary text-primary bg-transparent', '')
content = content.replace('text-primary', '')

with open(path, 'w') as f:
    f.write(content)
