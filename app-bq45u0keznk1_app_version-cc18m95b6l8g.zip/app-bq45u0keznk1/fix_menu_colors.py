import re

path = '/workspace/app-bq45u0keznk1/src/pages/OnlineOrdering.tsx'
with open(path, 'r') as f:
    content = f.read()

# Replace hardcoded dark styles with semantic tailwind classes
replacements = [
    # Backgrounds
    (r"style=\{\{\s*background:\s*'#110e08'\s*\}\}", 'className="bg-background min-h-screen"'),
    (r"style=\{\{\s*background:\s*'#1a1208',\s*borderBottom:\s*'1px solid #2e2416'\s*\}\}", 'className="bg-card border-b border-border relative overflow-hidden"'),
    (r"style=\{\{\s*background:\s*'#1e1a0e',\s*borderLeft:\s*'1px solid #2e2616'\s*\}\}", 'className="bg-card border-l border-border"'),
    (r"style=\{\{\s*background:\s*'#1e1a0e',\s*border:\s*'1px solid #2e2616'\s*\}\}", 'className="bg-card border border-border"'),
    (r"style=\{\{\s*background:\s*'#2a2410',\s*border:\s*'1px solid #3a3020'\s*\}\}", 'className="bg-muted border border-border"'),
    (r"style=\{\{\s*background:\s*'#2a2410'\s*\}\}", 'className="bg-muted"'),
    (r"style=\{\{\s*background:\s*'#2a2010',\s*border:\s*'1px solid #3a3020',\s*color:\s*'#a89070'\s*\}\}", 'className="bg-muted border border-border text-muted-foreground"'),
    (r"style=\{\{\s*background:\s*'#3a3020',\s*border:\s*'1px solid #4a4030',\s*color:\s*'#f5f0e8'\s*\}\}", 'className="bg-secondary border border-border text-secondary-foreground"'),
    
    # Texts
    (r"style=\{\{\s*color:\s*'#f5f0e8'\s*\}\}", 'className="text-foreground"'),
    (r"style=\{\{\s*color:\s*'#7a6850'\s*\}\}", 'className="text-muted-foreground"'),
    (r"style=\{\{\s*color:\s*'#ea5a0c'\s*\}\}", 'className="text-primary"'),
    (r"style=\{\{\s*color:\s*'#f87171'\s*\}\}", 'className="text-destructive"'),
    (r"style=\{\{\s*color:\s*'#5a5040'\s*\}\}", 'className="text-muted-foreground"'),
    
    # Primary Buttons
    (r"style=\{\{\s*background:\s*'#ea5a0c',\s*color:\s*'#fff'\s*\}\}", 'className="bg-primary text-primary-foreground"'),
    (r"style=\{\{\s*background:\s*'#ea5a0c',\s*color:\s*'#fff',\s*boxShadow:\s*'0 4px 24px rgba\(234,88,12,0.35\)'\s*\}\}", 'className="bg-primary text-primary-foreground shadow-[0_4px_24px_rgba(225,29,72,0.35)]"'),
    (r"style=\{\{\s*background:\s*'#ea5a0c',\s*color:\s*'#fff',\s*border:\s*'1px solid #ea5a0c'\s*\}\}", 'className="bg-primary text-primary-foreground border-primary"'),
    
    # Secondary / Outline Buttons
    (r"style=\{\{\s*border:\s*'1px solid #ea5a0c',\s*color:\s*'#ea5a0c',\s*background:\s*'transparent'\s*\}\}", 'className="border border-primary text-primary bg-transparent"'),
    (r"style=\{\{\s*background:\s*'transparent',\s*color:\s*'#a89070',\s*border:\s*'1px solid #3a3020'\s*\}\}", 'className="bg-transparent text-muted-foreground border border-border"'),
    
    # Primary Badge
    (r"style=\{\{\s*background:\s*'#dc2626'\s*\}\}", 'className="bg-destructive"'),
    
    # Misc
    (r"style=\{\{\s*background:\s*'#2e2616'\s*\}\}", 'className="bg-border"'),
    (r"style=\{\{\s*color:\s*'#4a3820'\s*\}\}", 'className="text-muted-foreground"'),
    (r"style=\{\{\s*background:\s*'rgba\(0,0,0,0.55\)'\s*\}\}", 'className="bg-black/50"'),
    (r"style=\{\{\s*color:\s*'#f87171',\s*background:\s*'rgba\(0,0,0,0.7\)',\s*border:\s*'1px solid rgba\(248,113,113,0.4\)'\s*\}\}", 'className="text-destructive bg-black/70 border border-destructive/40"'),
]

for old, new in replacements:
    content = re.sub(old, new, content)

# Remove `darkMode` prop from AppHeader
content = re.sub(r"<AppHeader isOpen=\{isOpen\} rightSlot=\{cartButton\} darkMode />", "<AppHeader isOpen={isOpen} rightSlot={cartButton} />", content)

with open(path, 'w') as f:
    f.write(content)
