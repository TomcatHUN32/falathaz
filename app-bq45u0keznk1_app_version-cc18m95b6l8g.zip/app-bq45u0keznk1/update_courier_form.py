import sys

path = '/workspace/app-bq45u0keznk1/src/pages/AdminDashboard.tsx'
with open(path, 'r') as f:
    content = f.read()

# Fix the /menu to /
content = content.replace("window.location.href = '/menu'", "window.location.href = '/'")

# Remove "Futár kiosztás (Régi)" from sidebar items
sidebar_item = "{ id: 'couriers', icon: Users, label: 'Futár kiosztás (Régi)' },"
content = content.replace(sidebar_item, "")

with open(path, 'w') as f:
    f.write(content)
print("Updated basic stuff")
