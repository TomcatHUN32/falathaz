import sys

path = '/workspace/app-bq45u0keznk1/src/pages/AdminDashboard.tsx'
with open(path, 'r') as f:
    content = f.read()

bad_string = """    </div>
  );
}
      </div>

      {/* ── Bottom Tabs (POS Layout) ── */}"""

good_string = """      </div>

      {/* ── Bottom Tabs (POS Layout) ── */}"""

if bad_string in content:
    content = content.replace(bad_string, good_string)
    with open(path, 'w') as f:
        f.write(content)
    print("Fixed syntax error")
else:
    print("Not found")

