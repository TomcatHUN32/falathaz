import sys

path = '/workspace/app-bq45u0keznk1/src/pages/AdminDashboard.tsx'
with open(path, 'r') as f:
    content = f.read()

content = content.replace(
    "const [activeTab, setActiveTab] = useState('orders');",
    "const [activeTab, setActiveTab] = useState('asztalok');\n  const [selectedTable, setSelectedTable] = useState<string>('');"
)

old_table = "onOpenTable={() => setActiveTab('crm')}"
new_table = "onOpenTable={(table) => { setSelectedTable(table.name); setActiveTab('crm'); }}"
content = content.replace(old_table, new_table)

old_crm = "onOrderCreated={handleCrmOrderCreated}"
new_crm = "onOrderCreated={handleCrmOrderCreated}\n            initialTable={selectedTable}"
content = content.replace(old_crm, new_crm)

with open(path, 'w') as f:
    f.write(content)
print("Done")
