path = '/workspace/app-bq45u0keznk1/src/index.css'
with open(path, 'r') as f:
    css = f.read()

# remove neon
if "/* === NEON RGB THEME === */" in css:
    css = css.split("/* === NEON RGB THEME === */")[0]

with open(path, 'w') as f:
    f.write(css)

