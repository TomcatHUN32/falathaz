import re

path = '/workspace/app-bq45u0keznk1/src/index.css'
with open(path, 'r') as f:
    css = f.read()

neon_css = """
/* === NEON RGB THEME === */
@keyframes rgb-glow {
  0% { background-position: 0% 50%; }
  50% { background-position: 100% 50%; }
  100% { background-position: 0% 50%; }
}

.rgb-animated-border {
  position: relative;
  z-index: 1;
}
.rgb-animated-border::before {
  content: "";
  position: absolute;
  inset: -2px;
  border-radius: inherit;
  background: linear-gradient(90deg, #00d2ff, #3a7bd5, #8a2be2, #ff00c8, #ff8c00, #00ffd5);
  background-size: 200% auto;
  animation: rgb-glow 3s linear infinite;
  z-index: -1;
  opacity: 0.7;
}
.rgb-animated-border::after {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: inherit;
  background: #0a0a0a;
  z-index: -1;
}

.rgb-animated-line {
  height: 2px;
  width: 100%;
  background: linear-gradient(90deg, #00d2ff, #8a2be2, #ff8c00, #00ffd5);
  background-size: 200% auto;
  animation: rgb-glow 4s linear infinite;
  box-shadow: 0 0 10px rgba(138, 43, 226, 0.6);
}

.neon-text-orange {
  color: transparent;
  -webkit-text-stroke: 1.5px #ff8c00;
  text-shadow: 0 0 15px rgba(255, 140, 0, 0.4);
}
.neon-text-blue {
  color: transparent;
  -webkit-text-stroke: 1.5px #00d2ff;
  text-shadow: 0 0 15px rgba(0, 210, 255, 0.4);
}

.neon-btn-gradient {
  background: linear-gradient(135deg, #ff8c00, #d500f9);
  color: white;
  border: none;
  box-shadow: 0 4px 15px rgba(213, 0, 249, 0.4);
  transition: all 0.3s ease;
}
.neon-btn-gradient:hover {
  box-shadow: 0 6px 20px rgba(213, 0, 249, 0.6);
  transform: translateY(-2px);
}

.neon-category-tab {
  background: transparent;
  border: 1px solid #00d2ff;
  color: #fff;
  box-shadow: inset 0 0 8px rgba(0,210,255,0.2), 0 0 8px rgba(0,210,255,0.2);
  transition: all 0.3s ease;
}
.neon-category-tab.active {
  border-color: #d500f9;
  box-shadow: inset 0 0 12px rgba(213,0,249,0.4), 0 0 12px rgba(213,0,249,0.4);
}

.neon-logo-glow {
  border: 2px solid #ffcc00;
  box-shadow: inset 0 0 15px rgba(255,204,0,0.5), 0 0 20px rgba(255,204,0,0.5);
  border-radius: 50%;
}

.neon-card {
  background: #111;
  border: 1px solid rgba(255,255,255,0.1);
  box-shadow: 0 4px 20px rgba(0,0,0,0.5);
  position: relative;
  overflow: hidden;
}
.neon-card::after {
  content: "";
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  height: 60%;
  background: linear-gradient(to top, rgba(0,0,0,0.9), transparent);
  pointer-events: none;
}
.neon-card-content {
  position: relative;
  z-index: 10;
}

.bg-black-neon {
  background-color: #050505;
}
"""

if "/* === NEON RGB THEME === */" not in css:
    with open(path, 'w') as f:
        f.write(css + "\n" + neon_css)

