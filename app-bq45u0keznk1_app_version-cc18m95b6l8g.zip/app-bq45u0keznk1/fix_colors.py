import re
import os

path = '/workspace/app-bq45u0keznk1/src/pages/AdminDashboard.tsx'
with open(path, 'r') as f:
    content = f.read()

# Replace style={{ ... }} colors
content = re.sub(r"style=\{\{\s*color:\s*'#333'\s*\}\}", 'className="text-foreground"', content)
content = re.sub(r"style=\{\{\s*color:\s*'#b5255e'\s*\}\}", 'className="text-primary"', content)
content = re.sub(r"style=\{\{\s*color:\s*'#555'\s*\}\}", 'className="text-muted-foreground"', content)
content = re.sub(r"style=\{\{\s*color:\s*'#777'\s*\}\}", 'className="text-muted-foreground"', content)
content = re.sub(r"style=\{\{\s*color:\s*'#999'\s*\}\}", 'className="text-muted-foreground"', content)
content = re.sub(r"style=\{\{\s*color:\s*'#aaa'\s*\}\}", 'className="text-muted-foreground"', content)

# Backgrounds
content = re.sub(r"style=\{\{\s*background:\s*'#f8f9fa'\s*\}\}", 'className="bg-muted/10"', content)
content = re.sub(r"style=\{\{\s*background:\s*'#f5f6f8',\s*borderBottom:\s*'1px solid #e2e6ea'\s*\}\}", 'className="bg-muted/20 border-b border-border"', content)
content = re.sub(r"style=\{\{\s*borderBottom:\s*'1px solid #e2e6ea'\s*\}\}", 'className="border-b border-border"', content)

# Bottom Nav
content = re.sub(r"style=\{\{\s*background:\s*'#fff',\s*borderTop:\s*'1px solid #c5cacf',\s*height:\s*56\s*\}\}", 'className="bg-card border-t border-border h-14"', content)

with open(path, 'w') as f:
    f.write(content)
