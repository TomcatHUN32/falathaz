# Követelményspecifikáció

## 1. Alkalmazás áttekintése

### 1.1 Alkalmazás neve
Szesztestvérek Falatház - Többétteremlicenc-alapú rendelési és admin rendszer (Multi-Restaurant SaaS Platform)

### 1.2 Leírás
Prémium Gourmet Dark / Rustic Luxury stílusú többétteremlicenc-alapú rendelési platform, amely magában foglalja az egységes főoldalt, vendégoldali rendelési felületet, étterem-specifikus admin dashboardot, POS rendszert, valamint központi Szuper-Admin (Owner) felületet. A rendszer lehetővé teszi több étterem független működését egyetlen platformon belül, teljes adatszeparációval és licenckezeléssel. A dizájn mély, füstös szénszürke/mattfekete hátterekkel, meleg réz, bronz és borostyánsárga fényekkel/kontúrokkal emeli ki a szaftos ételfotókat.

## 2. Felhasználók és használati esetek

### 2.1 Célfelhasználók
- Potenciális vendégek: Információt keresnek éttermekről, rendelést adnak le
- Regisztrált vendégek: Rendelést adnak le, követik státuszát, kezelik profiljukat
- Premium előfizetők: Havi díjas tagok extra kedvezményekkel
- Étterem admin felhasználók: Saját étterem rendeléseinek, termékeinek, statisztikáinak, futárainak, kuponjainak kezelése
- POS felhasználók: Helyszíni rendelésfelvétel
- Szuper-Admin (Owner): Teljes rendszer felügyelet, éttermek kezelése, licencek kezelése, globális statisztikák

### 2.2 Fő használati esetek
- Látogató megnyitja főoldalt → Kiválasztja megyét és várost → Megtekinti elérhető éttermeket → Kiválaszt egy éttermet → Böngészi étlapot → Kosárba helyez termékeket → Pénztárban leadja rendelést → Követi rendelés státuszát
- Premium tag rendelést ad le → Automatikus kedvezmény/ingyenes szállítás alkalmazása → VIP prioritás
- Étterem admin bejelentkezik → Kezeli saját étterem rendeléseit/termékeit → Megtekinti statisztikákat → Zárja napot → Kijelentkezik
- POS felhasználó rendelést vesz fel → Kiválasztja típust → Tételeket kosárba helyez → Megjegyzést fűz → Leadja rendelést
- Szuper-Admin bejelentkezik → Kezeli éttermeket → Állítja licencstátuszokat → Megtekinti globális statisztikákat → Kijelentkezik

## 3. Oldal struktúra és funkciók

### 3.1 Oldal hierarchia

```
├── Egységes Főoldal (/)
│   ├── 1. Lépés: Megye és Város választó
│   ├── 2. Lépés: Étterem választás (szűrt lista)
│   └── 3. Lépés: Átirányítás kiválasztott étterem étlapjára
├── Landing Page (/:restaurantId/landing)
│   ├── Hero szekció
│   ├── Statisztikák sáv
│   ├── Hogyan működik szekció
│   ├── YouTube videó szekció
│   ├── Jellemzők/előnyök szekció
│   ├── CTA szekció
│   └── Footer
├── Központi Bejelentkezés (/login)
├── Regisztráció (/register)
├── Rendelési oldal (/:restaurantId/menu)
│   ├── Étlap böngészés
│   ├── Intelligens Kosár Drawer
│   └── Pénztár (Checkout)
├── Rendelés Státusz Idővonal (/:restaurantId/order-status/:orderId)
├── Felhasználói Profil (/profile)
│   ├── Kedvencek
│   ├── Rendelési előzmények
│   ├── Újrarendelés
│   ├── Tagsági szintek
│   └── Premium Klub előfizetés
├── POS felület (/:restaurantId/pos)
│   ├── Rendeléstípus választás
│   └── Tételszintű megjegyzés
├── Étterem Admin Dashboard (/:restaurantId/admin)
│   ├── Licenc visszaszámláló (header)
│   ├── Navigációs side-bar
│   ├── Rendelések
│   ├── Termékek
│   ├── Statisztika
│   ├── Futárok (Dispatch + CRUD)
│   ├── Kuponok
│   ├── Nyitvatartás
│   ├── Nap zárása (nyomtatható)
│   ├── Futár zárás (nyomtatható)
│   ├── Kijelentkezés
│   └── Étterem oldal link
└── Szuper-Admin (Owner) Felület (/super-admin)
    ├── Éttermek kezelése (CRUD)
    ├── Licenckezelés
    ├── Globális statisztikák
    └── Kijelentkezés
```

### 3.2 Egységes Főoldal (/)

#### 3.2.1 1. Lépés: Megye és Város választó
- Letisztult, egységes Falatház brand felület
- Kötelező Megye választó (legördülő menü)
- Kötelező Város választó (legördülő menü, megye kiválasztása után töltődik)
- Alternatíva: Pontos cím megadása mező
- Tovább gomb
- Kattintásra átirányítás 2. lépéshez

#### 3.2.2 2. Lépés: Étterem választás
- Szűrt éttermek listája kártyaformátumban
- Szűrési logika: csak azok az éttermek jelennek meg, amelyek:
  + A kiválasztott városban regisztrálva vannak
  + Aktív licenccel rendelkeznek
- Étterem kártya tartalma:
  + Étterem neve
  + Nyitvatartási státusz (nyitva/zárva, beállított nyitvatartás alapján)
  + Rövid leírás
- Kattintásra átirányítás: /:restaurantId/menu

#### 3.2.3 3. Lépés: Étlap betöltése
- Kiválasztott étterem étlapjának megjelenítése
- Étterem-specifikus tartalom betöltése restaurant_id alapján

### 3.3 Landing Page (/:restaurantId/landing)

#### 3.3.1 Hero szekció
- Nagy cím: Étterem neve (restaurant_id alapján)
- Alcím: Rövid bemutatkozó szöveg
- Étterem státusz: nyitva/zárva
- CTA gomb: 「Rendelek most →」
- Kattintásra átirányítás: /:restaurantId/menu

#### 3.3.2 Statisztikák sáv
- 400+ rendelés teljesítve
- 4.9★ értékelés
- 30 perc átlagos szállítás

#### 3.3.3 Hogyan működik szekció
- 1. lépés: Válassz - Böngészd az étlapot
- 2. lépés: Fizess - Add le a rendelést
- 3. lépés: Átvesz/Szállítás - Élvezd az ételt

#### 3.3.4 YouTube videó szekció
- Két beágyazott videó:
  + https://www.youtube.com/watch?v=3a54ukaJtyc
  + https://www.youtube.com/watch?v=pM_4sQznULI

#### 3.3.5 Jellemzők/előnyök szekció
- Hat kártya: Friss alapanyagok, Gyors kiszállítás, Online fizetés, Rendelés követés, GPS nyomkövetés, Széles étlap választék

#### 3.3.6 CTA szekció
- Végső felhívás szöveg
- CTA gomb: 「Rendelek most →」
- Átirányítás: /:restaurantId/menu

#### 3.3.7 Footer
- Kapcsolat információk
- Nyitvatartás
- Social media linkek

### 3.4 Központi Bejelentkezés (/login)

#### 3.4.1 UI elrendezés
- Osztott képernyős (Split Screen) design
- Bal oldal: Hangulatos, sötétített ételfotó/animáció
- Jobb oldal: Letisztult, sötét beviteli mezők vékony réz színű kerettel
- Mezők fókuszkor borostyán fénnyel izzanak

#### 3.4.2 Bejelentkezés funkciók
- Email mező
- Jelszó mező jelszó-megjelenítő ikonnal
- Bejelentkezés gomb
- Google gyorsbejelentkezés gomb (OSS Google Login)
- Apple ID gyorsbejelentkezés gomb
- Regisztrációra váltás link

#### 3.4.3 Jogosultság alapú átirányítás
- Bejelentkezés után rendszer ellenőrzi felhasználó jogosultságát:
  + Szuper-Admin (Owner): átirányítás /super-admin
  + Étterem admin: átirányítás /:restaurantId/admin (restaurant_id alapján)
  + Vendég: átirányítás főoldalra vagy utolsó meglátogatott étterem oldalára

### 3.5 Regisztráció (/register)

#### 3.5.1 UI elrendezés
- Osztott képernyős (Split Screen) design
- Bal oldal: Hangulatos, sötétített ételfotó/animáció
- Jobb oldal: Letisztult, sötét beviteli mezők vékony réz színű kerettel

#### 3.5.2 Regisztráció funkciók
- Név mező
- Email mező
- Jelszó mező jelszó-megjelenítő ikonnal
- Jelszó megerősítés mező
- Regisztráció gomb
- Google gyorsregisztráció gomb (OSS Google Login)
- Apple ID gyorsregisztráció gomb
- Bejelentkezésre váltás link

### 3.6 Rendelési oldal (/:restaurantId/menu)

#### 3.6.1 Étlap böngészés
- Termékek megjelenítése kategóriák szerint (restaurant_id alapján szűrve)
- Termék kártyák: kép, név, leírás, ár
- Kedvenc jelölés: szivecske ikon kattintásra kedvencekhez adás
- Premium tagok: áthúzott régi ár, kiemelt előfizetői ár
- Kosárba helyezés gomb

#### 3.6.2 Intelligens Kosár Drawer (Smart Cart)

##### 3.6.2.1 UI megjelenés
- Jobb oldalról beúszó panel (Side-drawer)
- Prémium sötét textúra, réz/borostyán kiemelések
- Termékek listája képpel, névvel, árral
- Darabszám-választó: - 1 + réz gombokkal
- Törlés gomb tétel mellett

##### 3.6.2.2 Kosár értéke csúszka
- Vizuális folyamatjelző sáv
- Szöveg: 「Még X Ft és ingyen szállítjuk!」 vagy 「Még X Ft és ajándékot kapsz!」
- Sáv kitöltődése a kosár értékének növekedésével

##### 3.6.2.3 Smart Upsell ajánló
- Kosár alján gyorsgombos ajánló képekkel
- Szöveg: 「Esetleg egy ropogós sültkrumpli vagy hideg Coca-Cola?」
- 「Kóstold meg a séfünk ajánlatát!」 szekció
- Egyetlen kattintással extra szósz vagy desszert hozzáadása

##### 3.6.2.4 Pénztár gomb
- Nagy, kiemelt gomb: 「Tovább a pénztárhoz」
- Kattintásra átirányítás: /:restaurantId/checkout

### 3.7 Letisztult Pénztár (/:restaurantId/checkout)

#### 3.7.1 Egyoldalas folyamat
- Egyetlen oldalon végiggördülő 3-lépéses folyamat:
  + 1. Személyes adatok
  + 2. Szállítás
  + 3. Fizetés

#### 3.7.2 Személyes adatok
- Név mező
- Telefonszám mező
- Email mező (előre kitöltve bejelentkezett felhasználónál)

#### 3.7.3 Szállítás
- Város legördülő menü
- Cím mező (utca, házszám)
- Checkbox: 「Cím mentése a profilba」
- Szállítási díj megjelenítése:
  + Ha Szuhogy: +500 Ft (kivéve Premium tagnál)
  + Egyéb város: alapértelmezett díj vagy ingyenes (Premium tagnál)

#### 3.7.4 Fizetés
- Nagy, jól kattintható gombok:
  + Készpénz
  + Bankkártya a futárnál
  + Online fizetés (Stripe/Barion)

#### 3.7.5 Rendelés leadása
- Végösszeg megjelenítése (termékek + szállítás - kedvezmények)
- 「Rendelés leadása」 gomb
- Kattintásra rendelés mentése restaurant_id-val, átirányítás: /:restaurantId/order-status/:orderId

### 3.8 Rendelés Státusz Idővonal (/:restaurantId/order-status/:orderId)

#### 3.8.1 Függőleges idővonal
- Socket.io élő frissítés (frissítés nélkül)
- Réz/borostyán fényekkel kiemelt lépések:
  + Rendelés leadva
  + Konyhán készül
  + Futárnál van
  + Megérkezett! Jó étvágyat!
- Aktuális lépés kiemelése
- Admin státuszváltáskor azonnali frontend frissítés
- Diszkrét, prémium hangjelzés státuszváltáskor

#### 3.8.2 Népszerű ételeink ajánló
- Idővonal alatt ajánló szekció
- Népszerű ételek megjelenítése képpel, névvel, árral (restaurant_id alapján)
- Kosárba helyezés gomb

### 3.9 Felhasználói Profil (/profile)

#### 3.9.1 Kedvencek
- Kedvenc ételek listája
- Szivecskézett ételek megjelenítése képpel, névvel, árral
- Kosárba helyezés gomb
- Kedvencből eltávolítás gomb

#### 3.9.2 Rendelési előzmények
- Korábbi rendelések listája
- Rendelésszám, dátum, összeg, státusz, étterem neve
- Rendelés részletek megtekintése gomb

#### 3.9.3 Újrarendelés
- Korábbi rendelések mellett 「Ugyanezt kérem újra」 gomb
- Kattintásra teljes múltkori kosár visszadobása
- Mentett szuhogyi cím és szállítási díj automatikus alkalmazása

#### 3.9.4 Tagsági szintek (Hűségprogram)
- Pontgyűjtés: 4000 Ft = 1 pont
- Szintek:
  + Bronz Tag: üdvözlő kupon
  + Ezüst Tag: ajándék házi szósz a rendelés mellé
  + Arany Tag: fix kedvezmény + VIP törődés
- Aktuális szint és pontszám megjelenítése
- Következő szintig hiányzó pontok megjelenítése

#### 3.9.5 Falatház Premium Klub
- Havi előfizetés csatlakozás gomb
- Előfizetés leírása:
  + Szuhogy cím: -10% kedvezmény + VIP Priority
  + Nem Szuhogy cím: Ingyenes szállítás
- Stripe/Barion ismétlődő fizetés integráció
- Előfizetés státusz megjelenítése
- Lemondás gomb
- Premium tagok: arany színű PREMIUM TAG jelzés

### 3.10 POS felület (/:restaurantId/pos)

#### 3.10.1 Rendeléstípus választás
- Rendelésfelvétel kezdetekor típus választó:
  + Szállítás
  + Elvitel
  + Beülős
- Kiválasztott típus megjelenik rendelés adatai között

#### 3.10.2 Tételszintű megjegyzés
- Kosárba rakott tételekhez megjegyzés mező
- Megjegyzés szöveg mentése tételhez
- Megjegyzés megjelenítése rendelés részleteiben

### 3.11 Étterem Admin Dashboard (/:restaurantId/admin)

#### 3.11.1 Licenc visszaszámláló (header)
- Fejléc tetején diszkrét, jól látható számláló
- Havi/Negyedéves/Éves licenc esetén: 「X nap van hátra a licencből」
- Örökös licenc esetén: 「Örökös licenc — Aktív」
- Lejárt licenc esetén: Blokkoló képernyő: 「A licencidőszak lejárt. Kérjük, vegye fel a kapcsolatot a fejlesztővel!」

#### 3.11.2 Navigációs side-bar (mobil)
- Hamburger menü gomb képernyő tetején
- Kattintásra oldalsó Sheet panel kinyílik
- Menüpontok: Rendelések, Termékek, Statisztika, Futárok, Kuponok, Nyitvatartás, Nap zárása, Futár zárás, Kijelentkezés, Étterem oldal link
- Bezárás: kattintás panel melletti területre vagy bezárás gombra

#### 3.11.3 Rendelések

##### 3.11.3.1 Rendelések listázása
- Táblázatos vagy kártya formátum
- Csak saját étterem rendeléseinek megjelenítése (restaurant_id alapján szűrve)
- Szállítás: rendelésszám, típus, vevő neve, telefonszáma, státusz, összeg, időpont
- Elvitel: rendelésszám, 「Elvitel」, státusz, összeg, időpont
- Beülős: rendelésszám, 「Beülős」, státusz, összeg, időpont

##### 3.11.3.2 Rendelés státusz kezelése
- Elérhető státuszok: Új, Elfogadva, Kész, Kiadva, Törölve
- Státusz kiválasztása dropdown-ból
- Státuszváltáskor Socket.io esemény küldése frontend-nek
- Rendelés frissítése

##### 3.11.3.3 Rendelés részletek
- Rendelésszám, típus, vevő adatok (csak szállításnál), tételek megjegyzésekkel, összeg, fizetési mód, státusz, időpont

#### 3.11.4 Termékek
- Saját étterem termékeinek listázása és kezelése (restaurant_id alapján szűrve)

#### 3.11.5 Statisztika
- Saját étterem statisztikai adatainak megjelenítése

#### 3.11.6 Futárok

##### 3.11.6.1 Futár kiosztás (Dispatch)
- Saját étterem futárainak kiosztása

##### 3.11.6.2 Futárok kezelése (CRUD)
- Saját étterem futárainak listája: név, email, telefon (restaurant_id alapján szűrve)
- Új futár hozzáadása gomb → Űrlap: név, email, telefon, Mentés, Mégse
- Szerkesztés gomb → Előre kitöltött űrlap → Mentés
- Törlés gomb → Megerősítő dialógus → Törlés

#### 3.11.7 Kuponok
- Saját étterem kuponjainak kezelése

#### 3.11.8 Nyitvatartás
- Saját étterem nyitvatartási idejének kezelése

#### 3.11.9 Nap zárása (nyomtatható)
- Zárási dátum, összesített bevételek, fizetési mód bontás, futár bevételek, rendelési lista
- Nyomtatás gomb → Nyomtatóbarát nézet (CSS print media query)

#### 3.11.10 Futár zárás (nyomtatható)
- Zárási dátum, futár neve, futár bevételek, futár rendeléseinek listája
- Nyomtatás gomb → Nyomtatóbarát nézet

#### 3.11.11 Kijelentkezés
- Token törlése localStorage-ből
- Átirányítás: /login

#### 3.11.12 Étterem oldal link
- Átirányítás saját étterem nyitó oldalára (/:restaurantId/landing)

### 3.12 Szuper-Admin (Owner) Felület (/super-admin)

#### 3.12.1 Éttermek kezelése (CRUD)

##### 3.12.1.1 Éttermek listázása
- Táblázatos vagy kártya formátum
- Étterem neve, Megye, Város, Pontos cím, Licenc típusa, Licenc státusza, Lejárati dátum
- Új étterem hozzáadása gomb
- Szerkesztés gomb
- Törlés gomb

##### 3.12.1.2 Új étterem hozzáadása
- Űrlap:
  + Étterem neve mező
  + Megye választó (legördülő menü)
  + Város választó (legördülő menü)
  + Pontos cím mező
  + Licenc típusa választó: Havi, Negyedéves, Éves, Örökös
  + Lejárati dátum mező (Havi/Negyedéves/Éves esetén)
  + Mentés gomb
  + Mégse gomb
- Mentés után restaurant_id generálása, étterem mentése adatbázisba

##### 3.12.1.3 Étterem szerkesztése
- Előre kitöltött űrlap
- Mezők: Étterem neve, Megye, Város, Pontos cím, Licenc típusa, Lejárati dátum
- Mentés gomb
- Mégse gomb

##### 3.12.1.4 Étterem törlése
- Megerősítő dialógus: 「Biztosan törölni szeretné ezt az éttermet? Ez a művelet nem visszavonható.」
- Törlés gomb
- Mégse gomb

#### 3.12.2 Licenckezelés

##### 3.12.2.1 Licenc státusz manuális állítása
- Étterem kiválasztása
- Licenc típusa módosítása: Havi, Negyedéves, Éves, Örökös
- Lejárati dátum módosítása (Havi/Negyedéves/Éves esetén)
- Licenc státusz felülbírálása: Aktív, Lejárt, Felfüggesztve
- Mentés gomb

##### 3.12.2.2 Licenc automatikus kezelés
- Rendszer naponta ellenőrzi lejárati dátumokat
- Lejárt licenc esetén:
  + Étterem státusza: Lejárt
  + Étterem nem jelenik meg főoldali étteremválasztó listában
  + Étterem admin felületén blokkoló képernyő megjelenítése

#### 3.12.3 Globális statisztikák
- Összesített rendelések száma (összes étterem)
- Aktív partnerek száma
- Lejárt licenccel rendelkező éttermek száma
- Összesített bevételek (összes étterem)

#### 3.12.4 Kijelentkezés
- Token törlése localStorage-ből
- Átirányítás: /login

## 4. Design specifikáció

### 4.1 Gourmet Dark / Rustic Luxury stílus
- Háttér: mély, füstös szénszürke/mattfekete
- Kiemelések: meleg réz, bronz, borostyánsárga fények/kontúrok
- Textúrák: letisztult, prémium felületek
- Ételfotók: szaftos, jól megvilágított képek kiemeléssel

### 4.2 Színek
- Brand szín: #e73423 (piros-narancs)
- Háttér: szénszürke/mattfekete (#1a1a1a, #0d0d0d)
- Kiemelések: réz (#b87333), bronz (#cd7f32), borostyánsárga (#ffbf00)
- Szöveg: világos szürke/fehér (#f5f5f5, #ffffff)

### 4.3 Betűtípusok
- Fejlécek: Bricolage Grotesque (félkövér, nagybetűs, 44-80px)
- Szöveg: Barlow
- Betöltés: Google Fonts

### 4.4 UI elemek
- Gombok: lekerekített pill-gombok (border-radius: 9999px), réz/borostyán kiemelés hover-kor
- Beviteli mezők: vékony réz színű keret, borostyán fény fókuszkor
- Kártyák: sötét háttér, finom árnyék, réz kontúr
- Side-bar/Drawer: oldalsó panel slide-in/slide-out animációval

### 4.5 Animációk
- Fade-in effektek
- Scroll-triggered megjelenések
- CSS transition alapú animációk
- Side-bar/Drawer slide animáció
- Kosár értéke csúszka animált kitöltődés

### 4.6 Reszponzivitás
- Desktop és mobil nézet támogatása
- Mobil eszközön side-bar navigáció

## 5. Üzleti szabályok és logika

### 5.1 Multi-Tenant (Többétteremlicenc) struktúra

#### 5.1.1 Adatbázis szétválasztás
- Minden étteremnek egyedi restaurant_id azonosító
- Minden étlap, kategória, étel, futár, rendelés restaurant_id-hoz kötve
- Éttermek egymás adatait nem láthatják

#### 5.1.2 Helyszín alapú szűrés
- Éttermek profiljához kötelező mezők: Megye, Város, Pontos cím
- Főoldali megye/város választó szűrési logikája:
  + Kiválasztott megye és város alapján adatbázis lekérdezés
  + Csak aktív licenccel rendelkező éttermek megjelenítése

#### 5.1.3 Központi Auth panel
- Központi beléptető felület: /login
- Jogosultság és restaurant_id alapú átirányítás:
  + Szuper-Admin: /super-admin
  + Étterem admin: /:restaurantId/admin
  + Vendég: főoldal vagy utolsó meglátogatott étterem

### 5.2 Licenckezelő modul

#### 5.2.1 Licenc típusok
- Havi: 30 napos időszak
- Negyedéves: 90 napos időszak
- Éves: 365 napos időszak
- Örökös: Végleges vétel, nincs lejárati dátum

#### 5.2.2 Vizuális visszaszámláló
- Étterem admin felület fejlécében megjelenítés:
  + Havi/Negyedéves/Éves: 「X nap van hátra a licencből」
  + Örökös: 「Örökös licenc — Aktív」
- Visszaszámláló naponta frissül

#### 5.2.3 Automatikus korlátozás
- Licenc lejáratakor (0 nap):
  + Étterem státusza: Lejárt
  + Étterem nem jelenik meg főoldali étteremválasztó listában
  + Vendégek nem tudnak rendelést leadni
  + Étterem admin felületén blokkoló képernyő: 「A licencidőszak lejárt. Kérjük, vegye fel a kapcsolatot a fejlesztővel!」

### 5.3 Routing szabályok
- Főoldal: /
- Landing page: /:restaurantId/landing
- Bejelentkezés: /login
- Regisztráció: /register
- Rendelési oldal: /:restaurantId/menu
- Pénztár: /:restaurantId/checkout
- Rendelés státusz: /:restaurantId/order-status/:orderId
- Profil: /profile
- POS: /:restaurantId/pos
- Étterem Admin Dashboard: /:restaurantId/admin
- Szuper-Admin: /super-admin
- Kijelentkezés után átirányítás: /login

### 5.4 Autentikáció
- Token alapú hitelesítés
- Token tárolása: localStorage
- Kijelentkezéskor token törlése
- Google Login: OSS Google Login módszer használata
- Apple ID Login: Apple Sign-In integráció

### 5.5 Szállítási díj logika
- Város választó: legördülő menü
- Ha Szuhogy kiválasztva:
  + Nem Premium tag: +500 Ft szállítási díj
  + Premium tag (isPremium: true): -10% kedvezmény kosár végösszegéből + VIP Priority
- Ha nem Szuhogy:
  + Nem Premium tag: alapértelmezett szállítási díj
  + Premium tag: 0 Ft szállítási díj (ingyenes)

### 5.6 Premium Klub logika
- Előfizetés: Stripe/Barion ismétlődő fizetés
- Adatbázis: isPremium: true mező
- Kedvezmények automatikus alkalmazása pénztárban:
  + Szuhogy cím: -10% kosár végösszeg + VIP Priority
  + Nem Szuhogy cím: 0 Ft szállítási díj
- Premium tag jelzés: arany színű PREMIUM TAG
- Étlapon: áthúzott régi ár, kiemelt előfizetői ár

### 5.7 Hűségprogram logika
- Pontgyűjtés: 4000 Ft rendelés = 1 pont
- Sikeres rendelés után automatikus pontjóváírás
- Szintek:
  + Bronz Tag: 0-9 pont → üdvözlő kupon
  + Ezüst Tag: 10-29 pont → ajándék házi szósz
  + Arany Tag: 30+ pont → fix kedvezmény + VIP törődés

### 5.8 Rendelés státusz frissítés
- Admin státuszváltáskor Socket.io esemény: order_status_update
- Frontend Socket.io listener: azonnali idővonal frissítés
- Diszkrét hangjelzés lejátszása státuszváltáskor

### 5.9 Kosár értéke csúszka logika
- Küszöbérték beállítása (pl. 5000 Ft ingyenes szállításhoz)
- Kosár értékének folyamatos számítása
- Hiányzó összeg megjelenítése: 「Még X Ft és ingyen szállítjuk!」
- Küszöb elérése után: 「Gratulálunk! Ingyenes szállítás!」

### 5.10 Újrarendelés logika
- Korábbi rendelés tételeinek lekérése
- Tételek kosárba helyezése
- Mentett cím és szállítási díj automatikus alkalmazása
- Átirányítás: /:restaurantId/checkout

### 5.11 Kedvencek logika
- Szivecske ikon kattintásra kedvencekhez adás/eltávolítás
- Kedvencek mentése felhasználói profilban
- Kedvencek megjelenítése /profile oldalon

### 5.12 POS rendeléstípus logika
- Rendeléstípus választása kötelező
- Kiválasztott típus mentése rendelés adatai között
- Rendeléstípus megjelenítése admin felületen és rendelés részleteiben

### 5.13 Tételszintű megjegyzés logika
- Megjegyzés opcionális
- Megjegyzés mentése tételhez
- Megjegyzés megjelenítése rendelés részleteiben és konyhai nyomtatványon

### 5.14 Szuper-Admin jogosultságok
- Teljes hozzáférés minden étterem adataihoz
- Éttermek CRUD műveletek
- Licencek manuális állítása és felülbírálása
- Globális statisztikák megtekintése

## 6. Backend végpontok és Socket események

### 6.1 API végpontok
- /api/restaurants: éttermek CRUD (Szuper-Admin)
- /api/restaurants/:restaurantId/orders: rendelések CRUD (restaurant_id alapján szűrve)
- /api/restaurants/:restaurantId/products: termékek CRUD (restaurant_id alapján szűrve)
- /api/restaurants/:restaurantId/settings: beállítások kezelése
- /api/cities: városok listája szállítási díjakkal
- /api/users: felhasználók kezelése
- /api/favorites: kedvencek kezelése
- /api/loyalty: hűségprogram pontok kezelése
- /api/premium: Premium előfizetés kezelése
- /api/licenses: licencek kezelése (Szuper-Admin)
- /api/super-admin/stats: globális statisztikák (Szuper-Admin)

### 6.2 Socket.io események
- order_status_update: rendelés státusz változás
- new_order: új rendelés érkezett

## 7. Kivételek és határesetek

| Helyzet | Kezelés |
|---------|--------|
| YouTube videó nem tölthető be | Placeholder kép megjelenítése |
| Státusz információ nem elérhető | Alapértelmezett szöveg |
| CTA gomb kattintás sikertelen | Hibaüzenet |
| Google Fonts betöltés sikertelen | Fallback betűtípus |
| Token hiányzik vagy érvénytelen | Átirányítás /login |
| Socket.io kapcsolat megszakad | Újracsatlakozás, hibaüzenet |
| Hangjelzés lejátszás sikertelen | Csendes folytatás |
| Stripe/Barion fizetés sikertelen | Hibaüzenet, újrapróbálkozás |
| Város nem található | Alapértelmezett szállítási díj |
| Premium státusz ellenőrzés sikertelen | Nem Premium tagként kezelés |
| Kedvenc hozzáadás sikertelen | Hibaüzenet |
| Újrarendelés sikertelen | Hibaüzenet |
| Futár mentése sikertelen | Hibaüzenet |
| Email formátum hibás | Validációs hibaüzenet |
| Telefon formátum hibás | Validációs hibaüzenet |
| Rendeléstípus nem választott | Figyelmeztetés |
| Megjegyzés mentése sikertelen | Hibaüzenet |
| Megye/város nem választott | Figyelmeztetés |
| Nincs elérhető étterem kiválasztott városban | Üzenet: 「Sajnos jelenleg nincs elérhető étterem ebben a városban.」 |
| Licenc lejárt | Blokkoló képernyő admin felületen, étterem nem jelenik meg főoldalon |
| restaurant_id hiányzik vagy érvénytelen | Átirányítás főoldalra |
| Szuper-Admin jogosultság hiányzik | Átirányítás /login, hibaüzenet |
| Étterem törlése sikertelen | Hibaüzenet |
| Licenc módosítása sikertelen | Hibaüzenet |

## 8. Elfogadási kritériumok

1. Látogató megnyitja főoldalt (/)
2. Kiválasztja megyét és várost
3. Rendszer megjeleníti elérhető éttermeket (aktív licenccel)
4. Látogató kiválaszt egy éttermet
5. Átirányítás /:restaurantId/menu oldalra
6. Látogató regisztrál (/register) Google/Apple ID-val vagy email/jelszóval
7. Látogató böngészi étlapot, szivecskézi kedvenc ételt
8. Látogató kosárba helyez tételeket
9. Intelligens kosár drawer megnyílik, upsell ajánló megjelenik
10. Látogató pénztárhoz megy (/:restaurantId/checkout)
11. Látogató kitölti személyes adatokat, kiválasztja Szuhogy várost
12. Rendszer automatikusan hozzáadja +500 Ft szállítási díjat (ha nem Premium tag)
13. Látogató kiválasztja fizetési módot, leadja rendelést
14. Átirányítás /:restaurantId/order-status/:orderId oldalra
15. Függőleges idővonal megjelenik Socket.io élő frissítéssel
16. Étterem admin bejelentkezik (/login)
17. Átirányítás /:restaurantId/admin oldalra
18. Admin felület fejlécében licenc visszaszámláló megjelenik
19. Admin státuszt vált rendeléshez
20. Frontend idővonal azonnal frissül, hangjelzés lejátszódik
21. Szuper-Admin bejelentkezik (/login)
22. Átirányítás /super-admin oldalra
23. Szuper-Admin új éttermet ad hozzá (név, megye, város, cím, licenc típus)
24. Étterem mentése, restaurant_id generálása
25. Szuper-Admin módosítja étterem licencstátuszát
26. Licenc lejáratakor étterem automatikusan eltűnik főoldali listából
27. Lejárt licenccel rendelkező étterem admin felületén blokkoló képernyő megjelenik

## 9. Jelen verzióban nem megvalósított funkciók

- Többnyelvű támogatás
- Dinamikus statisztikák backend-ből (étterem szinten)
- Felhasználói vélemények megjelenítése
- Blog szekció
- Foglalási funkció
- Interaktív térkép étterem helyszínnel
- Newsletter feliratkozás
- Chatbot integráció
- Élő térképes futárkövetés (helyette idővonal)
- Ajándékkártya vásárlás
- Törzsvásárlói pontok beváltása termékekre
- Automatikus email értesítések licenc lejáratkor
- Fizetési előzmények Szuper-Admin felületen
- Étterem teljesítmény összehasonlító riportok
- Mobilalkalmazás (iOS/Android)
- Push értesítések