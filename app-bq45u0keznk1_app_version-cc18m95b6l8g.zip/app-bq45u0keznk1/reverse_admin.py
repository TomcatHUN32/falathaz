import re

path = '/workspace/app-bq45u0keznk1/src/pages/AdminDashboard.tsx'
with open(path, 'r') as f:
    content = f.read()

# Reverse replacements
replacements = [
    (r'className="text-foreground"', "style={{ color: '#333' }}"),
    (r'className="text-primary"', "style={{ color: '#b5255e' }}"),
    (r'className="text-muted-foreground"', "style={{ color: '#555' }}"), # might overlap with 777, 999, aaa. let's be careful.
    
    (r'className="bg-muted/10"', "style={{ background: '#f8f9fa' }}"),
    (r'className="bg-muted/20 border-b border-border"', "style={{ background: '#f5f6f8', borderBottom: '1px solid #e2e6ea' }}"),
    (r'className="border-b border-border"', "style={{ borderBottom: '1px solid #e2e6ea' }}"),
    (r'className="bg-card border-t border-border h-14"', "style={{ background: '#fff', borderTop: '1px solid #c5cacf', height: 56 }}"),
    
    (r'className=\{isActive \? \'text-primary\' : \'text-foreground\'\}', "style={{ color: isActive ? '#b5255e' : '#333' }}"),
    (r'className="bg-card border-b border-border shadow-\[0_4px_12px_rgba\(225,29,72,0\.05\)\]"', "style={{ background: '#fff', borderBottom: '1px solid #c5cacf' }}"),
    (r'className=\{orderTypeFilter === t\.key \? \'text-primary border-b-2 border-primary\' : \'text-muted-foreground border-b-2 border-transparent\'\}', "style={{ color: orderTypeFilter === t.key ? '#b5255e' : '#666', borderBottom: orderTypeFilter === t.key ? '2px solid #b5255e' : '2px solid transparent' }}"),
    (r'className="bg-muted text-muted-foreground"', "style={{ background: '#dde1e6', color: '#555' }}"),
    (r'className=\{isActive \? \'text-primary border-t-2 border-primary\' : \'text-muted-foreground border-t-2 border-transparent\'\}', "style={{ color: isActive ? '#b5255e' : '#777', borderTop: isActive ? '2px solid #b5255e' : '2px solid transparent' }}"),
    (r'className="bg-primary"', "style={{ background: '#b5255e' }}"),
    (r'className="w-px h-4 bg-border mx-2"', 'className="w-px h-4 bg-[#e2e6ea] mx-2"'),
    
    (r'className="bg-card card-glow border-border animate-in fade-in zoom-in-95 duration-500"', 'className="bg-card shadow-sm border-border"'),
    (r'bg-card card-glow', 'bg-card shadow-sm'),
    (r'className="h-screen flex flex-col overflow-hidden bg-background"', 'className="h-screen flex flex-col overflow-hidden" style={{ background: \'#dde1e6\' }}'),
]

for old, new in replacements:
    content = re.sub(old, new, content)

with open(path, 'w') as f:
    f.write(content)

